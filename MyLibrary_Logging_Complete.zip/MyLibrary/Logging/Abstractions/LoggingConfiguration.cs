namespace MyLibrary.Logging.Abstractions
{
    public class LoggingConfiguration
    {
        public LogLevel MinimumLogLevel { get; set; } = LogLevel.Info;
        public string LogFilePath { get; set; } = "logs/";
    }
}
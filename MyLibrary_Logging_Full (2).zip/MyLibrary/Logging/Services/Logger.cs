using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Serilog;
using Serilog.Formatting.Compact;
using MyLibrary.Logging.Abstractions;

namespace MyLibrary.Logging.Services
{
    public class Logger : ILoggerService
    {
        private readonly Serilog.ILogger _logger;
        private readonly LogLevel _configuredLogLevel;
        private readonly string _logFilePath;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private static readonly Lazy<string> _libraryVersion = new Lazy<string>(() =>
            Assembly.GetExecutingAssembly().GetName().Version?.ToString() ?? "Unknown"
        );

        public static string LibraryVersion => _libraryVersion.Value;

        public Logger(LoggingConfiguration config, IHttpContextAccessor httpContextAccessor)
        {
            _configuredLogLevel = config.MinimumLogLevel;
            _logFilePath = config.LogFilePath;
            _httpContextAccessor = httpContextAccessor;

            _logger = new LoggerConfiguration()
                .MinimumLevel.Information()
                .WriteTo.File(new CompactJsonFormatter(), GetExecutionLogFilePath(), rollingInterval: RollingInterval.Day)
                .CreateLogger();
        }

        private string GetExecutionLogFilePath()
        {
            var executionId = Guid.NewGuid().ToString();
            var dateTime = DateTime.UtcNow.ToString("yyyyMMdd_HHmmss");
            var endpoint = _httpContextAccessor.HttpContext?.Request?.Path.Value?.Replace("/", "_") ?? "UnknownEndpoint";
            return Path.Combine(_logFilePath, $"execution_{executionId}_{dateTime}_{endpoint}.log");
        }

        public async Task AddSingleLogAsync(string message, LogLevel level)
        {
            if (level < _configuredLogLevel) return;
            var logEntry = $"[{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss}] - {message}";
            _logger.Information(logEntry);
            await Task.CompletedTask;
        }

        public async Task AddEnvironmentLogAsync()
        {
            var context = _httpContextAccessor.HttpContext;
            if (context == null) return;

            var environmentInfo = new
            {
                Timestamp = DateTime.UtcNow,
                ClientIP = context.Connection.RemoteIpAddress?.ToString() ?? "Unknown",
                UserAgent = context.Request.Headers["User-Agent"].ToString(),
                Method = context.Request.Method,
                Path = context.Request.Path,
                OS = System.Runtime.InteropServices.RuntimeInformation.OSDescription,
                Host = context.Request.Host.ToString()
            };

            _logger.Information(JsonSerializer.Serialize(environmentInfo, new JsonSerializerOptions { WriteIndented = true }));
            await Task.CompletedTask;
        }

        public async Task LogExceptionAsync(Exception ex)
        {
            var context = _httpContextAccessor.HttpContext;
            var exceptionDetails = new
            {
                ExceptionType = ex.GetType().FullName,
                Message = ex.Message,
                StackTrace = ex.StackTrace,
                InnerException = ex.InnerException?.Message,
                Source = ex.Source,
                Timestamp = DateTime.UtcNow,
                RequestPath = context?.Request?.Path.Value ?? "Unknown",
                RequestMethod = context?.Request?.Method ?? "Unknown",
                ClientIP = context?.Connection?.RemoteIpAddress?.ToString() ?? "Unknown"
            };

            _logger.Error(JsonSerializer.Serialize(exceptionDetails, new JsonSerializerOptions { WriteIndented = true }));
            await Task.CompletedTask;
        }
    }
}
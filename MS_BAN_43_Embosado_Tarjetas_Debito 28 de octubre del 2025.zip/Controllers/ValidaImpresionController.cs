﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MS_BAN_43_Embosado_Tarjetas_Debito.Models.Dtos;
using MS_BAN_43_Embosado_Tarjetas_Debito.Models.Dtos.ValidaImpresion;
using MS_BAN_43_Embosado_Tarjetas_Debito.Services.ValidaImpresion;
using MS_BAN_43_Embosado_Tarjetas_Debito.Utils;
using System.Net.Mime;

namespace MS_BAN_43_Embosado_Tarjetas_Debito.Controllers;

/// <summary>
/// Endpoints de validación de impresión.
/// </summary>
/// <remarks>
/// Constructor que inyecta dependencias de IValidaImpresionService.
/// </remarks>
/// <param name="validaImpresion">Objeto GetValidaImpresionDto contiene los parametros requeridos para validar una impresión.</param>
[ApiController]
[Route("api/[controller]")]
[Produces(MediaTypeNames.Application.Json)]
[Authorize(Policy = "ActiveSession")]
public class ValidaImpresionController(
    IValidaImpresionService validaImpresion) : ControllerBase
{
    private readonly IValidaImpresionService _validaImpresion = validaImpresion;
    private readonly ResponseHandler _responseHandler = new();

    /// <summary>
    /// Valida si la tarjeta fue impresa (consulta UNI5400).
    /// </summary>
    /// <param name="getValidaImpresionDto">Parámetros de búsqueda.</param>
    /// <returns>Respuesta HTTP con el resultado de la validación.</returns>
    /// <remarks>
    /// Devuelve:
    /// - <b>200</b> con estado <c>success</c> cuando el registro se actualiza correctamente.
    /// - <b>400</b> con estado <c>BadRequest</c> cuando la solicitud es inválida o ocurre un error controlado.
    /// </remarks>
    /// <remarks>
    /// Rutas soportadas:
    /// - <c>GET api/ValidaImpresion/ValidaImpresion</c> (alias por compatibilidad)
    /// </remarks>
    [HttpGet("ValidaImpresion")]
    [ProducesResponseType(typeof(GetValidaImpresionResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(GetValidaImpresionResponseDto), StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> ValidaImpresion([FromQuery] GetValidaImpresionDto getValidaImpresionDto)
    {
        if (!ModelState.IsValid)
        {
            var msg = string.Join(" | ", ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => string.IsNullOrWhiteSpace(e.ErrorMessage) ? e.Exception?.Message : e.ErrorMessage)
                .Where(s => !string.IsNullOrWhiteSpace(s)));

            var bad = BuildError("BadRequest", "400",
                string.IsNullOrWhiteSpace(msg) ? "Solicitud inválida." : msg);

            return _responseHandler.HandleResponse(bad, bad.Codigo.Status);
        }

        try
        {
            var respuesta = await _validaImpresion.ValidaImpresionAsync(getValidaImpresionDto);

            // Garantiza respuesta no nula para el handler
            respuesta ??= BuildError("BadRequest", "400", "No se obtuvo respuesta del servicio.");

            return _responseHandler.HandleResponse(respuesta, respuesta.Codigo.Status);
        }
        catch (Exception ex)
        {
            var error = BuildError("BadRequest", "400", ex.Message);
            return _responseHandler.HandleResponse(error, error.Codigo.Status);
        }
    }

    private static GetValidaImpresionResponseDto BuildError(string status, string code, string message)
        => new()
        {
            Imprime = false,
            Codigo = new CodigoDto
            {
                Status = status,
                Error = code,
                Message = message,
                TimeStamp = DateTime.Now.ToString("HH:mm:ss tt")
            }
        };
}
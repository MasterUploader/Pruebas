﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MS_BAN_43_Embosado_Tarjetas_Debito.Models.Dtos.Auth;
using MS_BAN_43_Embosado_Tarjetas_Debito.Models.Dtos.Heartbeat;
using MS_BAN_43_Embosado_Tarjetas_Debito.Services.AuthService;
using MS_BAN_43_Embosado_Tarjetas_Debito.Services.SessionManagerService;
using MS_BAN_43_Embosado_Tarjetas_Debito.Utils;
using System.Net.Mime;
using System.Security.Claims;

namespace MS_BAN_43_Embosado_Tarjetas_Debito.Controllers;

/// <summary>
/// Endpoints de autenticación para el sitio de embosado.
/// </summary>
/// <remarks>
/// constructor que inyecta los servicios necesarios.
/// </remarks>
/// <param name="authService">Instancia de IAuthService.</param>
/// <param name="sessionManagerService">Instancia de ISessionManagerService.</param>
[ApiController]
[Route("api/[controller]")]
[Produces(MediaTypeNames.Application.Json)]
[Authorize(Policy="ActiveSession")]
public class AuthController(
    IAuthService authService,
    ISessionManagerService sessionManagerService) : ControllerBase
{
    private readonly IAuthService _authService = authService;
    private readonly ISessionManagerService _sessionManagerService = sessionManagerService;
    private readonly ResponseHandler _responseHandler = new();

    /// <summary>
    /// Realiza el proceso de logueo contra AD y registra actividad.
    /// </summary>
    /// <returns>Respuesta HTTP con el resultado del servicio.</returns>
    /// <remarks>
    /// Rutas soportadas:
    /// - <c>GET api/Auth/Login</c>
    /// </remarks>
    [HttpPost("Login")]
    [AllowAnonymous]
    [ProducesResponseType(typeof(GetAuthResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(GetAuthResponseDto), StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Login([FromBody] LoginDto loginDto)
    {
        if (!ModelState.IsValid)
        {
            var dto = new GetAuthResponseDto
            {
                Codigo =
                    {
                        Status = "BadRequest",
                        Error = "400",
                        Message = "Solicitud inválida.",
                        TimeStamp = DateTime.Now.ToString("HH:mm:ss tt")
                    }
            };
            return _responseHandler.HandleResponse(dto, dto.Codigo.Status);
        }

        try
        {
            var response = await _authService.AuthenticateAsync(loginDto!);
            return _responseHandler.HandleResponse(response, response.Codigo.Status);
        }
        catch (Exception ex)
        {
            var dto = new GetAuthResponseDto
            {
                Codigo =
                    {
                        Status = "BadRequest",
                        Error = "400",
                        Message = ex.Message,
                        TimeStamp = DateTime.Now.ToString("HH:mm:ss tt")
                    }
            };
            return _responseHandler.HandleResponse(dto, dto.Codigo.Status);
        }
    }

    /// <summary>
    /// Mantiene viva la sesión del usuario autenticado.
    /// </summary>
    /// <returns></returns>
    [HttpPost("KeepAlive")]
    [ProducesResponseType(typeof(GetHeartbeatDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(GetHeartbeatDto), StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> KeepAlive()
    {
        // Usuario de red desde el token
        var userId = User.FindFirstValue(ClaimTypes.NameIdentifier)
                     ?? User.FindFirstValue(ClaimTypes.Name)
                     ?? User.Identity?.Name;


        await Task.Yield(); // Evita advertencia de método async sin await.

        if (string.IsNullOrWhiteSpace(userId))
        {
            var err = new GetHeartbeatDto { Codigo = { Status = "Unauthorized", Error = "401", Message = "Usuario no identificado" } };
            return _responseHandler.HandleResponse(err, err.Codigo.Status);
        }

        // (Opcional) validación contra tu bandera en DB: LOGB04SEA
        var active = _sessionManagerService.IsSessionActiveAsync(userId);
        if (!active)
        {
            var err = new GetHeartbeatDto { Codigo = { Status = "Unauthorized", Error = "401", Message = "Sesión no activa" } };
            return _responseHandler.HandleResponse(err, err.Codigo.Status);
        }

        // Estrategia 1: ROTAR token (mejor seguridad)
        // var (securityToken, jwtString) = await _sessionSvc.GenerateTokenAsync(new LoginDto { User = userId, Password = "", /*...*/ });
        // var dto = new GetHeartbeatDto
        // {
        //     Token = new TokenDto { Token = jwtString, Expiration = securityToken.ValidTo },
        //     Codigo = { Status = "OK", Error = "0", Message = "OK" }
        // };
        // return _response.HandleResponse(dto, dto.Codigo.Status);

        // Estrategia 2: SOLO extender expiración de sesión (sin rotar token)
        // Si tu backend maneja expiración de sesión aparte del JWT, devuelve nueva fecha:
        var newExp = DateTime.UtcNow.AddMinutes(15); // ejemplo: +15 min
        var dto = new GetHeartbeatDto
        {
            Token = new TokenDto { Token = string.Empty, Expiration = newExp }, // Token vacío = no rotado
            Codigo = { Status = "OK", Error = "0", Message = "OK" }
        };
        return _responseHandler.HandleResponse(dto, dto.Codigo.Status);
    }

    /// <summary>
    /// Realiza el Proceso des deslogueo de un usuario
    /// </summary>
    /// <returns></returns>
    [HttpPost("Logout")]
    public async Task<IActionResult> Logout()
    {
        var userId = User.FindFirstValue(ClaimTypes.NameIdentifier)
                     ?? User.Identity?.Name;
        if (!string.IsNullOrWhiteSpace(userId))
        {
            // Marca sesión como inactiva en tu tabla (LOGB04SEA = 1) y opcionalmente
            // agrega el jti del token a una denylist temporal (hasta que expire).
            await _sessionManagerService.InvalidateOldSessionAsync(userId);
        }

        var ok = new GetHeartbeatDto
        {
            Codigo = { Status = "OK", Error = "0", Message = "Sesión finalizada" }
        };
        return _responseHandler.HandleResponse(ok, ok.Codigo.Status);
    }
}

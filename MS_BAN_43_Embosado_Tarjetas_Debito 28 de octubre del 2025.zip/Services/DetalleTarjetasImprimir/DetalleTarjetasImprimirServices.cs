﻿using Connections.Abstractions;
using MS_BAN_43_Embosado_Tarjetas_Debito.Models.Dtos.DetalleTarjetaImprimir;
using MS_BAN_43_Embosado_Tarjetas_Debito.Repository.IRepository.DetalleTarjetaImprimir;

namespace MS_BAN_43_Embosado_Tarjetas_Debito.Services.DetalleTarjetasImprimir;

/// <summary>
/// Clase de servicio DetalleTarjetasImprimirServices.
/// </summary>
public class DetalleTarjetasImprimirServices(IDatabaseConnection _connection, IHttpContextAccessor _contextAccessor) : IDetalleTarjetasImprimirServices
{
    /// <inheritdoc />
    public async Task<GetDetallesTarjetasImprimirResponseDto> GetTarjetas(GetDetalleTarjetaImprimirDto getDetalleTarjetaImprimirDto)
    {
        DetalleTarjetasImprimirRepository _detalleTarjetasImprimirRepository = new(_connection, _contextAccessor);

        string bin = getDetalleTarjetaImprimirDto.BIN;
        int agenciaApertura = short.Parse(getDetalleTarjetaImprimirDto.AgenciaApertura);
        int agenciaImprime = short.Parse(getDetalleTarjetaImprimirDto.AgenciaImprime);

        try
        {
            _connection.Open();

            return await _detalleTarjetasImprimirRepository.BusquedaUNI5400(bin, agenciaImprime, agenciaApertura);
        }
        catch (Exception ex)
        {
            GetDetallesTarjetasImprimirResponseDto getDetalleTarjetasImprimirResponseDto = new();

            getDetalleTarjetasImprimirResponseDto.Codigo.Message = ex.Message;
            getDetalleTarjetasImprimirResponseDto.Codigo.Status = "BadRequest";
            getDetalleTarjetasImprimirResponseDto.Codigo.Error = "400";
            getDetalleTarjetasImprimirResponseDto.Codigo.TimeStamp = string.Format("{0:HH:mm:ss tt}", DateTime.Now);

            return getDetalleTarjetasImprimirResponseDto;
        }
    }
}

﻿using MS_BAN_43_Embosado_Tarjetas_Debito.Models.Dtos.Auth;

namespace MS_BAN_43_Embosado_Tarjetas_Debito.Services.AuthService;

/// <summary>
/// Interfaz IAuthService, de la clase de Servicio AuthService.
/// </summary>
public interface IAuthService
{
    /// <summary>
    /// Método AuthenticateAsync, encargado del proceso de Logueo de un usuario.
    /// Válida el usuario y contraseña contra el AD, devolviendo los parametros de AD.
    /// Si los párametros coinciden con los autorizados se procede con el logueo.
    /// </summary>
    /// <param name="getAuthDto">Objeto de tipo LoginDto.</param>
    /// <returns>Retorna respuesta HTTP con objeto GetAuthResponseDto.</returns>
    Task<GetAuthResponseDto> AuthenticateAsync(LoginDto getAuthDto);
}
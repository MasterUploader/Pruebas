﻿using Connections.Abstractions;
using MS_BAN_43_Embosado_Tarjetas_Debito.Models.Dtos.ValidaImpresion;
using QueryBuilder.Builders;
using QueryBuilder.Enums;
using QueryBuilder.Helpers;
using System.Data.Common;

namespace MS_BAN_43_Embosado_Tarjetas_Debito.Services.ValidaImpresion;


/// <summary>
/// Servicio que valida si una tarjeta fue impresa consultando la tabla S38FILEBA.UNI5400.
/// </summary>
/// <remarks>
/// Criterio: existe registro para ST_CODIGO_TARJETA con fecha/hora de impresión &gt; 0 y usuario no vacío.
/// </remarks>
public class ValidaImpresionService(IDatabaseConnection connection, IHttpContextAccessor contextAccessor) : IValidaImpresionService
{
    private readonly IDatabaseConnection _connection = connection;
    private readonly IHttpContextAccessor _contextAccessor = contextAccessor;

    /// <inheritdoc />
    public async Task<GetValidaImpresionResponseDto> ValidaImpresionAsync(GetValidaImpresionDto getValidaImpresionDto)
    {
        var resp = new GetValidaImpresionResponseDto();

        // Validación básica
        var codigoTarjeta = (getValidaImpresionDto?.CodigoTarjeta ?? string.Empty).Trim();
        if (string.IsNullOrWhiteSpace(codigoTarjeta))
        {
            resp.Imprime = false;
            resp.Codigo.Status = "BadRequest";
            resp.Codigo.Error = "400";
            resp.Codigo.Message = "El parámetro 'CodigoTarjeta' es obligatorio.";
            resp.Codigo.TimeStamp = DateTime.Now.ToString("HH:mm:ss tt");
            return resp;
        }

        _connection.Open();
        if (!_connection.IsConnected)
        {
            resp.Imprime = false;
            resp.Codigo.Status = "BadRequest";
            resp.Codigo.Error = "400";
            resp.Codigo.Message = "No hay conexión con la base de datos.";
            resp.Codigo.TimeStamp = DateTime.Now.ToString("HH:mm:ss tt");
            return resp;
        }

        // Construcción de SELECT con RestUtilities.QueryBuilder
        // WHERE:
        //   ST_CODIGO_TARJETA = <tarjeta>
        //   AND ST_FECHA_IMPRESION > 0
        //   AND ST_HORA_IMPRESION > 0
        //   AND COALESCE(ST_USUARIO_IMPRESION, '') <> ''
        // ORDER BY (para consistencia/determinismo)
        var qb = new SelectQueryBuilder("UNI5400", "S38FILEBA")
            .Select("ST_CODIGO_TARJETA", "ST_CENTRO_COSTO_IMPR_TARJETA", "ST_CENTRO_COSTO_APERTURA",
                    "ST_FECHA_IMPRESION", "ST_HORA_IMPRESION", "ST_USUARIO_IMPRESION")
            // Usamos SqlHelper.FormatValue para evitar inyección y formatear valores
            .WhereRaw($"ST_CODIGO_TARJETA = {SqlHelper.FormatValue(codigoTarjeta)}")
            .WhereRaw("ST_FECHA_IMPRESION > 0")
            .WhereRaw("ST_HORA_IMPRESION > 0")
            .WhereRaw("COALESCE(ST_USUARIO_IMPRESION, '') <> ''")
            .OrderBy(("ST_CODIGO_TARJETA", SortDirection.Asc),
                     ("ST_CENTRO_COSTO_IMPR_TARJETA", SortDirection.Asc),
                     ("ST_CENTRO_COSTO_APERTURA", SortDirection.Asc),
                     ("ST_FECHA_IMPRESION", SortDirection.Asc),
                     ("ST_HORA_IMPRESION", SortDirection.Asc),
                     ("ST_USUARIO_IMPRESION", SortDirection.Asc));

        var query = qb.Build();

        // Ejecutar
        using var cmd = _connection.GetDbCommand(query, _contextAccessor.HttpContext!);

        using DbDataReader reader = await cmd.ExecuteReaderAsync();

        if (reader.HasRows)
        {
            resp.Imprime = true;
            resp.Codigo.Status = "success";
            resp.Codigo.Error = "200";
            resp.Codigo.Message = "Tarjeta impresa";
            resp.Codigo.TimeStamp = DateTime.Now.ToString("HH:mm:ss tt");
            return resp;
        }

        resp.Imprime = false;
        resp.Codigo.Status = "success";
        resp.Codigo.Error = "200";
        resp.Codigo.Message = "Tarjeta no impresa";
        resp.Codigo.TimeStamp = DateTime.Now.ToString("HH:mm:ss tt");
        return resp;
    }
}

﻿using API_1_TERCEROS_REMESADORAS.Utilities;
using Connections.Abstractions;
using Microsoft.IdentityModel.Tokens;
using MS_BAN_43_Embosado_Tarjetas_Debito.Models.Dtos.Auth;
using System.Data.Common;
using System.Data.OleDb;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace MS_BAN_43_Embosado_Tarjetas_Debito.Services.SessionManagerService;

/// <summary>
/// Clase SessionManagerService encargada de validar si la sesión esta activa y de crear los claims para el JWT.
/// </summary>
/// <param name="_jwtService"></param>
/// <param name="_connection"></param>
/// <param name="_contextAccessor"></param>
public class SessionManagerService(IJwtService _jwtService, IDatabaseConnection _connection, IHttpContextAccessor _contextAccessor) : ISessionManagerService
{

    /// <inheritdoc />
    public async Task<(SecurityToken, string)> GenerateTokenAsync(LoginDto loginDto)
    {
        var secretKey = await _jwtService.GetSecretKeyAsync();
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secretKey));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        // Identidad (ajusta a tu realidad)
        var userId = loginDto.User; // o el que uses como único
        var sid = Guid.NewGuid().ToString("N"); // id de sesión
        var jti = Guid.NewGuid().ToString("N"); // id de token

        var claims = new List<Claim>
    {
        new(JwtRegisteredClaimNames.Sub, userId),
        new(ClaimTypes.NameIdentifier, userId),
        new("sid", sid),
        new(JwtRegisteredClaimNames.Jti, jti),
        // agrega roles / agencies si los necesitas como claims
    };

        var now = DateTime.UtcNow;
        var expires = now.AddMinutes(15); // expira en 15 min (ajusta a tu política)

        var descriptor = new SecurityTokenDescriptor
        {
            Subject = new ClaimsIdentity(claims),
            NotBefore = now,
            Expires = expires,
            SigningCredentials = creds
        };

        var handler = new JwtSecurityTokenHandler();
        var token = handler.CreateToken(descriptor);
        var jwt = handler.WriteToken(token);

        // (Opcional) guarda `sid` en tu tabla de sesiones; marca LOGB04SEA=0 (activa)
        // await SaveSessionAsync(userId, sid, expires);

        return (token, jwt);
    }

    /// <inheritdoc />
    public async Task InvalidateOldSessionAsync(string userID)
    {
        // Marca LOGB04SEA=1 (inactiva) para userID en BCAH96DTA.ETD02LOG
        // Puedes conservar timestamp de cierre.
        _connection.Open();

        string sql = "UPDATE BCAH96DTA.ETD02LOG SET LOGB04SEA = '1', LOGB05FCH = CURRENT_TIMESTAMP WHERE LOGB01UID = ?";
        using var cmd = _connection.GetDbCommand(_contextAccessor.HttpContext!);
        cmd.CommandText = sql;
        cmd.CommandType = System.Data.CommandType.Text;

        FieldsQueryL param = new();
        param.AddOleDbParameter(cmd, "LOGB01UID", OleDbType.Char, userID);

        await cmd.ExecuteNonQueryAsync();
    }

    /// <inheritdoc />
    public bool IsSessionActiveAsync(string usuarioRed)
    {
        FieldsQueryL param = new();

        //Validar si el token aun representa una session activa._
        _connection.Open();

        string sqlQuery = "SELECT * FROM BCAH96DTA.ETD02LOG WHERE LOGB01UID = ?";
        using var command = _connection.GetDbCommand(_contextAccessor.HttpContext!);
        command.CommandText = sqlQuery;
        command.CommandType = System.Data.CommandType.Text;

        param.AddOleDbParameter(command, "LOGB01UID", OleDbType.Char,usuarioRed);

        using DbDataReader reader = command.ExecuteReader();
        if (reader.HasRows)
        {
            while (reader.Read())
            {
                string valorDevuelto = reader.GetString(reader.GetOrdinal("LOGB04SEA"));
                if (valorDevuelto.Equals("0"))
                {
                    return true;
                }else if (valorDevuelto.Equals("1"))
                {
                    return false;
                }
                else if (valorDevuelto.IsNullOrEmpty())
                {
                    return false;
                }
            }
        }
        return false;
    }
}

﻿using Microsoft.IdentityModel.Tokens;
using MS_BAN_43_Embosado_Tarjetas_Debito.Models.Dtos.Auth;

namespace MS_BAN_43_Embosado_Tarjetas_Debito.Services.SessionManagerService;

/// <summary>
/// Interfaz SessionManagerService.
/// </summary>
public interface ISessionManagerService
{
    /// <summary>
    /// Invalida la Sesión del usuario.
    /// </summary>
    /// <param name="userID">Id de sesión de usuario a invalidar.</param>
    /// <returns></returns>
    /// <exception cref="NotImplementedException"></exception>
    Task InvalidateOldSessionAsync(string userID);

    /// <summary>
    /// Clase que Genera Token para JWT.
    /// </summary>
    /// <param name="loginDto">Objeto DTO de login necesario para generar los claims.</param>
    /// <returns></returns>
    Task<(SecurityToken, string)> GenerateTokenAsync(LoginDto loginDto);

    /// <summary>
    /// Valida si la sesión del usuario sigue activa.
    /// </summary>
    /// <param name="usuarioRed">Utilioza el usuario de Red para validar si la sesión esta activa.</param>
    /// <returns>Retorna boleano que inidca si la sesión esta activa o no.</returns>
    bool IsSessionActiveAsync(string usuarioRed);
}

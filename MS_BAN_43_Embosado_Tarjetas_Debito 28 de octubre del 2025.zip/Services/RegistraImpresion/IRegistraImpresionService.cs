﻿using MS_BAN_43_Embosado_Tarjetas_Debito.Models.Dtos.RegistraImpresion;

namespace MS_BAN_43_Embosado_Tarjetas_Debito.Services.RegistraImpresion;

/// <summary>
/// Servicio para registrar eventos de impresión de tarjetas.
/// </summary>
public interface IRegistraImpresionService
{
    /// <summary>
    /// Registra la impresión en las tablas correspondientes.
    /// </summary>
    /// <param name="postRegistraImpresionDto">Datos necesarios para el registro.</param>
    /// <returns><see langword="true"/> si el registro fue exitoso; en caso contrario <see langword="false"/>.</returns>
    Task<bool> RegistraImpresion(PostRegistraImpresionDto postRegistraImpresionDto);
}

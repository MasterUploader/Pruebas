﻿using Connections.Abstractions;
using MS_BAN_43_Embosado_Tarjetas_Debito.Models.Dtos.RegistraImpresion;
using MS_BAN_43_Embosado_Tarjetas_Debito.Repository.IRepository.RegistraImpresion;

namespace MS_BAN_43_Embosado_Tarjetas_Debito.Services.RegistraImpresion;

/// <summary>
/// Implementación del servicio de registro de impresión.
/// </summary>
/// <param name="_connection">Conexión a base de datos (AS/400).</param>
/// <param name="_contextAccessor">Accessor del contexto HTTP (opcional para logging/trazabilidad).</param>
public class RegistraImpresionService(IDatabaseConnection _connection, IHttpContextAccessor _contextAccessor)
    : IRegistraImpresionService
{
    /// <inheritdoc />
    public async Task<bool> RegistraImpresion(PostRegistraImpresionDto postRegistraImpresionDto)
    {
        var repo = new RegistraImpresionRepository(_connection, _contextAccessor);
        // No hay I/O previo aquí; mantenemos la firma async por consistencia.
        await Task.Yield();

        repo.GuardaImpresionUNI5400(postRegistraImpresionDto, out bool exito);
        return exito;
    }
}

﻿using Newtonsoft.Json;

namespace MS_BAN_43_Embosado_Tarjetas_Debito.Models.Dtos;

/// <summary>
/// Clase objeto Dto RespuestaGenericaDto
/// </summary>
public class RespuestaGenericaDto
{
    /// <summary>
    /// Elemento Status.
    /// </summary>
    [JsonProperty("status")]
    public string Status { get; set; } = string.Empty;

    /// <summary>
    /// Elemento Message.
    /// </summary>
    [JsonProperty("message")]
    public string Message { get; set; } = string.Empty;

    /// <summary>
    /// Elemento Data.
    /// </summary>
    [JsonProperty("data")]
    public string Data { get; set; } = string.Empty;

    /// <summary>
    /// Elemento Timestamp
    /// </summary>
    [JsonProperty("timestamp")]
    public string TimeStamp { get; set; } = string.Empty;
}


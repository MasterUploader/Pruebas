﻿using Logging.Attributes;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace MS_BAN_43_Embosado_Tarjetas_Debito.Models.Dtos.RegistraImpresion;

/// <summary>
/// Clase PostRegistraImpresiónDto
/// </summary>
public class PostRegistraImpresionDto
{
    /// <summary>
    /// Número de tarjeta a registra.
    /// </summary>
    [Required(ErrorMessage = "El Numero de Tarjeta es necesario para la consulta")]
    [JsonProperty("numeroTarjeta")]
    [LogFileName("TarjetaRegistrada")]
    public string NumeroTarjeta { get; set; } = string.Empty;

    /// <summary>
    /// Nombre de usuario en ICBS que realizo la impresión.
    /// </summary>
    [Required(ErrorMessage = "El usuario de ICBS es necesario para la consulta")]
    [JsonProperty("usuarioICBS")]
    [LogFileName("UsuarioRegistra")]
    public string UsuarioICBS { get; set; } = string.Empty;

    /// <summary>
    /// Nombre que se imprimio en la tarjeta.
    /// </summary>
    [JsonProperty("nombreEnTarjeta")]
    public string NombreEnTarjeta { get; set; } = string.Empty;
}

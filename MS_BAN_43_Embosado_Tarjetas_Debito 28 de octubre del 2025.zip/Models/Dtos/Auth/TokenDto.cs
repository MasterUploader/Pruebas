﻿using Newtonsoft.Json;

namespace MS_BAN_43_Embosado_Tarjetas_Debito.Models.Dtos.Auth;

/// <summary>
/// Clase estructura TokenDto.
/// </summary>
public class TokenDto
{
    /// <summary>
    /// String que corresponde al token de seguridad.
    /// </summary>
    [JsonProperty("token")]
    public string Token { get; set; } = string.Empty;

    /// <summary>
    /// Tiempo de expiración del token de seguridad.
    /// </summary>
    [JsonProperty("expiration")]
    public DateTime Expiration { get; set; }
}

﻿using MS_BAN_43_Embosado_Tarjetas_Debito.Models.Dtos.Auth;
using MS_BAN_43_Embosado_Tarjetas_Debito.Models.Dtos.DetalleTarjetaImprimir;
using Newtonsoft.Json;

namespace MS_BAN_43_Embosado_Tarjetas_Debito.Models.Dtos.Heartbeat;

/// <summary>
/// Clase DTO GetHeartbeatDto, representa el objeto necesario para mantener activa una sesión.
/// </summary>
public class GetHeartbeatDto
{
    /// <summary>
    /// Token de la sesión.
    /// </summary>
    [JsonProperty("token")]
    public TokenDto Token { get; set; } = new();

    /// <inheritdoc/>
    [JsonProperty("codigo")]
    public Codigo Codigo { get; set; } = new();
}

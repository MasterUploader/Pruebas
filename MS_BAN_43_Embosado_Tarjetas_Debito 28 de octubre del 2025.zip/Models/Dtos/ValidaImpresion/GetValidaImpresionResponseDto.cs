﻿using Newtonsoft.Json;

namespace MS_BAN_43_Embosado_Tarjetas_Debito.Models.Dtos.ValidaImpresion;

/// <summary>
/// Clase DTO GetValidaImprsion
/// </summary>
public class GetValidaImpresionResponseDto
{
    /// <summary>
    /// Estado de la validación de la impresión.
    /// </summary>
    [JsonProperty("imprime")]
    public bool Imprime { get; set; }

    /// <inheritdoc />
    [JsonProperty("codigo")]
    public CodigoDto Codigo { get; set; } = new();
}


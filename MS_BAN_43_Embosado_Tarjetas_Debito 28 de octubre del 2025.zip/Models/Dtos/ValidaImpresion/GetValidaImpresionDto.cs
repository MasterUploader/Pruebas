﻿using Logging.Attributes;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace MS_BAN_43_Embosado_Tarjetas_Debito.Models.Dtos.ValidaImpresion;

/// <summary>
/// Clase objeto Dto
/// </summary>
public class GetValidaImpresionDto
{
    /// <summary>
    /// Código de Tarjeta a validar.
    /// </summary>
    [Required(ErrorMessage = "El bin es necesario para la consulta")]
    [JsonProperty("codigoTarjeta")]
    [LogFileName("TarjetaValidadaImpresion")]
    public string CodigoTarjeta { get; set; } = string.Empty;

}

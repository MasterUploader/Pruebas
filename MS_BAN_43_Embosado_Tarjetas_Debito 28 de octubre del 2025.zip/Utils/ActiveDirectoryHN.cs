﻿namespace MS_BAN_43_Embosado_Tarjetas_Debito.Utils;

/// <summary>
/// Clase utilitaria que se Encarga de validar la existencia del Dominio y el ActiveDirectory en el arechivo de Configuración.
/// </summary>
public class ActiveDirectoryHN
{
    /// <summary>
    /// Método que se encarga de Validar la existencia del activeDirectory y el dominio en el archivo de configuración.
    /// </summary>
    /// <param name="domainName">String que corresponde al Dominio, es parametro de salida.</param>
    /// <param name="activeDirectory">String que corresponde al AD, es parametro de salida.</param>
    /// <returns>Retorna un boleano que indica si existe el domino y el AD.</returns>
    public bool GetActiveDirectory(out string domainName, out string activeDirectory)
    {
        var parms = new
        {
            domainName = GlobalConnection.Current.Domain,
            activeDirectory = GlobalConnection.Current.ActiveDirectory
        };

        if (!string.IsNullOrEmpty(parms.domainName) && !string.IsNullOrEmpty(parms.activeDirectory))
        {
            domainName = parms.domainName;
            activeDirectory = parms.activeDirectory;

            return true;
        }

        domainName = "";
        activeDirectory = "";

        return false;
    }
}

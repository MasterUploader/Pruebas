﻿namespace MS_BAN_43_Embosado_Tarjetas_Debito.Utils;

using Microsoft.AspNetCore.Mvc;

/// <summary>
/// Clase ResponseHandler, se encarga de validar la respuesta Http
/// </summary>
public class ResponseHandler
{
    private readonly Dictionary<string, Func<object, IActionResult>> responseActions;

    /// <summary>
    /// Constructor
    /// </summary>
    public ResponseHandler()
    {
        responseActions = new Dictionary<string, Func<object, IActionResult>>(StringComparer.OrdinalIgnoreCase)
    {
            { "success", HandleOk },
            { "OK", HandleOk },
            { "Created", HandleCreated },
            { "Accepted", HandleAccepted },
            { "NoContent", HandleNoContent },
            { "BadRequest", HandleBadRequest },
            { "Unauthorized", HandleUnauthorized },
            { "Forbidden", HandleForbidden },
            { "NotFound", HandleNotFound },
            { "PayloaToLarge", HandlePayloadToLarge },
            { "Conflict", HandleConflict },
            { "BadGateway", HandleBadGateway },
            { "InternalServerError", HandleInternalServerError },
            { "NotModified", HandleNotModified },

    };
    }

    /// <summary>
    /// Método HandleResponse, se encarga de determinar el método privado a devolver.
    /// </summary>
    /// <param name="response"></param>
    /// <param name="statusCode"></param>
    /// <returns></returns>
    /// <exception cref="ArgumentNullException"></exception>
    public IActionResult HandleResponse(object response, string statusCode)
    {
        if (response == null)
        {
            throw new ArgumentNullException(nameof(response));
        }

        if (responseActions.TryGetValue(statusCode, out var action))
        {
            return action(response);
        }

        // Si el código de estado no se encuentra en el diccionario, devuelve un resultado genérico.
        return new StatusCodeResult(500);
    }

    private static IActionResult HandleOk(object response)
    {
        return new OkObjectResult(response);
    }

    private static IActionResult HandleCreated(object response)
    {
        return new CreatedResult("", response);
    }

    private static IActionResult HandleAccepted(object response)
    {
        return new AcceptedResult("", response);
    }

    private IActionResult HandleNoContent(object response)
    {
        var noContent = new ObjectResult(response)
        {
            StatusCode = 204
        };

        return noContent;
    }

    private static IActionResult HandleBadRequest(object response)
    {
        return new BadRequestObjectResult(response);
    }

    private static IActionResult HandleUnauthorized(object response)
    {
        return new UnauthorizedObjectResult(response);
    }

    private IActionResult HandleForbidden(object response)
    {
        var forbiddenResult = new ObjectResult(response)
        {
            StatusCode = 403
        };

        return forbiddenResult;
    }

    private static IActionResult HandleNotFound(object response)
    {
        return new NotFoundObjectResult(response);
    }

    private IActionResult HandlePayloadToLarge(object response)
    {
        var payloadToLarge = new ObjectResult(response)
        {
            StatusCode = 413
        };
        return payloadToLarge;
    }

    private static IActionResult HandleConflict(object response)
    {
        return new ConflictObjectResult(response);
    }

    private static IActionResult HandleInternalServerError(object response)
    {
        return new ObjectResult(response)
        {
            StatusCode = 500,
        };
    }

    private static IActionResult HandleBadGateway(object response)
    {
        return new ObjectResult(response)
        {
            StatusCode = 502,
        };
    }

    private static IActionResult HandleNotModified(object response)
    {
        return new ObjectResult(response)
        {
            StatusCode = 304,
        };
    }
}


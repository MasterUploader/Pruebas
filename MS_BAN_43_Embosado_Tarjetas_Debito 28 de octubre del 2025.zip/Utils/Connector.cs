﻿using SUNITP.LIB.DataBaseCustomConfiguration;
using SUNITP.LIB.DataBaseCustomConfiguration.Configuration;

namespace MS_BAN_43_Embosado_Tarjetas_Debito.Utils;

/// <summary>
/// 
/// </summary>
public class Connector
{
    private readonly ServiceDataBaseCustomConfiguration db;

    /// <summary>
    /// 
    /// </summary>
    public CurrentCustomConfigsResponse Connect { get; set; } = default!;

    /// <summary>
    /// Constructor de la Clase Conector, al crear una instancia de esta clase, se crea automaticamente la conexion con la Base de Datos. 
    /// </summary>
    public Connector()
    {
        var connectionData = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("ConnectionData.json").Build();
        var appSettings = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json").Build();
        var ambiente = appSettings.GetSection("ApiSettings:Enviroment").Value;

        var parms = new
        {
            keyDecrypt = connectionData.GetSection("AppSettings" + ambiente + ":KeyDecrypt").Value,
            DriverConnection = connectionData.GetSection("AppSettings" + ambiente + ":DriverConnection").Value,
            dataSource = connectionData.GetSection("AppSettings" + ambiente + ":ServerName").Value,
            user = connectionData.GetSection("AppSettings" + ambiente + ":User").Value,
            password = connectionData.GetSection("AppSettings" + ambiente + ":Password").Value
        };

        db = new ServiceDataBaseCustomConfiguration(parms.DriverConnection, parms.dataSource, parms.user, parms.password);
        db.CreateConnection(true, parms.keyDecrypt);
    }

    /// <summary>
    /// 
    /// </summary>
    public void Open()
    {
        Connect = db.GetConnection();

    }

    /// <summary>
    /// 
    /// </summary>
    public void Close()
    {
        db.DropConnection();
    }
}

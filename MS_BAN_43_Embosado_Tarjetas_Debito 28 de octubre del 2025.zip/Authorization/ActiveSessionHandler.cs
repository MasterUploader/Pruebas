﻿using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using MS_BAN_43_Embosado_Tarjetas_Debito.Services.SessionManagerService;

namespace MS_BAN_43_Embosado_Tarjetas_Debito.Authorization;

/// <summary>
/// Handler que valida si la sesión del usuario sigue activa en AS400.
/// Usa ISessionManagerService.IsSessionActiveAsync(userId).
/// </summary>
/// <remarks>
/// Constructor que inyecta ISessionManagerService.
/// </remarks>
/// <param name="sessionManager"></param>
public class ActiveSessionHandler(ISessionManagerService sessionManager) : AuthorizationHandler<ActiveSessionRequirement>
{
    private readonly ISessionManagerService _sessionManager = sessionManager;

    /// <summary>
    /// Método que maneja la validación del requisito de sesión activa.
    /// </summary>
    /// <param name="context"></param>
    /// <param name="requirement"></param>
    /// <returns></returns>
    protected override async Task HandleRequirementAsync(
        AuthorizationHandlerContext context,
        ActiveSessionRequirement requirement)
    {
        await Task.Yield(); // Para evitar advertencias de método async sin await.

        var userId = context.User.FindFirstValue(ClaimTypes.NameIdentifier)
                     ?? context.User.Identity?.Name;

        if (string.IsNullOrWhiteSpace(userId))
            return;

        bool isActive =  _sessionManager.IsSessionActiveAsync(userId); //Este deberia de ser async

        if (isActive)
            context.Succeed(requirement);
    }
}

/// <summary>
/// Requisito vacío para la política "ActiveSession".
/// </summary>
public class ActiveSessionRequirement : IAuthorizationRequirement { }
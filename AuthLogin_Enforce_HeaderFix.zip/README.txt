1) Este patch obliga a que, al abrir la app, la ruta raíz redirija a /login.
2) El AuthStore ahora sólo marca autenticado si el JWT se decodifica correctamente y no está expirado.
   - Si había un token inválido en localStorage, se limpiará automáticamente.
3) Para la barra superior duplicada:
   - Revisa que NINGUNA página (inicio/impresión/etc.) incluya <ui-header> en su HTML.
     El header debe vivir sólo en app.component.html (o en el shell/layout).
   - Mientras corriges las plantillas, puedes incluir en src/styles.scss:
       @use 'styles/patch-header';

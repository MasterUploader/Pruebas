import { Injectable, signal } from '@angular/core';
import { decodeJwt, isExpired } from './auth.helpers';

/** Store de autenticación basado en Signals. */
@Injectable({ providedIn: 'root' })
export class AuthStore {
  private _token = signal<string | null>(localStorage.getItem('token'));
  readonly token = this._token.asReadonly();

  private _user = signal<{ name?: string; roles?: string[] } | null>(null);
  readonly user = this._user.asReadonly();

  readonly isAuthenticated = signal<boolean>(false);

  constructor() { this.hydrate(); }

  /** Reconstruye el estado desde el token actual. Sólo valida si el payload es decodificable y no está expirado. */
  hydrate() {
    const t = this._token();
    const payload = t ? decodeJwt(t) : null;

    // Si no hay token o no se pudo decodificar o expiró => limpiar y salir
    if (!t || !payload || isExpired(t)) {
      this.clear();
      return;
    }

    const roles = Array.isArray(payload['role']) ? payload['role'] as string[]
                  : (payload['role'] ? [payload['role']] : []);

    this._user.set({
      name: (payload['name'] || payload['unique_name'] || payload['sub'] || 'Usuario') as string,
      roles
    });
    this.isAuthenticated.set(true);
  }

  /** Establece token y lo persiste (por defecto). */
  setToken(token: string, persist = true) {
    this._token.set(token);
    if (persist) localStorage.setItem('token', token);
    this.hydrate();
  }

  /** Limpia sesión por completo. */
  clear() {
    this._token.set(null);
    this._user.set(null);
    this.isAuthenticated.set(false);
    localStorage.removeItem('token');
  }
}

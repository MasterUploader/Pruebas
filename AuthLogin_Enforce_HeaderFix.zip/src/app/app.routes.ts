import { Routes } from '@angular/router';
import { authGuard } from './core/auth/auth.guard';

export const routes: Routes = [
  // Al iniciar, si no hay sesión, se mostrará /login
  { path: '', pathMatch: 'full', redirectTo: 'login' },

  {
    path: 'login',
    loadComponent: () => import('./features/auth/pages/login/login-page/login-page')
      .then(m => m.LoginPage)
  },
  {
    path: 'inicio',
    canActivate: [authGuard],
    data: { breadcrumb: 'Inicio' },
    loadComponent: () => import('./features/inicio/pages/inicio-page/inicio-page')
      .then(m => m.InicioPage)
  },
  {
    path: 'impresion',
    canActivate: [authGuard],
    data: { breadcrumb: 'Impresión' },
    loadComponent: () => import('./features/impresion/pages/impresion-page/impresion-page')
      .then(m => m.ImpresionPage)
  },
  { path: '**', redirectTo: 'login' }
];

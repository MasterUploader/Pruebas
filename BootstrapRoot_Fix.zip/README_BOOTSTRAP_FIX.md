Este parche agrega los archivos mínimos de *bootstrap* para evitar la pantalla en blanco:

- `src/app/app.component.ts` (standalone) con `<router-outlet/>`
- `src/main.ts` usando `bootstrapApplication(AppComponent, appConfig)`
- `src/index.html` con `<app-root>` y `<base href="/">`
- (Opcional) `app.config.ts` con `provideRouter` + interceptores

Si ya tienes alguno de estos archivos, este parche los puede sobreescribir; ajusta manualmente si lo prefieres.

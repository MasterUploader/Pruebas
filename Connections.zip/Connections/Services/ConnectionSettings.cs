﻿using Connections.Helpers;
using Connections.Models;
using Microsoft.Extensions.Configuration;
using System.Text;

namespace Connections.Services;

/// <summary>
/// Gestiona la configuración de conexiones según el ambiente actual.
/// </summary>
public class ConnectionSettings
{
    private readonly IConfiguration _configuration;

    public ConnectionSettings(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    public IConfigurationSection CurrentEnvironment =>
        _configuration.GetSection(_configuration["ApiSettings:Enviroment"] ?? "DEV");

    /// <summary>
    /// Construye dinámicamente la cadena de conexión al AS400 desde campos individuales.
    /// </summary>
    /// <param name="connectionName">Nombre de la conexión (ej. "AS400").</param>
    public string GetAS400ConnectionString(string connectionName)
    {
        // Obtener sección actual del ambiente (DEV, UAT, PROD)
        var section = CurrentEnvironment
            .GetSection("ConnectionSettings")
            .GetSection(connectionName);

        string driver = section["DriverConnection"];
        string server = section["ServerName"];
        string userEncoded = section["User"];
        string passEncoded = section["Password"];
        string encryptionType = section["EncryptionType"] ?? "Base64";
        string keyDecrypt = section["KeyDecrypt"] ?? "";

        // Desencriptar dinámicamente
        string user = EncryptionHelper.Decrypt(userEncoded, encryptionType, keyDecrypt);
        string password = EncryptionHelper.Decrypt(passEncoded, encryptionType, keyDecrypt);
        return $"Provider={driver};Data Source={server};User ID={user};Password={password};";
    }

    /// <summary>
    /// Genera la cadena de conexión compatible con IBM.EntityFrameworkCore para AS400.
    /// </summary>
    /// <param name="connectionName">Nombre de la conexión (ej. AS400_DBContext)</param>
    public string GetEfCoreConnectionString(string connectionName)
    {
        var section = CurrentEnvironment.GetSection("ConnectionSettings").GetSection(connectionName);

        string server = section["Server"];
        string database = section["Database"];
        string user = EncryptionHelper.Decrypt(section["User"], section["EncryptionType"], section["KeyDecrypt"]);
        string password = EncryptionHelper.Decrypt(section["Password"], section["EncryptionType"], section["KeyDecrypt"]);

        return $"Server={server};Database={database};UID={user};PWD={password};";
    }


    /// <summary>
    /// Obtiene configuración completa para un servicio externo.
    /// </summary>
    public IConfigurationSection GetServiceConfig(string serviceName)
    {
        return CurrentEnvironment.GetSection("Services").GetSection(serviceName);
    }

}

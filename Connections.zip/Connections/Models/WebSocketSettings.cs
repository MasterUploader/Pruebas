﻿namespace Connections.Models
{
    /// <summary>
    /// Configuración para conexiones WebSocket.
    /// </summary>
    public class WebSocketSettings
    {
        /// <summary>
        /// URL del servidor WebSocket.
        /// </summary>
        public string Url { get; set; }

        /// <summary>
        /// Indica si la conexión debe mantenerse abierta.
        /// </summary>
        public bool KeepAlive { get; set; }
    }
}

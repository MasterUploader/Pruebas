﻿namespace Connections.Models
{
    /// <summary>
    /// Representa la información general de una conexión.
    /// </summary>
    public class ConnectionInfo
    {
        /// <summary>
        /// Nombre de la conexión.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Tipo de conexión (Ejemplo: "MSSQL", "AS400", "Redis", "RabbitMQ").
        /// </summary>
        public string Type { get; set; }

        /// <summary>
        /// Cadena de conexión completa si aplica.
        /// </summary>
        public string ConnectionString { get; set; }
    }
}

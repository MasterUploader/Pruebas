﻿namespace Connections.Models
{
    /// <summary>
    /// Configuración específica para conexiones a bases de datos relacionales.
    /// </summary>
    public class DatabaseSettings
    {
        /// <summary>
        /// Dirección del servidor de base de datos.
        /// </summary>
        public string Host { get; set; }

        /// <summary>
        /// Nombre de la base de datos.
        /// </summary>
        public string DatabaseName { get; set; }

        /// <summary>
        /// Nombre de usuario para autenticación.
        /// </summary>
        public string Username { get; set; }

        /// <summary>
        /// Contraseña de acceso a la base de datos.
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// Indica si la conexión debe utilizar SSL.
        /// </summary>
        public bool UseSSL { get; set; }
    }
}

﻿namespace Connections.Models
{
    /// <summary>
    /// Configuración para conexiones gRPC.
    /// </summary>
    public class GrpcSettings
    {
        /// <summary>
        /// Dirección del servidor gRPC.
        /// </summary>
        public string ServerAddress { get; set; }

        /// <summary>
        /// Indica si debe usarse autenticación TLS.
        /// </summary>
        public bool UseTLS { get; set; }
    }
}

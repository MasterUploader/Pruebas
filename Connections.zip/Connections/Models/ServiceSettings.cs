﻿namespace Connections.Models
{
    /// <summary>
    /// Configuración para servicios externos REST y SOAP.
    /// </summary>
    public class ServiceSettings
    {
        /// <summary>
        /// URL base del servicio.
        /// </summary>
        public string BaseUrl { get; set; }

        /// <summary>
        /// Tipo de servicio (Ejemplo: "REST", "SOAP").
        /// </summary>
        public string ServiceType { get; set; }

        /// <summary>
        /// API Key si aplica.
        /// </summary>
        public string ApiKey { get; set; }

        /// <summary>
        /// Indica si debe usarse autenticación OAuth.
        /// </summary>
        public bool UseOAuth { get; set; }
    }
}

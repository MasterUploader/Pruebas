﻿namespace Connections.Providers.Database
{
    internal class RedisConnectionProvider
    {
    }
}

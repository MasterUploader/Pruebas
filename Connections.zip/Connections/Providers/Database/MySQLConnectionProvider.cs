﻿namespace Connections.Providers.Database
{
    internal class MySQLConnectionProvider
    {
    }
}

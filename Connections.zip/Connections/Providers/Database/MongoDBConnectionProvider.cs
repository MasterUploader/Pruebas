﻿namespace Connections.Providers.Database
{
    internal class MongoDBConnectionProvider
    {
    }
}

﻿namespace Connections.Providers.Database
{
    internal class PostgreSQLConnectionProvider
    {
    }
}

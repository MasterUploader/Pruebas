﻿using Connections.Interfaces;
using FluentFTP;

namespace Connections.Providers.Services
{
    /// <summary>
    /// Cliente para conexiones FTP/SFTP.
    /// </summary>
    public class FtpConnectionProvider : IFtpConnection
    {
        private readonly FtpClient _ftpClient;

        public FtpConnectionProvider(string server, string user, string password)
        {
           _ftpClient = new FtpClient(server, user, password);
        }

        public async Task UploadFileAsync(string filePath, string destinationPath)
        {
            await Task.Run(() => {
                _ftpClient.Connect();
                _ftpClient.UploadFile(filePath, destinationPath, FtpRemoteExists.Overwrite);
                _ftpClient.Disconnect();
            });
             
        }

        public async Task DownloadFileAsync(string remotePath, string localPath)
        {
            await Task.Run(() => {
                _ftpClient.Connect();
                _ftpClient.DownloadFile(localPath, remotePath);
                _ftpClient.Disconnect();
            });
        }

        /// <summary>
        /// Libera los recursos del proveedor de conexión FTP.
        /// </summary>
        public void Dispose()
        {
            _ftpClient.Dispose();
        }
    }
}

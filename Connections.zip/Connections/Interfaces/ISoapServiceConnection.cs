﻿namespace Connections.Interfaces
{
    /// <summary>
    /// Define los métods estándar para conexiones a servicios SOAP
    /// </summary>
    public interface ISoapServiceConnection : IDisposable
    {
        Task<HttpResponseMessage> CallSoapServiceAsync(string soapAction, string xmlBody);
    }
}

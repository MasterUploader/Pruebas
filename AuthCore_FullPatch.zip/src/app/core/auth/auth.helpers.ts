/**
 * Decodifica (sin validar firma) el payload de un JWT.
 * Devuelve null si el token es inválido.
 */
export function decodeJwt(token: string | null): any | null {
  if (!token) return null;
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  try {
    const json = atob(parts[1].replace(/-/g, '+').replace(/_/g, '/'));
    return JSON.parse(decodeURIComponent(escape(json)));
  } catch {
    try { return JSON.parse(atob(parts[1])); } catch { return null; }
  }
}

/** Indica si el JWT está expirado comparando 'exp' con el tiempo actual. */
export function isExpired(token: string | null): boolean {
  const payload = decodeJwt(token);
  if (!payload || typeof payload.exp !== 'number') return false;
  const now = Math.floor(Date.now() / 1000);
  return payload.exp <= now;
}

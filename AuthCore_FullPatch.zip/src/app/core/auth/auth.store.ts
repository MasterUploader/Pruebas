import { Injectable, signal } from '@angular/core';
import { decodeJwt, isExpired } from './auth.helpers';

/** Store de autenticación basado en Signals. */
@Injectable({ providedIn: 'root' })
export class AuthStore {
  private _token = signal<string | null>(localStorage.getItem('token'));
  readonly token = this._token.asReadonly();

  private _user = signal<{ name?: string; roles?: string[] } | null>(null);
  readonly user = this._user.asReadonly();

  readonly isAuthenticated = signal<boolean>(false);

  constructor() { this.hydrate(); }

  /** Reconstruye el estado desde el token actual. */
  hydrate() {
    const t = this._token();
    if (!t || isExpired(t)) { this.clear(); return; }
    const p = decodeJwt(t) ?? {};
    const roles = Array.isArray(p['role']) ? (p['role'] as string[]) : (p['role'] ? [p['role']] : []);
    this._user.set({ name: p['name'] || p['unique_name'] || p['sub'] || 'Usuario', roles });
    this.isAuthenticated.set(true);
  }

  /** Establece token y lo persiste (por defecto). */
  setToken(token: string, persist = true) {
    this._token.set(token);
    if (persist) localStorage.setItem('token', token);
    this.hydrate();
  }

  /** Limpia sesión por completo. */
  clear() {
    this._token.set(null);
    this._user.set(null);
    this.isAuthenticated.set(false);
    localStorage.removeItem('token');
  }
}

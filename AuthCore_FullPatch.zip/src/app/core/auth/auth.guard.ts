import { CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';
import { AuthStore } from './auth.store';
import { isExpired } from './auth.helpers';

/** Guarda de ruta: exige token válido. Redirige a /login si no hay sesión. */
export const authGuard: CanActivateFn = (route, state) => {
  const store = inject(AuthStore) as AuthStore; // tipado explícito por si falla la inferencia
  const router = inject(Router);

  const token = store.token();
  const ok = !!token && !isExpired(token);
  if (!ok) {
    store.clear();
    router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
    return false;
  }
  return true;
};

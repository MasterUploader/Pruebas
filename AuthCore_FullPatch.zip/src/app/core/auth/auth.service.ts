import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { AuthStore } from './auth.store';

export interface LoginRequest { username: string; password: string; remember?: boolean; }
export interface LoginResponse { token: string; }

/** Servicio de autenticación contra el backend. */
@Injectable({ providedIn: 'root' })
export class AuthService {
  private http = inject(HttpClient);
  private store = inject(AuthStore);

  login(payload: LoginRequest): Observable<LoginResponse> {
    return this.http.post<LoginResponse>('/auth/login', payload).pipe(
      tap(resp => this.store.setToken(resp.token, payload.remember !== false))
    );
  }

  logout() { this.store.clear(); }
}

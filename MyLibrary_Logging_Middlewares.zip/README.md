# MyLibrary.Logging - Guía de Integración

## 📌 Archivos a Modificar en la Librería
### **1️⃣ `LoggingConfiguration.cs` (En `MyLibrary.Logging.Abstractions`)**
- Contiene las configuraciones necesarias para definir el nivel de log y la ubicación de los archivos de log.
- Si necesitas más configuraciones, agrégalas aquí.

### **2️⃣ `Logger.cs` (En `MyLibrary.Logging.Services`)**
- Se encarga de escribir logs en archivos con nombres basados en `ExecutionId`, fecha y endpoint.
- Captura automáticamente la IP del usuario, navegador, sistema operativo, método HTTP, ruta y más.
- Si necesitas modificar el formato del log o agregar más datos, edita esta clase.

### **3️⃣ `ExceptionHandlingMiddleware.cs` (En `MyLibrary.Logging.Helpers`)**
- Captura todas las excepciones no manejadas dentro del API.
- Guarda detalles como el tipo de error, mensaje, stack trace, IP del usuario y endpoint donde ocurrió.
- Si deseas personalizar la respuesta en caso de error, edita esta clase.

---

## 📌 Código a Agregar en la API que Consuma la Librería

### **1️⃣ Configuración en `appsettings.json`**
Asegúrate de incluir la configuración de logging en `appsettings.json`:

```json
{
  "LoggingConfig": {
    "MinimumLogLevel": "Info",
    "LogFilePath": "logs/"
  }
}
```

### **2️⃣ Configuración en `Program.cs`**
Debes registrar `ILoggerService` y los middlewares necesarios:

```csharp
using Serilog;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using MyLibrary.Logging.Abstractions;
using MyLibrary.Logging.Services;
using MyLibrary.Logging.Helpers;

var builder = WebApplication.CreateBuilder(args);

// Cargar configuración de logging desde appsettings.json
var loggingConfig = builder.Configuration.GetSection("LoggingConfig").Get<LoggingConfiguration>();

// Configurar Serilog como logger principal
Log.Logger = new LoggerConfiguration()
    .WriteTo.Console()
    .WriteTo.File("logs/app.log", rollingInterval: RollingInterval.Day)
    .CreateLogger();

builder.Host.UseSerilog();
builder.Services.AddSingleton<ILoggerService>(new Logger(loggingConfig, new HttpContextAccessor()));

var app = builder.Build();
app.UseMiddleware<ExceptionHandlingMiddleware>();
app.UseMiddleware<ExecutionLoggingMiddleware>();

app.MapControllers();
app.Run();
```

✅ **Con estos cambios, la API estará lista para capturar logs automáticamente usando `MyLibrary.Logging`.**

Si necesitas personalizar la configuración o agregar más funcionalidades, revisa los archivos mencionados en la librería.

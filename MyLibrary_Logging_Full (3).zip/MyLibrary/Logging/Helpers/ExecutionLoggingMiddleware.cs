using Microsoft.AspNetCore.Http;
using System;
using System.Threading.Tasks;
using MyLibrary.Logging.Abstractions;

namespace MyLibrary.Logging.Helpers
{
    public class ExecutionLoggingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILoggerService _logger;

        public ExecutionLoggingMiddleware(RequestDelegate next, ILoggerService logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task Invoke(HttpContext context)
        {
            var executionId = Guid.NewGuid().ToString();
            context.Items["ExecutionId"] = executionId;

            await _logger.AddSingleLogAsync($"Execution Started: {executionId} - {context.Request.Method} {context.Request.Path}", LogLevel.Info);

            await _next(context);

            await _logger.AddSingleLogAsync($"Execution Completed: {executionId}", LogLevel.Info);
        }
    }
}
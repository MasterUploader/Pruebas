export const environment = {
  production: false,
  apiBase: 'http://localhost:5050'
};

# BiBImpresion FullKit (2025-11-19)

## Qué contiene
- **Enrutamiento** + **config** + **interceptores**
- **Feature Impresión** (servicio + página) con **paginación**
- **Componente de paginación** compartido
- **VisualKit SCSS** (tokens/base/utilities/components/print)
- **Compatibilidad legacy** (map, legacy colors, raw legacy layer)
- `styles.scss` conectado en el **orden correcto**

## Uso
1. Copia todo el contenido de este ZIP en la **raíz del proyecto** (la que contiene `src/`).
2. Revisa y ajusta:
   - `src/environments/environment*.ts` → `apiBase` por ambiente.
3. Ejecuta:
   ```bash
   npm start
   ```

## Notas
- El import lazy usa: `import('./features/impresion/pages/impresion-page/impresion-page').then(m => m.ImpresionPage)`
- Los **mixins** (`btn-base`, `form-control`, etc.) están a nivel raíz y se consumen con `@use`:
  ```scss
  @use '../components/button' as button;
  .mi-boton { '@' }include button.btn-base();
  ```
- Para **hash routing** (si lo necesitas), añade `withHashLocation()` en `app.config.ts`:
  ```ts
  import { provideRouter, withHashLocation } from '@angular/router';
  providers: [ provideRouter(routes, withHashLocation()), ... ]
  ```

## Migración visual
- Coloca tu CSS antiguo en `src/styles/legacy/_legacy-from-old.scss` y/o usa el mapeo en `src/styles/legacy/_legacy-map.generated.scss`.
- Si tienes un set de tokens legado generado automáticamente, pégalo en `src/styles/tokens/_legacy-colors.scss`.

¡Listo para trabajar!

# Copia todos los archivos del kit a la raíz del proyecto actual.
param([string]$ProjectRoot = ".")
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Copy-Item -Path (Join-Path $here "src") -Destination (Resolve-Path $ProjectRoot) -Recurse -Force
Copy-Item -Path (Join-Path $here "apply.ps1") -Destination (Resolve-Path $ProjectRoot) -Force
Copy-Item -Path (Join-Path $here "README_FULLKIT.md") -Destination (Resolve-Path $ProjectRoot) -Force
Write-Host "FullKit aplicado. Ajusta environment.apiBase y ejecuta 'npm start'."

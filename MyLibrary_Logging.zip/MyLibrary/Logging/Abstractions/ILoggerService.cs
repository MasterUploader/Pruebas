namespace MyLibrary.Logging.Abstractions
{
    public interface ILoggerService
    {
        Task AddSingleLogAsync(string message, LogLevel level);
        Task AddDetailedObjectLogAsync(object obj, LogLevel level);
        Task LogExceptionAsync(Exception ex);
    }
}
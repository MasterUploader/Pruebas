import { Directive } from '@angular/core';

@Directive({
  selector: '[appAutofocus]'
})
export class Autofocus {

  constructor() { }

}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ImpresionPage } from './impresion-page';

describe('ImpresionPage', () => {
  let component: ImpresionPage;
  let fixture: ComponentFixture<ImpresionPage>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ImpresionPage]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ImpresionPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

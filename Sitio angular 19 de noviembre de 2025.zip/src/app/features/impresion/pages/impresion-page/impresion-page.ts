import { Component } from '@angular/core';

@Component({
  selector: 'app-impresion-page',
  imports: [],
  templateUrl: './impresion-page.html',
  styleUrl: './impresion-page.scss',
})
export class ImpresionPage {

}

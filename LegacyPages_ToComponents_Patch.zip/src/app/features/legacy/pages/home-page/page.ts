
import { Component, ViewEncapsulation } from '@angular/core';
import { CommonModule } from '@angular/common';

/** Migrado automáticamente desde legacy: BiBImpresionMatriculaMasivaClient/app/view/home.html */
@Component({
  selector: 'app-home-page',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './page.html',
  styleUrl: './page.scss',
  encapsulation: ViewEncapsulation.None
})
export class HomePage { }

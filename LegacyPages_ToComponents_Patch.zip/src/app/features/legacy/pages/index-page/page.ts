
import { Component, ViewEncapsulation } from '@angular/core';
import { CommonModule } from '@angular/common';

/** Migrado automáticamente desde legacy: BiBImpresionMatriculaMasivaClient/index.html */
@Component({
  selector: 'app-index-page',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './page.html',
  styleUrl: './page.scss',
  encapsulation: ViewEncapsulation.None
})
export class IndexPage { }

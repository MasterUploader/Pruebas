using Microsoft.AspNetCore.Http;
using System;
using System.Threading.Tasks;
using MyLibrary.Logging.Abstractions;

namespace MyLibrary.Logging.Helpers
{
    public class ExecutionLoggingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILoggerService _logger;

        public ExecutionLoggingMiddleware(RequestDelegate next, ILoggerService logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task Invoke(HttpContext context)
        {
            var executionId = Guid.NewGuid().ToString();
            context.Items["ExecutionId"] = executionId;

            await _logger.LogRequestDetailsAsync();

            var originalBodyStream = context.Response.Body;
            using var responseBodyStream = new MemoryStream();
            context.Response.Body = responseBodyStream;

            await _next(context);

            context.Response.Body.Seek(0, SeekOrigin.Begin);
            using var reader = new StreamReader(context.Response.Body);
            var responseBody = await reader.ReadToEndAsync();
            context.Response.Body.Seek(0, SeekOrigin.Begin);

            await _logger.LogResponseDetailsAsync(context, responseBody);
            await responseBodyStream.CopyToAsync(originalBodyStream);
        }
    }
}
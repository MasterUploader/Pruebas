import { Component, ViewEncapsulation, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { finalize } from 'rxjs';
import { Impresion, Matricula, PagedResult } from '../../services/impresion';
import { PaginationComponent } from '../../../../shared/components/pagination/pagination.component';
import { ConfirmComponent } from '../../../../shared/components/confirm/confirm.component';
import { exportToCsv } from '../../../../shared/utils/csv';

/** Página de Impresión con filtros, confirmación e exportación CSV. */
@Component({
  selector: 'app-impresion-page',
  standalone: true,
  imports: [CommonModule, PaginationComponent, ConfirmComponent],
  templateUrl: './impresion-page.html',
  styleUrl: './impresion-page.scss',
  encapsulation: ViewEncapsulation.None
})
export class ImpresionPage {
  private readonly api = inject(Impresion);

  readonly items = signal<Matricula[]>([]);
  readonly total = signal(0);
  readonly pageIndex = signal(1);
  readonly pageSize = signal(10);
  readonly loading = signal(false);

  // Filtros
  readonly documento = signal('');
  readonly agencia = signal<number | null>(null);
  readonly fechaDesde = signal<string>('');
  readonly fechaHasta = signal<string>('');

  // Estado de diálogo
  readonly confirmOpen = signal(false);
  private targetToPrint: Matricula | null = null;

  /** UI events */
  onDocumentoChange(ev: Event): void {
    const value = (ev.target as HTMLInputElement | null)?.value ?? '';
    this.documento.set(value);
  }
  onAgenciaChange(ev: Event): void {
    const v = (ev.target as HTMLInputElement | null)?.value ?? '';
    const num = v.trim() === '' ? null : Number(v);
    this.agencia.set(Number.isFinite(num as number) ? (num as number) : null);
  }
  onFechaDesdeChange(ev: Event): void { this.fechaDesde.set((ev.target as HTMLInputElement | null)?.value ?? ''); }
  onFechaHastaChange(ev: Event): void { this.fechaHasta.set((ev.target as HTMLInputElement | null)?.value ?? ''); }

  private isDateRangeValid(): boolean {
    const d1 = this.fechaDesde();
    const d2 = this.fechaHasta();
    if (!d1 || !d2) return true; // si no hay ambos, no validar
    return new Date(d1) <= new Date(d2);
  }

  buscar(): void {
    if (!this.isDateRangeValid()) {
      alert('Rango de fechas inválido: "Desde" debe ser menor o igual a "Hasta".');
      return;
    }
    this.loading.set(true);
    this.api.buscarPaged({
      documento: this.documento(),
      agencia: this.agencia() ?? undefined,
      fechaDesde: this.fechaDesde() || undefined,
      fechaHasta: this.fechaHasta() || undefined,
      page: this.pageIndex(),
      pageSize: this.pageSize()
    })
    .pipe(finalize(() => this.loading.set(false)))
    .subscribe((r: PagedResult<Matricula>) => {
      this.items.set(r.items);
      this.total.set(r.total);
    });
  }

  onPageChange(e: { pageIndex: number; pageSize: number }) {
    this.pageIndex.set(e.pageIndex);
    this.pageSize.set(e.pageSize);
    this.buscar();
  }

  solicitarImpresion(m: Matricula): void {
    this.targetToPrint = m;
    this.confirmOpen.set(true);
  }
  confirmarImpresion(): void {
    const m = this.targetToPrint;
    this.confirmOpen.set(false);
    if (!m) return;
    this.api.marcarImpresa(m.id).subscribe(() => {
      this.items.update(xs => xs.map(x => x.id === m.id ? { ...x, estado: 'IMPRESA' } : x));
      setTimeout(() => window.print(), 0);
    });
  }
  cancelarImpresion(): void {
    this.confirmOpen.set(false);
    this.targetToPrint = null;
  }

  exportarCsv(): void {
    exportToCsv('impresion_matriculas', this.items());
  }
}

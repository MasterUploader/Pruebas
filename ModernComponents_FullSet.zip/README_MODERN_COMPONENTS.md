Este paquete agrega componentes compartidos modernizados y los conecta al layout común:

- Header + Footer con ambiente y API base
- Breadcrumb basado en las rutas (usa data.breadcrumb si lo deseas)
- Loading overlay con interceptor HTTP (muestra mientras hay requests)
- Toasts globales (success/error/info/warn)
- DataTable simple con ordenamiento
- Wrappers de formulario (input/select)
- Card de impresión CR80
- AppComponent actualizado para usar el layout y contenedores

Tras copiar, no olvides reiniciar `ng serve`.

import { Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'ui-breadcrumb',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
  <nav class="breadcrumb container" aria-label="breadcrumb">
    <a routerLink="/inicio">Inicio</a>
    <ng-container *ngFor="let c of crumbs()">
      <span>/</span>
      <a *ngIf="!c.last" [routerLink]="c.url">{{c.label}}</a>
      <span *ngIf="c.last" class="current">{{c.label}}</span>
    </ng-container>
  </nav>
  `,
  styles: [`
  .breadcrumb { display:flex; align-items:center; gap:.5rem; color: var(--color-muted); font-size: var(--text-sm); margin: .75rem auto; }
  .breadcrumb a { color: var(--color-muted); text-decoration:none; }
  .breadcrumb a:hover { color: var(--color-fg); }
  .breadcrumb .current { color: var(--color-fg); font-weight: 600; }
  `]
})
export class BreadcrumbComponent {
  private router = inject(Router);
  private route = inject(ActivatedRoute);
  private _crumbs = signal<{label:string; url:string; last:boolean}[]>([]);

  crumbs = computed(() => this._crumbs());

  constructor(){
    this.router.events.pipe(filter(e => e instanceof NavigationEnd)).subscribe(() => {
      const acc: {label:string; url:string; last:boolean}[] = [];
      let route: ActivatedRoute | null = this.route.root;
      let url = '';
      while (route) {
        const child = route.firstChild;
        if (!child) break;
        route = child;
        const routeConfig = child.routeConfig;
        if (!routeConfig) continue;
        const path = routeConfig.path ?? '';
        url += `/${path}`;
        const label = (routeConfig.data as any)?.['breadcrumb'] ?? path || 'Inicio';
        if (label) acc.push({ label, url, last: false });
      }
      if (acc.length) acc[acc.length-1].last = true;
      this._crumbs.set(acc);
    });
  }
}

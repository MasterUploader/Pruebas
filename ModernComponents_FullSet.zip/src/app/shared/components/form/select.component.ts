import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'ui-select',
  standalone: true,
  imports: [CommonModule],
  template: `
  <label class="form-label" *ngIf="label">{{label}}</label>
  <select class="select" [value]="value" (change)="onChange($event)">
    <option *ngFor="let o of options" [value]="o.value">{{o.label}}</option>
  </select>
  <small class="help" *ngIf="help">{{help}}</small>
  `
})
export class SelectComponent {
  @Input() label?: string;
  @Input() help?: string;
  @Input() options: { value: string | number, label: string }[] = [];
  @Input() value: string | number | null = null;
  @Output() valueChange = new EventEmitter<string | number>();

  onChange(e: Event){
    const v = (e.target as HTMLSelectElement | null)?.value ?? '';
    this.value = v;
    this.valueChange.emit(v);
  }
}

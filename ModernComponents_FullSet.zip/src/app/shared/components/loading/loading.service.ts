import { Injectable, signal } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class LoadingService {
  private _count = signal(0);
  readonly active = this._count.asReadonly();

  show() { this._count.update(x => x + 1); }
  hide() { this._count.update(x => Math.max(0, x - 1)); }
  reset(){ this._count.set(0); }
}

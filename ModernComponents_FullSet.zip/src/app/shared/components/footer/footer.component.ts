import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { environment } from '../../../../environments/environment';

@Component({
  selector: 'ui-footer',
  standalone: true,
  imports: [CommonModule],
  template: `
  <footer class="footer">
    <div class="container footer__inner">
      <span>© {{year}} Banco Interno</span>
      <span class="footer__spacer"></span>
      <span class="env">Env: <b>{{env}}</b></span>
      <span class="api">API: <b>{{apiBase}}</b></span>
      <span class="ver">UI v{{version}}</span>
    </div>
  </footer>
  `,
  styles: [`
  .footer { margin-top: 2rem; border-top:1px solid var(--border); background: var(--surface); }
  .footer__inner { display:flex; align-items:center; gap:.75rem; padding: .75rem 0; color: var(--color-muted); font-size: var(--text-sm); }
  .footer__spacer { flex:1 1 auto; }
  `]
})
export class FooterComponent {
  year = new Date().getFullYear();
  env = environment.production ? 'PROD' : 'DEV';
  apiBase = environment.apiBase;
  version = '1.0.0'; // si usas versionado, puedes inyectarlo por file replacement
}

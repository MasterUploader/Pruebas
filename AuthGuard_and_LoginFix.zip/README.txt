1) Asegura el import en src/app/app.routes.ts:
   import { authGuard } from './core/auth/auth.guard';

2) Este patch añade el archivo del guard y corrige el HTML del login para evitar
   errores NGS002 por <td> fuera de contexto o sin comillas. Conserva las clases
   legacy (8u, 4u) pero ahora en <div> válidos para Angular.

import { Component, ViewEncapsulation } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-home-page',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './page.html',
  styleUrl: './page.scss',
  encapsulation: ViewEncapsulation.None
})
export class HomePage {
  metadata = {
    image: 'assets/placeholder.jpg',
    title: 'Bienvenido',
    description: 'Sistema de Impresión de Matrícula',
    content: ''
  };
  date = new Date();
  month = this.getMonth(this.date.getMonth());
  getMonth(m: number): string {
    const names = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
    return names[(m ?? 0) % 12];
  }
}

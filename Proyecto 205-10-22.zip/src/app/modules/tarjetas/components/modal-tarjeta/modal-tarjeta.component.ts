
import { Component, Input, Output, OnInit, Inject, EventEmitter, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatDialogModule, MatDialog } from '@angular/material/dialog';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { ErrorStateMatcher } from '@angular/material/core';
import { FormControl, FormGroupDirective } from '@angular/forms';

import { DomSanitizer } from '@angular/platform-browser';
import { Subscription } from 'rxjs';

import { Tarjeta } from '../../../../core/models/tarjeta.model';
import { ImpresionService } from '../../../../core/services/impresion.service';
import { TarjetaService } from '../../../../core/services/tarjeta.service';
import { AuthService } from '../../../../core/services/auth.service';
import { MaskAccountNumberPipe } from '../../../../shared/pipes/mask-account-number.pipe';

/**
 * ErrorStateMatcher personalizado:
 * Muestra mat-error cuando hay error externo (nombreError) o validación normal.
 */
class NombreErrorStateMatcher implements ErrorStateMatcher {
  constructor(private hasExternalError: () => boolean) { }
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const submitted = !!form && form.submitted;
    const invalidStd = !!control && control.invalid && (control.touched || control.dirty || submitted);
    return this.hasExternalError() || invalidStd;
  }
}

@Component({
  selector: 'app-modal-tarjeta',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatDialogModule,
    MatSelectModule,
    MatFormFieldModule,
    MatInputModule,
    MatSnackBarModule,
    MaskAccountNumberPipe,
    MatIconModule
  ],
  templateUrl: './modal-tarjeta.component.html',
  styleUrl: './modal-tarjeta.component.css'
})
export class ModalTarjetaComponent implements OnInit, OnDestroy {

  private readonly subscription: Subscription = new Subscription();
  private imprime: boolean;

  // Máximo de letras repetidas consecutivas permitidas
  private readonly MAX_REPEAT = 3;

  @Output() nombreCambiado = new EventEmitter<string>();

  @Input() datosTarjeta: Tarjeta = {
    nombre: '',
    numero: '',
    fechaEmision: '',
    fechaVencimiento: '',
    motivo: '',
    numeroCuenta: ''
  };

  nombreCompleto: string = '';
  nombres: string = '';
  apellidos: string = '';

  numeroCuenta: string = '';
  usuarioICBS: string = '';
  nombreMandar: string = '';

  disenoSeleccionado: string = 'unaFila';

  // Máx 16 por fila en diseño 2 (lo cortamos en dividirNombreCompleto)
  maxCaracteresFila: number = 16;

  // Validación / UI
  nombreError: string = '';
  nombreCharsCount: number = 0;
  nombreMaxLength: number = 26;

  // Matcher para mat-error
  nombreErrorMatcher = new NombreErrorStateMatcher(() => this.nombreError.trim().length > 0);

  constructor(
    private readonly authService: AuthService,
    private readonly dialog: MatDialog,
    public dialogRef: MatDialogRef<ModalTarjetaComponent>,
    private readonly sanitizer: DomSanitizer,
    private readonly impresionService: ImpresionService,
    private readonly tarjetaService: TarjetaService,
    private readonly cdr: ChangeDetectorRef,
    private readonly snackBar: MatSnackBar,
    @Inject(MAT_DIALOG_DATA) public tarjeta: Tarjeta
  ) {
    // Inicialización respetando tu flujo
    this.actualizarNombre(tarjeta.nombre);
    this.nombreCompleto = tarjeta.nombre;
    this.imprime = false;

    this.nombreCharsCount = (this.tarjeta.nombre || '').length;
    this.aplicarValidaciones(this.tarjeta.nombre);
  }

  ngOnInit(): void {
    // Precarga de imágenes para evitar parpadeos al cambiar diseño
    const img1 = new Image(); img1.src = '/assets/TarjetaDiseño2.png';
    const img2 = new Image(); img2.src = '/assets/Tarjeta3.PNG';

    this.subscription.add(this.authService.sessionActive$.subscribe(isActive => {
      if (isActive) {
        this.usuarioICBS = this.authService.currentUserValue?.activeDirectoryData.usuarioICBS!;
        this.actualizarNombre(this.tarjeta.nombre);
        this.cdr.detectChanges();
        this.cdr.markForCheck();
      } else {
        this.authService.logout();
      }
    }));
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  imprimir(datosParaImprimir: Tarjeta): void {
    // Revalida justo al presionar
    this.aplicarValidaciones(this.tarjeta.nombre);

    if (this.nombreError) {
      this.mostrarNotificacionError(this.nombreError);
      return; // Bloquea la impresión
    }

    let impresionExitosa = false;

    this.subscription.add(this.authService.sessionActive$.subscribe(isActive => {
      if (isActive) {
        this.tarjetaService.validaImpresion(this.tarjeta.numero).subscribe({
          next: (respuesta) => { this.imprime = respuesta.imprime; }
        });

        if (!this.imprime) {
          const tipoDiseño = this.disenoSeleccionado === 'unaFila';
          impresionExitosa = this.impresionService.imprimirTarjeta(datosParaImprimir, tipoDiseño);
          if (impresionExitosa) {
            this.tarjetaService
              .guardaEstadoImpresion(this.tarjeta.numero, this.usuarioICBS, this.tarjeta.nombre.toUpperCase())
              .subscribe({
                next: () => { this.cerrarModal(); window.location.reload(); },
                error: (error) => { console.log('error', error); }
              });
          }
        } else {
          this.cerrarModal();
        }
      } else {
        this.authService.logout();
      }
    }));
  }

  cerrarModal(): void { this.dialogRef.close(); }

  emitirNombreCambiado(): void {
    this.nombreMandar = this.tarjeta.nombre.toUpperCase();
    this.nombreCambiado.emit(this.nombreMandar);
  }

  dividirYActualizarNombre(nombreCompleto: string) {
    this.actualizarNombre(nombreCompleto);
    this.emitirNombreCambiado();
  }

  private dividirNombreCompleto(nombreCompleto: string): void {
    const cadena = (nombreCompleto || '').toUpperCase().trim();
    if (!cadena) { this.nombres = ''; this.apellidos = ''; return; }

    const partes = cadena.split(' ').filter(p => p.length > 0);

    if (partes.length === 1) {
      this.nombres = partes[0];
      this.apellidos = '';
    } else if (partes.length === 2) {
      this.nombres = partes[0];
      this.apellidos = partes[1];
    } else if (partes.length === 3) {
      this.nombres = `${partes[0]} ${partes[1]}`;
      this.apellidos = partes[2];
    } else {
      this.nombres = `${partes[0]} ${partes[1]}`;
      this.apellidos = partes.slice(2).join(' ');
    }

    if (this.nombres.length > this.maxCaracteresFila) this.nombres = this.nombres.slice(0, this.maxCaracteresFila);
    if (this.apellidos.length > this.maxCaracteresFila) this.apellidos = this.apellidos.slice(0, this.maxCaracteresFila);
  }

  actualizarNombre(nombre: string) {
    let nombreActualizado = (nombre || '').toUpperCase();

    // Validación original (no tocamos tu regex base)
    nombreActualizado = this.validarNombre(nombreActualizado);

    this.tarjeta.nombre = nombreActualizado;

    if (this.disenoSeleccionado === 'dosFilas') this.dividirNombreCompleto(nombreActualizado);

    this.nombreCharsCount = nombreActualizado.length;
    this.aplicarValidaciones(nombreActualizado);

    this.emitirNombreCambiado();
  }

  // validarNombre(nombre: string): string {
  //   let nombreValido = nombre.replace(/[^A-Z\s]/g, '');
  //   nombreValido = nombreValido.replace(/\s+/g, ' ');
  //   return nombreValido;
  // }

  validarNombre(nombre: string): string {
    let nombreValido = (nombre || '').toUpperCase();

    // 1) Mantén solo letras y espacios
    nombreValido = nombreValido.replace(/[^A-ZÑ\s]/g, '');

    // 2) Colapsa espacios múltiples
    nombreValido = nombreValido.replace(/\s+/g, ' ');

    // 3) Limita rachas de letras repetidas a MAX_REPEAT
    nombreValido = this.clampRepeatedLetters(nombreValido);

    return nombreValido;
  }

  prevenirNumeroCaracteres(event: KeyboardEvent) {
    const regex = /^[a-zA-Z\s]*$/;
    if (!regex.test(event.key)) event.preventDefault();
  }

  cambiarDiseno() { this.actualizarNombre(this.tarjeta.nombre); }

  onPasteNombre(e: ClipboardEvent): void {
    const clip = (e.clipboardData?.getData('text') || '').toUpperCase();
    const limpio = clip.replace(/[^A-ZÑ\s]/g, '').replace(/\s{2,}/g, ' ');
    const input = e.target as HTMLInputElement;
    const combinado = (input.value || '') + limpio;

    if (this.hasTripleRun(combinado)) e.preventDefault();
  }

  private aplicarValidaciones(valor: string): void {
    const limpio = (valor || '').toUpperCase().trim().replace(/\s{2,}/g, ' ');
    const palabras = limpio ? limpio.split(' ') : [];

    this.nombreError = '';

    if (!limpio) {
      this.nombreError = 'El nombre no puede estar vacío.';
      return;
    }
    if (palabras.length < 2 && !this.hasTripleRun(limpio)) {
      this.nombreError = 'Debe ingresar al menos nombre y apellido (mínimo 2 palabras).';
      return;
    }
    if (this.hasTripleRun(limpio)) {
      this.nombreError = 'No se permiten 3 o más letras idénticas consecutivas en ninguna palabra.';
      return;
    }
  }

  validarEntrada(event: Event): void {
    const input = event.target as HTMLInputElement;
    let valor = (input.value || '').toUpperCase();

    // Solo letras/espacios; colapsa espacios
    valor = valor.replace(/[^A-ZÑ\s]/g, '').replace(/\s{2,}/g, ' ');

    // Si el pegado/auto-completado trae más de 3 seguidas, recorta a 3
    // (seguirá siendo inválido por la regla, pero evita “carreras” más largas)
    if (this.hasTripleRun(valor)) {
      valor = valor.replace(/([A-ZÑ])\1{3,}/g, (_m, ch) => ch.repeat(3));
    }

    input.value = valor;
    this.tarjeta.nombre = valor;

    if (this.disenoSeleccionado === 'dosFilas') this.dividirNombreCompleto(valor);

    this.nombreCharsCount = valor.length;
    this.aplicarValidaciones(valor);   // ⬅️ Ahora marcará error por triple repetición
    this.emitirNombreCambiado();
  }

  private mostrarNotificacionError(mensaje: string): void {
    this.snackBar.open(mensaje, 'Cerrar', {
      duration: 3500,
      horizontalPosition: 'right',
      verticalPosition: 'top'
    });
  }

  /** Recorta cualquier racha de la misma letra que exceda MAX_REPEAT */
  private clampRepeatedLetters(text: string): string {
    // Solo letras A-Z y Ñ (mayúsculas); si trabajas en minúsculas, añade la i al regex y normaliza
    return (text || '').replace(/([A-ZÑ])\1{3,}/g, (_m, ch) => ch.repeat(this.MAX_REPEAT));
  }

  // Teclas de control permitidas (mover, borrar, tab…)
  private static readonly CONTROL_KEYS = new Set<string>([
    'Backspace', 'Delete', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Tab', 'Home', 'End'
  ]);

  /** ¿El valor contiene 3 o más letras idénticas consecutivas en algún lugar? */
  private hasTripleRun(value: string): boolean {
    return /([A-ZÑ])\1{2}/.test((value || '').toUpperCase());
  }


  /** Si ya hay una racha de 3, no permitimos seguir escribiendo nada (solo teclas de control) */
  bloquearSiLimite(e: KeyboardEvent): void {
    if (e.ctrlKey || e.metaKey || ModalTarjetaComponent.CONTROL_KEYS.has(e.key)) return;
    const input = e.target as HTMLInputElement;
    if (this.hasTripleRun(input.value)) e.preventDefault();
  }
}

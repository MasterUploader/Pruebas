import { Component, EventEmitter, Input, Output, computed, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

/**
 * Componente de paginación liviano que usa las clases .pagination y .page del VisualKit.
 */
@Component({
  selector: 'ui-pagination',
  standalone: true,
  imports: [CommonModule],
  template: `
  <nav class="pagination" *ngIf="total() > 0">
    <button class="page" type="button" (click)="goto(pageIndex()-1)" [disabled]="pageIndex() <= 1">«</button>
    <button class="page" type="button"
            *ngFor="let p of pages()"
            [disabled]="p === pageIndex()"
            (click)="goto(p)">{{p}}</button>
    <button class="page" type="button" (click)="goto(pageIndex()+1)" [disabled]="pageIndex() >= pageCount()">»</button>

    <span style="margin-left:.5rem">/ {{pageCount()}}</span>

    <select style="margin-left:.75rem" [value]="pageSize()" (change)="changePageSize(($event.target as HTMLSelectElement).value)">
      <option *ngFor="let s of pageSizes()" [value]="s">{{s}} / pág.</option>
    </select>
  </nav>
  `
})
export class PaginationComponent {
  /** 1-based */
  @Input({ required: true }) pageIndex = signal(1);
  @Input({ required: true }) pageSize = signal(10);
  @Input({ required: true }) total = signal(0);
  @Input() pageSizes = signal<number[]>([10, 20, 50, 100]);

  @Output() pageChange = new EventEmitter<{ pageIndex: number; pageSize: number }>();

  pageCount = computed(() => Math.max(1, Math.ceil(this.total() / this.pageSize())));

  pages = computed(() => {
    const count = this.pageCount();
    const current = this.pageIndex();
    const maxShown = 7;
    const pages: number[] = [];
    let start = Math.max(1, current - Math.floor(maxShown/2));
    let end = Math.min(count, start + maxShown - 1);
    start = Math.max(1, end - maxShown + 1);
    for (let i = start; i <= end; i++) pages.push(i);
    return pages;
  });

  goto(p: number) {
    const count = this.pageCount();
    const page = Math.min(Math.max(1, p), count);
    if (page !== this.pageIndex()) {
      this.pageIndex.set(page);
      this.pageChange.emit({ pageIndex: page, pageSize: this.pageSize() });
    }
  }

  changePageSize(v: string) {
    const size = parseInt(v, 10) || this.pageSize();
    if (size !== this.pageSize()) {
      this.pageSize.set(size);
      this.pageIndex.set(1);
      this.pageChange.emit({ pageIndex: 1, pageSize: size });
    }
  }
}

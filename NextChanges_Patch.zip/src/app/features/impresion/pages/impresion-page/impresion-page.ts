import { Component, ViewEncapsulation, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { finalize } from 'rxjs';
import { Impresion, Matricula, PagedResult } from '../../services/impresion';
import { PaginationComponent } from '../../../../shared/components/pagination/pagination.component';

/**
 * Página de Impresión con filtros simples, tabla y paginación.
 */
@Component({
  selector: 'app-impresion-page',
  standalone: true,
  imports: [CommonModule, PaginationComponent],
  templateUrl: './impresion-page.html',
  styleUrl: './impresion-page.scss',
  encapsulation: ViewEncapsulation.None
})
export class ImpresionPage {
  private readonly api = inject(Impresion);

  readonly items = signal<Matricula[]>([]);
  readonly total = signal(0);
  readonly pageIndex = signal(1);
  readonly pageSize = signal(10);
  readonly loading = signal(false);
  readonly puedeImprimir = signal(true);

  readonly documento = signal('');

  buscar(): void {
    this.loading.set(true);
    this.api.buscarPaged({ documento: this.documento(), page: this.pageIndex(), pageSize: this.pageSize() })
      .pipe(finalize(() => this.loading.set(false)))
      .subscribe((r: PagedResult<Matricula>) => {
        this.items.set(r.items);
        this.total.set(r.total);
      });
  }

  onPageChange(e: { pageIndex: number; pageSize: number }) {
    this.pageIndex.set(e.pageIndex);
    this.pageSize.set(e.pageSize);
    this.buscar();
  }

  imprimir(m: Matricula): void {
    this.api.marcarImpresa(m.id).subscribe(() => {
      this.items.update(xs => xs.map(x => x.id === m.id ? { ...x, estado: 'IMPRESA' } : x));
      setTimeout(() => window.print(), 0);
    });
  }
}

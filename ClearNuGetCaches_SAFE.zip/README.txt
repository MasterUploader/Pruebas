ClearNuGetCaches_SAFE
=====================

Qué hace
--------
- Limpia cachés del USUARIO ACTUAL: NuGet (oficial), npm cache, CrashDumps, Postman (solo cache y logs).
- No elimina sesiones ni perfiles (Roaming), ni carpetas Microsoft/Google/GitHubDesktop.

Cómo usar
---------
1) **Ejecutar_Simulacion.cmd**  → Vista previa (no borra nada).
2) **Ejecutar_Limpieza_Real.cmd** → Limpieza real (solicita elevación).

Requisitos
----------
- PowerShell y, si existe, dotnet CLI y npm (si npm no está, se omite).

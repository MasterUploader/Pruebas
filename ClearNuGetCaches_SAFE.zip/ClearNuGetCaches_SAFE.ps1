<# 
.SYNOPSIS
  Limpieza segura de cachés de NuGet/npm/Postman/CrashDumps para el USUARIO ACTUAL.
.DESCRIPTION
  - No borra perfiles, sesiones ni datos en %AppData%\Roaming.
  - No toca carpetas "Microsoft", "Google", "GitHubDesktop".
  - Postman: solo Cache/GPUCache/Code Cache/logs en AppData\Local.
  - NuGet: usa "dotnet nuget locals all --clear".
  - npm: usa "npm cache clean --force".
.PARAMETER Apply
  Ejecuta la limpieza real. Si se omite, corre en modo simulación (Dry-Run).
.PARAMETER VerboseMode
  Muestra más detalle durante la ejecución.
.EXAMPLE
  # Simulación (recomendado)
  .\ClearNuGetCaches_SAFE.ps1
.EXAMPLE
  # Limpieza real
  .\ClearNuGetCaches_SAFE.ps1 -Apply
#>
[CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Low')]
param(
  [switch]$Apply,
  [switch]$VerboseMode
)

$ErrorActionPreference = 'Stop'
if ($VerboseMode) { $VerbosePreference = 'Continue' } else { $VerbosePreference = 'SilentlyContinue' }
$DryRun = -not $Apply

function Write-Header($text) { Write-Host "`n=== $text ===" }

function Remove-Safe([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { 
        Write-Verbose "No existe: $Path"
        return 
    }
    if ($DryRun) { 
        Write-Host "[SIMULACION] Eliminar: $Path"
        return 
    }
    try {
        if ($PSCmdlet.ShouldProcess($Path, "Remove-Item")) {
            Remove-Item -LiteralPath $Path -Recurse -Force -ErrorAction Stop
            Write-Host ("OK  {0}" -f $Path)
        }
    } catch {
        Write-Warning ("No se pudo eliminar {0}: {1}" -f $Path, $_.Exception.Message)
    }
}

Write-Header "Limpieza segura (usuario actual)"
Write-Host "Dry-Run: $DryRun  |  Verbose: $VerboseMode"
Write-Host "Acciones: NuGet (oficial), npm cache, CrashDumps, Postman(Local: Cache/GPUCache/Code Cache/logs)"
Write-Host "Resguardo: NO se tocan perfiles, sesiones, %AppData%\Roaming ni carpetas Microsoft/Google/GitHubDesktop."

# --- NuGet (oficial) --------------------------------------------------------------
Write-Header "NuGet"
try {
    $cmdArgs = @("nuget","locals","all","--clear")
    if ($DryRun) {
        Write-Host "[SIMULACION] dotnet $($cmdArgs -join ' ')"
    } else {
        & dotnet @cmdArgs | Out-Null
        Write-Host "OK  NuGet cache limpiada mediante 'dotnet nuget locals all --clear'"
    }
} catch {
    Write-Verbose "dotnet CLI no disponible; intento limpiar directorios de cache NuGet del usuario"
    $nugetPaths = @(
        Join-Path $env:USERPROFILE ".nuget\packages",
        Join-Path $env:LOCALAPPDATA "NuGet\Cache",
        Join-Path $env:LOCALAPPDATA "NuGet\v3-cache",
        Join-Path $env:LOCALAPPDATA "NuGet\v2-cache"
    )
    $nugetPaths | ForEach-Object { Remove-Safe $_ }
}

# --- npm cache --------------------------------------------------------------------
Write-Header "npm cache"
try {
    $npmCmd = Get-Command npm -ErrorAction Stop
    if ($DryRun) {
        Write-Host "[SIMULACION] npm cache clean --force"
    } else {
        npm cache clean --force | Out-Null
        Write-Host "OK  npm cache limpiada."
    }
} catch {
    Write-Host "npm no encontrado; omitido."
}

# --- CrashDumps -------------------------------------------------------------------
Write-Header "CrashDumps"
Remove-Safe (Join-Path $env:LOCALAPPDATA "CrashDumps")

# --- Postman (SOLO cache/logs en Local) ------------------------------------------
Write-Header "Postman (Local: cache y logs)"
$postmanLocal = Join-Path $env:LOCALAPPDATA "Postman"
$pmTargets = @(
    Join-Path $postmanLocal "Cache",
    Join-Path $postmanLocal "GPUCache",
    Join-Path $postmanLocal "Code Cache",
    Join-Path $postmanLocal "logs"
)
$pmTargets | ForEach-Object { Remove-Safe $_ }

Write-Host "`nHecho. Si quieres aplicar cambios reales, ejecuta con -Apply."

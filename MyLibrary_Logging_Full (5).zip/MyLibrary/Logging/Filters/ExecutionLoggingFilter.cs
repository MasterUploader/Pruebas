using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Http;
using System.Text.Json;
using System.Threading.Tasks;
using MyLibrary.Logging.Abstractions;
using System.Linq;
using System;

namespace MyLibrary.Logging.Filters
{
    public class ExecutionLoggingFilter : IAsyncActionFilter
    {
        private readonly ILoggerService _logger;

        public ExecutionLoggingFilter(ILoggerService logger)
        {
            _logger = logger;
        }

        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            var executionId = context.HttpContext.Items["ExecutionId"]?.ToString() ?? Guid.NewGuid().ToString();
            var controllerName = context.Controller.GetType().Name;
            var actionName = context.ActionDescriptor.DisplayName;
            
            var parameters = context.ActionArguments.ToDictionary(p => p.Key, p => p.Value);
            var inputLog = new
            {
                ExecutionId = executionId,
                Controller = controllerName,
                Action = actionName,
                Timestamp = DateTime.UtcNow,
                Parameters = parameters
            };

            await _logger.AddSingleLogAsync($"Action Executed: {JsonSerializer.Serialize(inputLog, new JsonSerializerOptions { WriteIndented = true })}", LogLevel.Info);

            var executedContext = await next();

            if (executedContext.Result is Microsoft.AspNetCore.Mvc.ObjectResult objectResult)
            {
                var outputLog = new
                {
                    ExecutionId = executionId,
                    Controller = controllerName,
                    Action = actionName,
                    Timestamp = DateTime.UtcNow,
                    Response = objectResult.Value
                };

                await _logger.AddSingleLogAsync($"Action Result: {JsonSerializer.Serialize(outputLog, new JsonSerializerOptions { WriteIndented = true })}", LogLevel.Info);
            }
        }
    }
}
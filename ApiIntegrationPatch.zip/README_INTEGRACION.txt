Integración con el API (misma estructura de endpoints)

1) Base URL
   - Asegúrate de que environment.apiBase apunte al host actual del API.
   - Si tu API usa cookie de sesión, define environment.apiWithCredentials = true.

2) Endpoints
   - Edita los paths en src/app/core/api/api-endpoints.ts si tu API usa otros nombres.
   - No cambies firmas si el API es el mismo; los DTOs de ejemplo en ImpresionService
     son placeholders y puedes ajustarlos.

3) Auth
   - AuthService ahora acepta 'token', 'access_token' o 'jwt' en la respuesta.
   - Si tu login es otro path, cambia ApiEndpoints.auth.login.

4) Uso
   - Inyecta ImpresionService en tu componente y llama:
       this.impresion.listar({ fecha, comercio, terminal, page, size })
       this.impresion.marcar({ ids, marcadoPor })
       this.impresion.imprimir({ ids, impresora, vistaPrevia })
       this.impresion.detalle(id)

5) Interceptores
   - Si tu proyecto ya prefija environment.apiBase desde un interceptor, ApiClient
     seguirá funcionando (prefiere URLs absolutas y respeta relativas). No hay conflictos.

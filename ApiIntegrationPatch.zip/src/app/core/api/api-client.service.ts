import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

/**
 * Cliente fino para unificar llamadas al API.
 * - Prefija environment.apiBase si la URL empieza con '/'
 * - Permite activar withCredentials desde environment.apiWithCredentials
 */
@Injectable({ providedIn: 'root' })
export class ApiClient {
  private http = inject(HttpClient);
  private withCreds = (environment as any).apiWithCredentials === true;

  private url(u: string) {
    if (u.startsWith('http://') || u.startsWith('https://')) return u;
    const base = (environment as any).apiBase ?? '';
    return `${base}${u}`;
  }

  get<T>(url: string, params?: Record<string, any>): Observable<T> {
    const hp = new HttpParams({ fromObject: params ?? {} });
    return this.http.get<T>(this.url(url), { params: hp, withCredentials: this.withCreds });
  }
  post<T>(url: string, body?: any, params?: Record<string, any>): Observable<T> {
    const hp = new HttpParams({ fromObject: params ?? {} });
    return this.http.post<T>(this.url(url), body ?? {}, { params: hp, withCredentials: this.withCreds });
  }
  put<T>(url: string, body?: any, params?: Record<string, any>): Observable<T> {
    const hp = new HttpParams({ fromObject: params ?? {} });
    return this.http.put<T>(this.url(url), body ?? {}, { params: hp, withCredentials: this.withCreds });
  }
  delete<T>(url: string, params?: Record<string, any>): Observable<T> {
    const hp = new HttpParams({ fromObject: params ?? {} });
    return this.http.delete<T>(this.url(url), { params: hp, withCredentials: this.withCreds });
  }
}

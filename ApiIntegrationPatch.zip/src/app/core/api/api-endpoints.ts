/**
 * Mapa centralizado de endpoints. Mantén los paths iguales a tu API actual.
 * Prefijo base: environment.apiBase (lo agrega el interceptor o ApiClient).
 */
export const ApiEndpoints = {
  auth: {
    login: '/auth/login',
    refresh: '/auth/refresh',
    me: '/auth/me'
  },
  impresion: {
    listar: '/impresion/listar',
    marcar: '/impresion/marcar',
    imprimir: '/impresion/imprimir',
    detalle: (id: string | number) => `/impresion/detalle/${id}`
  },
  reportes: {
    resumen: '/reportes/resumen',
    exportar: '/reportes/exportar'
  },
  configuracion: {
    preferencias: '/config/preferencias',
    permisos: '/config/permisos'
  }
} as const;
export type ApiEndpointTree = typeof ApiEndpoints;

import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { AuthStore } from './auth.store';
import { ApiEndpoints } from '../api/api-endpoints';

export interface LoginRequest { username: string; password: string; remember?: boolean; }
export type LoginResponse = { token: string } | { access_token: string } | { jwt: string };

/** Servicio de autenticación contra el backend. */
@Injectable({ providedIn: 'root' })
export class AuthService {
  private http = inject(HttpClient);
  private store = inject(AuthStore);

  login(payload: LoginRequest): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(ApiEndpoints.auth.login, payload).pipe(
      tap(resp => {
        const t = (resp as any).token ?? (resp as any).access_token ?? (resp as any).jwt;
        if (!t) throw new Error('Token no encontrado en la respuesta.');
        this.store.setToken(t, payload.remember !== false);
      })
    );
  }

  logout() { this.store.clear(); }
}

import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiClient } from '../../../core/api/api-client.service';
import { ApiEndpoints } from '../../../core/api/api-endpoints';

export interface LoteDto { id: number; comercio: string; terminal: string; fecha: string; cantidad: number; }
export interface MarcarRequest { ids: number[]; marcadoPor: string; }
export interface ImprimirRequest { ids: number[]; impresora?: string; vistaPrevia?: boolean; }
export interface OperacionOk { ok: true; message?: string; }
export interface OperacionFail { ok: false; error: string; }
export type Operacion = OperacionOk | OperacionFail;

@Injectable({ providedIn: 'root' })
export class ImpresionService {
  private api = inject(ApiClient);

  listar(filtro: Partial<{ fecha: string; comercio: string; terminal: string; page: number; size: number }>): Observable<LoteDto[]> {
    return this.api.get<LoteDto[]>(ApiEndpoints.impresion.listar, filtro as any);
  }

  marcar(req: MarcarRequest): Observable<Operacion> {
    return this.api.post<Operacion>(ApiEndpoints.impresion.marcar, req);
  }

  imprimir(req: ImprimirRequest): Observable<Operacion> {
    return this.api.post<Operacion>(ApiEndpoints.impresion.imprimir, req);
  }

  detalle(id: number): Observable<LoteDto> {
    return this.api.get<LoteDto>(ApiEndpoints.impresion.detalle(id));
  }
}

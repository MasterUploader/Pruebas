﻿namespace MS_BAN_43_Embosado_Tarjetas_Debito.Utils;

/// <summary>
/// Clase de Configuración de Conexiones y valores globales.
/// </summary>
public class ConnectionConfig
{
    /// <summary>
    /// Periodo de tiempo que se consultara hacia atras en las tarjetas.
    /// </summary>
    public string DiasConsultaTarjeta { get; set; } = string.Empty;

    /// <summary>
    /// ActiveDirectory
    /// </summary>
    public string ActiveDirectory { get; set; } = string.Empty;

    /// <summary>
    /// Dominio de GINIH.
    /// </summary>
    public string Domain { get; set; } = string.Empty;
}

/// <summary>
/// Clase estática para exponer la conexión global.
/// </summary>
public static class GlobalConnection
{
    /// <summary>
    /// Parametro instanciado de conexión.
    /// </summary>
    public static ConnectionConfig Current { get; set; } = new();
}

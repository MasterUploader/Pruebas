﻿using MS_BAN_43_Embosado_Tarjetas_Debito.Models.Dtos.DetalleTarjetaImprimir;
using Newtonsoft.Json;

namespace MS_BAN_43_Embosado_Tarjetas_Debito.Models.Dtos.Auth;

/// <summary>
/// Clase GetauthResponseDto.
/// </summary>
public class GetAuthResponseDto
{
    /// <inheritdoc />
    [JsonProperty("token")]
    public TokenDto Token { get; set; } = new();

    /// <inheritdoc />
    [JsonProperty("activeData")]
    public ActiveDirectoryDataDto ActiveDirectoryData { get; set; } = new();

    /// <inheritdoc />
    [JsonProperty("codigo")]
    public Codigo Codigo { get; set; } = new();

}

﻿using Newtonsoft.Json;

namespace MS_BAN_43_Embosado_Tarjetas_Debito.Models.Dtos.Auth;

/// <summary>
/// Clase ActiveDirectoryDataDto.
/// </summary>
public class ActiveDirectoryDataDto
{
    /// <summary>
    /// Código de Agencia de Apertura.
    /// </summary>
    [JsonProperty("agenciaAperturaCodigo")]
    public string AgenciaAperturaCodigo { get; set; } = string.Empty;

    /// <summary>
    /// Código de Agencia que Imprime.
    /// </summary>
    [JsonProperty("agenciaImprimeCodigo")]
    public string AgenciaImprimeCodigo { get; set; } = string.Empty;

    /// <summary>
    /// Nombre de usuario que imprime.
    /// </summary>
    [JsonProperty("nombreUsuario")]
    public string NombreUsuario { get; set; } = string.Empty;

    /// <summary>
    /// Nombre de usuario de ICBS.
    /// </summary>
    [JsonProperty("usuarioICBS")]
    public string UsuarioICBS { get; set; } = string.Empty;

}
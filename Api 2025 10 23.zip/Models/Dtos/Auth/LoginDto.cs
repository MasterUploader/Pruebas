﻿using Logging.Attributes;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace MS_BAN_43_Embosado_Tarjetas_Debito.Models.Dtos.Auth;

/// <summary>
/// Clase DTO LoginDto.
/// </summary>
public class LoginDto
{
    /// <summary>
    /// Usuario de RED que intenta ingresar.
    /// </summary>
    [Required(ErrorMessage = "El Usurioa es necesario para la consulta")]
    [JsonProperty("user")]
    [LogFileName("Usuario")]
    public string User { get; set; } = string.Empty;

    /// <summary>
    /// Contraseña de usuario de RED.
    /// </summary>
    [Required(ErrorMessage = "El Password es necesario para la consulta")]
    [JsonProperty("password")]
    public string Password { get; set; } = string.Empty;
}

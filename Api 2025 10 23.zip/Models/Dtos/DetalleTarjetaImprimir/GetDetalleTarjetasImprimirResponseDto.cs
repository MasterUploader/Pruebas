﻿using Newtonsoft.Json;

namespace MS_BAN_43_Embosado_Tarjetas_Debito.Models.Dtos.DetalleTarjetaImprimir;

/// <summary>
/// Clase GetDetallesTarjetaImprimirResponseDto.
/// </summary>
public class GetDetallesTarjetasImprimirResponseDto
{
    /// <inheritdoc />
    [JsonProperty("agencias")]
    public Agencia Agencia { get; set; } = new();

    /// <inheritdoc />
    [JsonProperty("tarjetas")]
    public List<Tarjetas> Tarjetas { get; set; } = new();

    /// <inheritdoc />
    [JsonProperty("codigo")]
    public Codigo Codigo { get; set; } = new();
}

/// <summary>
/// Clase objeto Tarjetas, consiste en la estructura de datos de una tarjeta de debito.
/// </summary>
public class Tarjetas
{
    /// <summary>
    /// Nombre en tarjeta.
    /// </summary>
    [JsonProperty("nombre")]
    public string Nombre { get; set; } = string.Empty;

    /// <summary>
    /// Número de tarjeta.
    /// </summary>
    [JsonProperty("numero")]
    public string Numero { get; set; } = string.Empty;

    /// <summary>
    /// Fecha de Emisión de la tarjeta.
    /// </summary>
    [JsonProperty("fechaEmision")]
    public string FechaEmision { get; set; } = string.Empty;

    /// <summary>
    /// Fecha de vencimiento de la tarjeta.
    /// </summary>
    [JsonProperty("fechaVencimiento")]
    public string FechaVencimiento { get; set; } = string.Empty;

    /// <summary>
    /// Motivo de impresión de tarjeta de debito.
    /// </summary>
    [JsonProperty("motivo")]
    public string Motivo { get; set; } = string.Empty;

    /// <summary>
    /// Número de cuenta asociada.
    /// </summary>
    [JsonProperty("numeroCuenta")]
    public string NumeroCuenta { get; set; } = string.Empty;
}

/// <summary>
/// Clase objeto, representa los valores de Agencia.
/// </summary>
public class Agencia
{
    /// <summary>
    /// Nombre de agencia de Apertura.
    /// </summary>
    [JsonProperty("agenciaAperturaNombre")]
    public string AgenciaAperturaNombre { get; set; } = string.Empty;

    /// <summary>
    /// Código de agencia de apertura.
    /// </summary>
    [JsonProperty("agenciaAperturaCodigo")]
    public string AgenciaAperturaCodigo { get; set; } = string.Empty;

    /// <summary>
    /// Nomnbre de Agencia que imprime.
    /// </summary>
    [JsonProperty("agenciaImprimeNombre")]
    public string AgenciaImprimeNombre { get; set; } = string.Empty;

    /// <summary>
    /// Código de Agencia que imrpime
    /// </summary>
    [JsonProperty("agenciaImprimeCodigo")]
    public string AgenciaImprimeCodigo { get; set; } = string.Empty;

}

/// <summary>
/// Clase objeto Codigo, reperesenta el estatus de la respuesta de una petición.
/// </summary>
public class Codigo
{
    /// <summary>
    /// Código de estatus.
    /// </summary>
    [JsonProperty("status")]
    public string Status { get; set; } = string.Empty;

    /// <summary>
    /// Descripción del estatus.
    /// </summary>
    [JsonProperty("message")]
    public string Message { get; set; } = string.Empty;

    /// <summary>
    /// Momento en el que se devolvio la respuesta.
    /// </summary>
    [JsonProperty("timestamp")]
    public string TimeStamp { get; set; } = string.Empty;

    /// <summary>
    /// Error interno.
    /// </summary>
    [JsonProperty("error")]
    public string Error { get; set; } = string.Empty;
}

﻿using Logging.Attributes;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace MS_BAN_43_Embosado_Tarjetas_Debito.Models.Dtos.DetalleTarjetaImprimir;

/// <summary>
/// Clase Objeto GetDetalleTarjetaImprimirDto
/// </summary>
public class GetDetalleTarjetaImprimirDto
{
    /// <summary>
    /// Número BIN de la tarjeta
    /// </summary>
    [Required(ErrorMessage = "El bin es necesario para la consulta")]
    [JsonProperty("bin")]
    public string BIN { get; set; } = string.Empty;

    /// <summary>
    /// Código de la agencia que imprime.
    /// </summary>
    [Required(ErrorMessage = "La Agencia que Imprime es requerida")]
    [JsonProperty("agenciaImprime")]
    [LogFileName("AgenciaImprime")]
    public string AgenciaImprime { get; set; } = string.Empty;

    /// <summary>
    /// Código de la agencia de apertura.
    /// </summary>
    [Required(ErrorMessage = "La Agencia de Apertura es requerida")]
    [JsonProperty("agenciaApertura")]
    [LogFileName("AgenciaApertura")]
    public string AgenciaApertura { get; set; } = string.Empty;
}

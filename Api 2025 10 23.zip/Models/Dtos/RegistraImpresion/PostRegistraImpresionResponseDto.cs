﻿using MS_BAN_43_Embosado_Tarjetas_Debito.Models.Dtos.DetalleTarjetaImprimir;
using Newtonsoft.Json;

namespace MS_BAN_43_Embosado_Tarjetas_Debito.Models.Dtos.RegistraImpresion;

/// <summary>
/// Clase objeto PostRegistraImpresionResponseDto
/// </summary>
public class PostRegistraImpresionResponseDto
{
    /// <summary>
    /// Estatus de exito de la impresión.
    /// </summary>
    [JsonProperty("impresionExitosa")]
    public bool ImpresionExitosa { get; set; }

    /// <inheritdoc />
    [JsonProperty("codigo")]
    public Codigo Codigo { get; set; } = new();
}

﻿using Newtonsoft.Json;

namespace MS_BAN_43_Embosado_Tarjetas_Debito.Models.Dtos;

/// <summary>
/// Clase objeto CodigoDTO.
/// </summary>
public class CodigoDto
{
    /// <summary>
    /// Estatus de la eejcución.
    /// </summary>
    [JsonProperty("status")]
    public string Status { get; set; } = string.Empty;

    /// <summary>
    /// Descripción del estatus.
    /// </summary>
    [JsonProperty("message")]
    public string Message { get; set; } = string.Empty;

    /// <summary>
    /// Momento de devolución de la respuesta.
    /// </summary>
    [JsonProperty("timestamp")]
    public string TimeStamp { get; set; } = string.Empty;

    /// <summary>
    /// Error de la ejecución.
    /// </summary>
    [JsonProperty("error")]
    public string Error { get; set; } = string.Empty;

}

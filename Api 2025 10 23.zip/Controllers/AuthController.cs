﻿using Microsoft.AspNetCore.Mvc;
using MS_BAN_43_Embosado_Tarjetas_Debito.Models.Dtos.Auth;
using MS_BAN_43_Embosado_Tarjetas_Debito.Services.AuthService;
using MS_BAN_43_Embosado_Tarjetas_Debito.Services.MachineInformationService;
using MS_BAN_43_Embosado_Tarjetas_Debito.Services.SessionManagerService;
using MS_BAN_43_Embosado_Tarjetas_Debito.Utils;
using System.Net.Mime;

namespace MS_BAN_43_Embosado_Tarjetas_Debito.Controllers;

/// <summary>
/// Endpoints de autenticación para el sitio de embosado.
/// </summary>
/// <remarks>
/// constructor que inyecta los servicios necesarios.
/// </remarks>
/// <param name="authService">Instancia de IAuthService.</param>
/// <param name="sessionManagerService">Instancia de ISessionManagerService.</param>
/// <param name="machineInfoService">Instancia de IMachineInfoService.</param>
[ApiController]
[Route("api/[controller]")]
[Produces(MediaTypeNames.Application.Json)]
public class AuthController(
    IAuthService authService,
    ISessionManagerService sessionManagerService,
    IMachineInfoService machineInfoService) : ControllerBase
{
    private readonly IAuthService _authService = authService;
    private readonly ISessionManagerService _sessionManagerService = sessionManagerService;
    private readonly IMachineInfoService _machineInfoService = machineInfoService;
    private readonly ResponseHandler _responseHandler = new();

    /// <summary>
    /// Realiza el proceso de logueo contra AD y registra actividad.
    /// </summary>
    /// <returns>Respuesta HTTP con el resultado del servicio.</returns>
    /// <remarks>
    /// Rutas soportadas:
    /// - <c>GET api/Auth/Login</c>
    /// </remarks>
    [HttpPost("Login")]
    [ProducesResponseType(typeof(GetAuthResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(GetAuthResponseDto), StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Login([FromBody] LoginDto loginDto)
    {
        if (!ModelState.IsValid)
        {
            var dto = new GetAuthResponseDto
            {
                Codigo =
                    {
                        Status = "BadRequest",
                        Error = "400",
                        Message = "Solicitud inválida.",
                        TimeStamp = DateTime.Now.ToString("HH:mm:ss tt")
                    }
            };
            return _responseHandler.HandleResponse(dto, dto.Codigo.Status);
        }

        try
        {
            var response = await _authService.AuthenticateAsync(loginDto!);
            return _responseHandler.HandleResponse(response, response.Codigo.Status);
        }
        catch (Exception ex)
        {
            var dto = new GetAuthResponseDto
            {
                Codigo =
                    {
                        Status = "BadRequest",
                        Error = "400",
                        Message = ex.Message,
                        TimeStamp = DateTime.Now.ToString("HH:mm:ss tt")
                    }
            };
            return _responseHandler.HandleResponse(dto, dto.Codigo.Status);
        }
    }
}

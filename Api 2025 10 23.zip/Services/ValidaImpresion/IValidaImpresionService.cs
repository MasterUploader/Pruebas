﻿using MS_BAN_43_Embosado_Tarjetas_Debito.Models.Dtos.ValidaImpresion;

namespace MS_BAN_43_Embosado_Tarjetas_Debito.Services.ValidaImpresion;

/// <summary>
/// Interfaz del servicio de validación de impresión.
/// </summary>
public interface IValidaImpresionService
{
    /// <summary>
    /// Valida si la tarjeta ya fue impresa (consultando UNI5400).
    /// </summary>
    /// <param name="getValidaImpresionDto">Parámetros de validación.</param>
    /// <returns>DTO con el resultado de la validación.</returns>
    Task<GetValidaImpresionResponseDto> ValidaImpresionAsync(GetValidaImpresionDto getValidaImpresionDto);
}

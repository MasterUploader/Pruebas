﻿namespace MS_BAN_43_Embosado_Tarjetas_Debito.Services.MachineInformationService;

/// <summary>
/// Interfaz IMachineInfoService
/// </summary>
public interface IMachineInfoService
{
    /// <summary>
    /// Método GetMachineInfo.
    /// </summary>
    /// <returns>Objeto MachineInfo.</returns>
    MachineInfo GetMachineInfo();
}

/// <summary>
/// Clase objeto MachineInfo
/// </summary>
public class MachineInfo
{
    /// <summary>
    /// Elemento HostName.
    /// </summary>
    public string HostName { get; set; } = string.Empty;

    /// <summary>
    /// Elemento ClientIpAddress.
    /// </summary>
    public string ClientIPAddress { get; set; } = string.Empty;

    /// <summary>
    /// Elemento UserAgent.
    /// </summary>
    public string UserAgent { get; set; } = string.Empty;

    /// <summary>
    /// Elemento Browser.
    /// </summary>
    public string Browser { get; set; } = string.Empty;

    /// <summary>
    /// Elemento OS.
    /// </summary>
    public string OS { get; set; } = string.Empty;

    /// <summary>
    /// Elemento Device.
    /// </summary>
    public string Device { get; set; } = string.Empty;

    /// <summary>
    /// Elemento Engine.
    /// </summary>
    public string Engine { get; set; } = string.Empty;
}

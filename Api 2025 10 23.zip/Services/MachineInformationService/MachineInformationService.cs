﻿using System.Net;
using UAParser;

namespace MS_BAN_43_Embosado_Tarjetas_Debito.Services.MachineInformationService;

/// <summary>
/// Clase de Servicio MachineInformationService, se encarga de devolver los elementos correspondientes al equipo que envia la petición.
/// </summary>
/// <remarks>
/// 
/// </remarks>
/// <param name="httpContextAccessor">Objeto de tipo IHttpContextAccessor, contiene la información de la petición Http que se hizo al API. </param>
public class MachineInformationService(IHttpContextAccessor httpContextAccessor) : IMachineInfoService
{
    private readonly IHttpContextAccessor _httpContextAccessor = httpContextAccessor;

    /// <inheritdoc/>
    public MachineInfo GetMachineInfo()
    {
        var context = _httpContextAccessor.HttpContext;

        if (context == null)
        {
            return new MachineInfo
            {
                HostName = "Contexto no Disponible",
                ClientIPAddress = "Contexto no Disponible",
                UserAgent = "Contexto no Disponible",
                Browser = "Contexto no Disponible",
                OS = "Contexto no Disponible",
                Device = "Contexto no disponible"
            };
        }

        var hostName = Dns.GetHostName(); // Obtener el nombre del host del servidor
        var ipAddress = context.Connection.RemoteIpAddress?.ToString() ?? "Ip Desconocida";

        // Extraer el User-Agent
        var userAgentString = context.Request.Headers.UserAgent.ToString();
        var uaParser = Parser.GetDefault();
        var clientInfo = uaParser.Parse(userAgentString);

        // Verificar si estamos detrás de un proxy y utilizar la cabecera X-Forwarded-For
        var forwardedIp = context.Request.Headers["X-Forwarded-For"].FirstOrDefault();
        if (!string.IsNullOrEmpty(forwardedIp))
        {
            ipAddress = forwardedIp.Split(',').FirstOrDefault() ?? ipAddress; // Toma la primera IP si hay múltiples
        }

        return new MachineInfo
        {
            HostName = hostName,
            ClientIPAddress = ipAddress,
            UserAgent = userAgentString,
            Browser = clientInfo.UA.Family + " " + clientInfo.UA.Major,
            OS = clientInfo.OS.Family + " " + clientInfo.OS.Major,
            Device = clientInfo.Device.Family
        };
    }
}

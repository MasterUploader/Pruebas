﻿using MS_BAN_43_Embosado_Tarjetas_Debito.Models.Dtos.DetalleTarjetaImprimir;

namespace MS_BAN_43_Embosado_Tarjetas_Debito.Services.DetalleTarjetasImprimir;

/// <summary>
/// Interfaz DetalleTarjetasImprimirServices
/// </summary>
public interface IDetalleTarjetasImprimirServices
{
    /// <summary>
    /// Método GetTarjetas
    /// </summary>
    /// <param name="getDetalleTarjetaImprimirDto">Objeto DTO</param>
    /// <returns>Retorna Objeto GetDetallesTarjetasImprimirResponseDto.</returns>
    Task<GetDetallesTarjetasImprimirResponseDto> GetTarjetas(GetDetalleTarjetaImprimirDto getDetalleTarjetaImprimirDto);
}
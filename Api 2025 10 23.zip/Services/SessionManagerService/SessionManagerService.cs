﻿using API_1_TERCEROS_REMESADORAS.Utilities;
using Connections.Abstractions;
using Microsoft.IdentityModel.Tokens;
using MS_BAN_43_Embosado_Tarjetas_Debito.Models.Dtos.Auth;
using System.Data.Common;
using System.Data.OleDb;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace MS_BAN_43_Embosado_Tarjetas_Debito.Services.SessionManagerService;

/// <summary>
/// Clase SessionManagerService encargada de validar si la sesión esta activa y de crear los claims para el JWT.
/// </summary>
/// <param name="_jwtService"></param>
/// <param name="_connection"></param>
/// <param name="_contextAccessor"></param>
public class SessionManagerService(IJwtService _jwtService, IDatabaseConnection _connection, IHttpContextAccessor _contextAccessor) : ISessionManagerService
{

    /// <inheritdoc />
    public async Task<(SecurityToken, string)> GenerateTokenAsync(LoginDto loginDto)
    {
        //Logica de Generar Token
        var secretKey = await _jwtService.GetSecretKeyAsync();
        var key = Encoding.ASCII.GetBytes(secretKey);
        var tokenDescriptor = new SecurityTokenDescriptor
        {
            Subject = new ClaimsIdentity(
        [
                    new Claim(ClaimTypes.NameIdentifier, loginDto.User),
                    new Claim(ClaimTypes.Name, loginDto.User)
            ]),
            Expires = DateTime.UtcNow.AddHours(8),
            SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
        };

        var tokenHandler = new JwtSecurityTokenHandler();
        var token = tokenHandler.CreateToken(tokenDescriptor);
        var tokenString = tokenHandler.WriteToken(token);

        return (token, tokenString);
    }

    /// <inheritdoc />
    public Task InvalidateOldSessionAsync(string userID)
    {
        //Invalidar Session en Tabla
        throw new NotImplementedException();
    }

    /// <inheritdoc />
    public bool IsSessionActiveAsync(string usuarioRed)
    {
        FieldsQueryL param = new();

        //Validar si el token aun representa una session activa._
        _connection.Open();

        string sqlQuery = "SELECT * FROM BCAH96DTA.ETD02LOG WHERE LOGB01UID = ?";
        using var command = _connection.GetDbCommand(_contextAccessor.HttpContext!);
        command.CommandText = sqlQuery;
        command.CommandType = System.Data.CommandType.Text;

        param.AddOleDbParameter(command, "LOGB01UID", OleDbType.Char,usuarioRed);

        using DbDataReader reader = command.ExecuteReader();
        if (reader.HasRows)
        {
            while (reader.Read())
            {
                string valorDevuelto = reader.GetString(reader.GetOrdinal("LOGB04SEA"));
                if (valorDevuelto.Equals("0"))
                {
                    return true;
                }else if (valorDevuelto.Equals("1"))
                {
                    return false;
                }
                else if (valorDevuelto.IsNullOrEmpty())
                {
                    return false;
                }
            }
        }
        return false;
    }
}

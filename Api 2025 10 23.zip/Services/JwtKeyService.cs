﻿using MS_BAN_43_Embosado_Tarjetas_Debito.Utils;
using System.Data.OleDb;

namespace MS_BAN_43_Embosado_Tarjetas_Debito.Services;

public interface IJwtService
{
    Task<string> GetSecretKeyAsync();
}
public class JwtKeyService : IJwtService
{
   // private readonly Connector conection = new();

    public async Task<string> GetSecretKeyAsync()
    {

        return await Task.FromResult("JwtKey:dsfhksdfhkj4534543kfdjgkj345435iuokldshlfdhlghdfio4543543dflghfldkhgfdhg");

        try
        {
            string secretKey = "";
            //Conexión As400
           // conection.Open();
            string sqlQuery = "SELECT * FROM BCAH96DTA.USERAPI WHERE USR00COD = ? ORDER BY USR00COD";
            await using (OleDbCommand command = new OleDbCommand(sqlQuery, null))
            {
                command.CommandType = System.Data.CommandType.Text;
                command.Parameters.Add("USR00COD", OleDbType.Integer).Value = 1;

                using (OleDbDataReader reader = command.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            secretKey = reader.GetString(reader.GetOrdinal("USR13TKN"));
                        }
                    }
                }
            }
            return secretKey;

        }
        catch (Exception ex)
        {
            return ex.Message;

        }


    }
}


﻿using Microsoft.AspNetCore.Http;
using System.Data.Common;

namespace Connections.Interfaces;

/// <summary>
/// Define las operaciones básicas para una conexión de base de datos compatible con múltiples motores.
/// </summary>
public interface IDatabaseConnection : IDisposable
{
    /// <summary>
    /// Abre la conexión a la base de datos.
    /// </summary>
    void Open();

    /// <summary>
    /// Cierra la conexión actual a la base de datos.
    /// </summary>
    void Close();

    /// <summary>
    /// Indica si la conexión está activa.
    /// </summary>
    bool IsConnected { get; }

    /// <summary>
    /// Crea un nuevo comando de base de datos, decorado con soporte de logging si está habilitado.
    /// </summary>
    /// <param name="context">Contexto HTTP opcional para registrar logs por petición.</param>
    /// <returns>Comando decorado con logging.</returns>
    DbCommand GetDbCommand(HttpContext context);
}


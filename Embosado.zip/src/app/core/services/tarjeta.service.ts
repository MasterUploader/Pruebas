import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { GetDetalleTarjetasImprimirResponseDto } from '../models/getDetalleTarjetasImprimir.model';
import { environment } from '../../environments/environment';
import { PostRegistraImpresionResponseDto } from '../models/PostResgistraImpresionResponseDto.model';
import { GetValidaImpresionDto } from '../models/getValidaImpresion.model';

@Injectable({
  providedIn: 'root'
})
export class TarjetaService {
  private readonly apiUrl = environment.apiBaseUrl;//URL del Microservicio

  constructor(private readonly http: HttpClient) { }

  obtenerDatosTarjeta(bin: string, agenciaImprime: string, agenciaApertura: string): Observable<GetDetalleTarjetasImprimirResponseDto> {
    return this.http.get<GetDetalleTarjetasImprimirResponseDto>(`${this.apiUrl}/api/DetalleTarjetasImprimir/GetTarjetas`, {
      params: {
        bin,
        agenciaImprime,
        agenciaApertura
      }
    });
  }

  validaImpresion(codigoTarjeta: string): Observable<GetValidaImpresionDto> {
    return this.http.get<GetValidaImpresionDto>(`${this.apiUrl}/api/ValidaImpresion`, {
      params: {
        codigoTarjeta
      }
    });
  }

  guardaEstadoImpresion(numeroTarjeta: string, usuarioICBS: string, nombreEnTarjeta: string): Observable<PostRegistraImpresionResponseDto> {

    return this.http.post<PostRegistraImpresionResponseDto>(`${this.apiUrl}/api/RegistraImpresion/RegistraImpresion`,
           {
            numeroTarjeta: numeroTarjeta,
            usuarioICBS: usuarioICBS,
            nombreEnTarjeta: nombreEnTarjeta
          }
      )
      .pipe(map(response => {
        return response;
      }));
  }
}

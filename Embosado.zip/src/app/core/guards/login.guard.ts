import { CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';
import { AuthService } from '../services/auth.service';

/**
 * Evita acceder a /login si ya hay sesión activa.
 * Si la sesión está activa, redirige a /tarjetas.
 * Si no, permite ver el login.
 */
export const loginGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  const router = inject(Router);

  return auth.sessionIsActive()
    ? router.createUrlTree(['/tarjetas'])
    : true;
};

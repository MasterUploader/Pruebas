import { Codigo } from "./codigo.model";

export interface PostRegistraImpresionResponseDto{
    impresionExitosa: boolean;
    codigo: Codigo;

}
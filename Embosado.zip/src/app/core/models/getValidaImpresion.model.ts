import { Codigo } from "./codigo.model";

export interface GetValidaImpresionDto {
    imprime: boolean;
    codigo: Codigo;
}
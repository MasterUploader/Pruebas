import { Tarjeta } from "./tarjeta.model";

export interface Agencia{
    agenciaAperturaNombre: string;
    agenciaAperturaCodigo: string;
    agenciaImprimeNombre: string;
    agenciaImprimeCodigo: string;
}
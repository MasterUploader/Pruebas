import { Agencia } from "./agencia.model";
import { Codigo } from "./codigo.model";
import { Tarjeta } from "./tarjeta.model";

export interface GetDetalleTarjetasImprimirResponseDto {
    agencia: Agencia;
    tarjetas: Tarjeta[];
    codigo: Codigo;
}
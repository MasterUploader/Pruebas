export interface Token{
    token: string;
    expiration: Date;
}
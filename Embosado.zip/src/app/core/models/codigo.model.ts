export interface Codigo {
    status: string;
    message: string;
    timeStamp: string;
    error: string;
}
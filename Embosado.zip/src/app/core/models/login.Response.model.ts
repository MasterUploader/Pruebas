import { ActiveDirectoryData } from "./ActiveDirectoryData.model";
import { Token } from "./Token.model";
import { Codigo } from "./codigo.model";

export interface LoginResponse{
    token: Token;
    activeDirectoryData: ActiveDirectoryData;
    codigo: Codigo;
}
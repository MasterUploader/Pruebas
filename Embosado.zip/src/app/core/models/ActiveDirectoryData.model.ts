export interface ActiveDirectoryData{
    agenciaAperturaCodigo: string,
    agenciaImprimeCodigo: string,
    nombreUsuario: string,
    usuarioICBS: string
}
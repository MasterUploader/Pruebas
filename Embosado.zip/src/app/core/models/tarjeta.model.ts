export interface Tarjeta {
    nombre: string;
    numero: string;
    fechaEmision: string;
    fechaVencimiento: string;
    motivo: string;
    numeroCuenta: string;
}
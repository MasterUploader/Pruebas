import { Component, NgModule } from '@angular/core';
import { RouterOutlet, RouterModule } from '@angular/router';
import { NavbarComponent } from './shared/components/navbar/navbar.component';
import { FooterComponent } from './shared/components/footer/footer.component';

import { routes } from './app.routes';

@Component({
    selector: 'app-root',
    imports: [RouterOutlet,  NavbarComponent, FooterComponent, ],
    templateUrl: './app.component.html',
    styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'EmbosadoTarjetasDebito';
}

@NgModule({
  declarations: [],
  imports:[
    AppComponent,
    RouterModule.forChild(routes)
  ]
  })
  export class AppModule{}

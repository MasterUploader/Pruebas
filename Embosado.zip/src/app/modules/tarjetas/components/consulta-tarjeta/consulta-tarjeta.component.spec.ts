import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ConsultaTarjetaComponent } from './consulta-tarjeta.component';

describe('ConsultaTarjetaComponent', () => {
  let component: ConsultaTarjetaComponent;
  let fixture: ComponentFixture<ConsultaTarjetaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ConsultaTarjetaComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ConsultaTarjetaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

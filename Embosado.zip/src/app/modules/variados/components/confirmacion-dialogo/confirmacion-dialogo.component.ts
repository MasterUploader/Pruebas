import { Component } from '@angular/core';
import { MatDialogModule, MatDialog } from '@angular/material/dialog';
import { TarjetaService } from '../../../../core/services/tarjeta.service';

@Component({
    selector: 'app-confirmacion-dialogo',
    imports: [MatDialogModule],
    templateUrl: './confirmacion-dialogo.component.html',
    styleUrl: './confirmacion-dialogo.component.css'
})
export class ConfirmacionDialogoComponent {

  constructor(private readonly dialog: MatDialog, private readonly tarjetaService: TarjetaService){

  }

}

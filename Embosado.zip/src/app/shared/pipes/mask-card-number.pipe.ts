import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'maskCardNumber',
  standalone: true
})
export class MaskCardNumberPipe implements PipeTransform {

  transform(cardNumber: string): string {
    if(!cardNumber) return '';
    let maskedSection = cardNumber.slice(4, -4).replace(/\d/g, '*');
    return `${cardNumber.slice(0,4)}${maskedSection}${cardNumber.slice(-4)}`;
  }

}

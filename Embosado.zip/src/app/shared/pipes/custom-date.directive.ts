import { Directive } from '@angular/core';

@Directive({
  selector: '[appCustomDate]',
  standalone: true
})
export class CustomDateDirective {

  constructor() { }

}

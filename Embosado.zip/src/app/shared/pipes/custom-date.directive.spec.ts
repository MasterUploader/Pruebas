import { CustomDateDirective } from './custom-date.directive';

describe('CustomDateDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomDateDirective();
    expect(directive).toBeTruthy();
  });
});

import { MaskCardNumberPipe } from './mask-card-number.pipe';

describe('MaskCardNumberPipe', () => {
  it('create an instance', () => {
    const pipe = new MaskCardNumberPipe();
    expect(pipe).toBeTruthy();
  });
});

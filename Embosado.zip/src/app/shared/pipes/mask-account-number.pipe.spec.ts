import { MaskAccountNumberPipe } from './mask-account-number.pipe';

describe('MaskAccountNumberPipe', () => {
  it('create an instance', () => {
    const pipe = new MaskAccountNumberPipe();
    expect(pipe).toBeTruthy();
  });
});

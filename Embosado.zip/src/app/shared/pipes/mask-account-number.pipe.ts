import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'maskAccountNumber',
  standalone: true
})
export class MaskAccountNumberPipe implements PipeTransform {

  transform(accountNumber: string): string {
    if(!accountNumber || accountNumber.length <=6) return accountNumber; //Numero demaciado corto
    const start = accountNumber.slice(0, (accountNumber.length/2)-1);
    const end = accountNumber.slice((accountNumber.length / 2) + 2);
    return `${start}***${end}`
  }

}
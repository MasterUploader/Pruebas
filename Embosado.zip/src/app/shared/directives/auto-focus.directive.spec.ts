import { AutoFocusDirective } from './auto-focus.directive';

describe('AutoFocusDirective', () => {
  it('should create an instance', () => {
    const directive = new AutoFocusDirective();
    expect(directive).toBeTruthy();
  });
});

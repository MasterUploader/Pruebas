export const environment = {
    production: false,
    apiBaseUrl: 'http://hncstg015189wws:4043' //UAT
} 
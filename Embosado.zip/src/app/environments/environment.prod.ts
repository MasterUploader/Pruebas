export const environment = {
    production: true,
    apiBaseUrl: 'https://hncstg010244wap:8044'  //PROD
} 
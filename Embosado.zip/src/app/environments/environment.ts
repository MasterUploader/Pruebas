export const environment = {
    production: true,
    apiBaseUrl: 'https://hncstg015089wws:4043' // DEV
   //apiBaseUrl: 'http://hncstg015189wws:4043' //UAT
    //apiBaseUrl: 'https://localhost:7275' //Localhost
  // apiBaseUrl: 'https://hncstg010244wap:8044'  //PROD
}

export const environment = {
    production: false,
    apiBaseUrl: 'https://localhost:7275' //Localhost
} 
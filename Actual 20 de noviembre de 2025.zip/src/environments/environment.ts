export const environment = {
  production: true,
  apiBase: 'https://api.tu-dominio.com' // TODO: ajustar a PROD
};

import { Component, ViewEncapsulation } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { HeaderComponent } from '../../../../shared/components/header/header.component';

/** Página de inicio con diseño modernizado. */
@Component({
  selector: 'app-inicio-page',
  standalone: true,
  imports: [CommonModule, RouterLink, HeaderComponent],
  templateUrl: './inicio-page.html',
  styleUrl: './inicio-page.scss',
  encapsulation: ViewEncapsulation.None
})
export class InicioPage {}

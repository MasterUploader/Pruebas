import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';

export interface BuscarRequest {
  documento: string;
  agencia?: number;
  fechaDesde?: string; // ISO
  fechaHasta?: string; // ISO
}
export interface Matricula {
  id: string;
  nombre: string;
  cuenta: string;
  estado: 'PENDIENTE' | 'IMPRESA' | 'RECHAZADA';
  fecha: string; // ISO
}
export interface PagedResult<T> {
  items: T[];
  total: number;
}

@Injectable({ providedIn: 'root' })
export class Impresion {
  private readonly http = inject(HttpClient);

  buscar(payload: BuscarRequest): Observable<Matricula[]> {
    return this.http.post<Matricula[]>('/impresion/buscar', payload);
  }

  /** Si backend devuelve array sin paginar, lo adaptamos a { items, total }. */
  buscarPaged(payload: BuscarRequest & { page?: number; pageSize?: number }): Observable<PagedResult<Matricula>> {
    return this.http.post<PagedResult<Matricula> | Matricula[]>('/impresion/buscar', payload).pipe(
      map(resp => Array.isArray(resp) ? { items: resp, total: resp.length } : resp)
    );
  }

  marcarImpresa(id: string): Observable<void> {
    return this.http.post<void>(`/impresion/${id}/imprimir`, {});
  }
}

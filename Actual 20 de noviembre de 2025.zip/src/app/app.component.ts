import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { HeaderComponent } from './shared/components/header/header.component';
import { FooterComponent } from './shared/components/footer/footer.component';
import { BreadcrumbComponent } from './shared/components/breadcrumb/breadcrumb.component';
import { LoadingComponent } from './shared/components/loading/loading.component';
import { ToastContainerComponent } from './shared/toast/toast-container.component';

/** Componente raíz con layout común (header, breadcrumb, outlet, footer). */
@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, HeaderComponent, FooterComponent, BreadcrumbComponent, LoadingComponent, ToastContainerComponent],
  template: `
    <ui-loading></ui-loading>
    <ui-toast-container></ui-toast-container>

    <ui-header></ui-header>
    <ui-breadcrumb></ui-breadcrumb>

    <main class="container">
      <router-outlet></router-outlet>
    </main>

    <ui-footer></ui-footer>
  `
})
export class AppComponent {}

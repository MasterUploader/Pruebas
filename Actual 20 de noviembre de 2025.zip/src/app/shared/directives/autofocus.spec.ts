import { Autofocus } from './autofocus';

describe('Autofocus', () => {
  it('should create an instance', () => {
    const directive = new Autofocus();
    expect(directive).toBeTruthy();
  });
});

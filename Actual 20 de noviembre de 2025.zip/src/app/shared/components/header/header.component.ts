import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

/** Encabezado simple con branding y navegación principal. */
@Component({
  selector: 'ui-header',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
  <header class="topbar">
    <div class="topbar__inner container">
      <div class="topbar__brand">
        <a routerLink="/inicio" class="brand-link">BiB Impresión</a>
      </div>
      <nav class="topbar__nav">
        <a routerLink="/inicio" routerLinkActive="is-active">Inicio</a>
        <a routerLink="/impresion" routerLinkActive="is-active">Impresión</a>
      </nav>
    </div>
  </header>
  `,
  styles: [`
  .topbar { position: sticky; top:0; z-index:10; background: var(--surface); border-bottom: 1px solid var(--border); }
  .topbar__inner { display:flex; align-items:center; justify-content:space-between; height: 3.25rem; }
  .topbar__nav { display:flex; gap: 1rem; }
  .topbar__nav a { color: var(--color-fg); text-decoration:none; padding:.25rem .5rem; border-radius:.25rem; }
  .topbar__nav a.is-active { background: var(--primary-100); color: var(--primary-600); }
  .brand-link { font-weight: 700; letter-spacing:.2px; }
  `]
})
export class HeaderComponent {}

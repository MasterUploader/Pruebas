import { Component, Input, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';

export interface ColumnDef {
  header: string;
  field: string;
}

@Component({
  selector: 'ui-data-table',
  standalone: true,
  imports: [CommonModule],
  template: `
  <table class="tabla">
    <thead>
      <tr>
        <th *ngFor="let c of columns" (click)="toggleSort(c.field)" style="cursor:pointer">
          {{c.header}} <span *ngIf="sortField()===c.field">{{ sortDir() === 'asc' ? '▲' : '▼' }}</span>
        </th>
      </tr>
    </thead>
    <tbody>
      <tr *ngFor="let row of sorted()">
        <td *ngFor="let c of columns">{{ row[c.field] }}</td>
      </tr>
    </tbody>
  </table>
  `
})
export class DataTableComponent {
  @Input() columns: ColumnDef[] = [];
  @Input({ required: true }) set data(value: any[]) { this._data.set(value ?? []); }
  _data = signal<any[]>([]);

  sortField = signal<string | null>(null);
  sortDir = signal<'asc' | 'desc'>('asc');

  toggleSort(field: string){
    if (this.sortField() === field){
      this.sortDir.set(this.sortDir() === 'asc' ? 'desc' : 'asc');
    } else {
      this.sortField.set(field);
      this.sortDir.set('asc');
    }
  }

  sorted = computed(() => {
    const data = [...this._data()];
    const field = this.sortField();
    if (!field) return data;
    const dir = this.sortDir();
    data.sort((a,b) => {
      const va = a?.[field]; const vb = b?.[field];
      if (va == null && vb == null) return 0;
      if (va == null) return -1;
      if (vb == null) return 1;
      return (va > vb ? 1 : va < vb ? -1 : 0) * (dir === 'asc' ? 1 : -1);
    });
    return data;
  });
}

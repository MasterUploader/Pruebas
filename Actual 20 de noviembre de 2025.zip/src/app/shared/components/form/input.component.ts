import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'ui-input',
  standalone: true,
  imports: [CommonModule],
  template: `
  <label class="form-label" *ngIf="label">{{label}}</label>
  <input class="input" [type]="type" [value]="value" (input)="onInput($event)" [placeholder]="placeholder" />
  <small class="help" *ngIf="help">{{help}}</small>
  `
})
export class InputComponent {
  @Input() label?: string;
  @Input() help?: string;
  @Input() placeholder?: string;
  @Input() type: string = 'text';
  @Input() value: string | number | null = null;

  @Output() valueChange = new EventEmitter<string>();

  onInput(e: Event){
    const v = (e.target as HTMLInputElement | null)?.value ?? '';
    this.value = v;
    this.valueChange.emit(v);
  }
}

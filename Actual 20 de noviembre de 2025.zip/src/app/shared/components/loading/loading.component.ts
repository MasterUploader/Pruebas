import { Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoadingService } from './loading.service';

@Component({
  selector: 'ui-loading',
  standalone: true,
  imports: [CommonModule],
  template: `
  <div class="loading-backdrop" *ngIf="visible()">
    <div class="loading-spinner"></div>
  </div>
  `,
  styles: [`
  .loading-backdrop{ position: fixed; inset:0; background: rgba(255,255,255,.6); display:flex; align-items:center; justify-content:center; z-index: 9999; }
  .loading-spinner{
    width: 52px; height: 52px; border-radius: 50%;
    border: 4px solid var(--primary-100); border-top-color: var(--primary-600); animation: spin 1s linear infinite;
  }
  @keyframes spin { to { transform: rotate(360deg) } }
  `]
})
export class LoadingComponent {
  private svc = inject(LoadingService);
  visible = computed(() => this.svc.active() > 0);
}

import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';

/**
 * Diálogo de confirmación muy liviano usando las clases .dialog / .dialog-backdrop.
 * Controlado por [open]. Emite (confirm) y (cancel).
 */
@Component({
  selector: 'ui-confirm',
  standalone: true,
  imports: [CommonModule],
  template: `
  <div class="dialog-backdrop" [class.open]="open" (click)="onCancel()"></div>
  <div class="dialog" [class.open]="open" role="dialog" aria-modal="true" aria-labelledby="confirm-title">
    <div class="dialog__panel">
      <div class="card__header" id="confirm-title">{{ title }}</div>
      <div class="card__body">
        <p>{{ message }}</p>
      </div>
      <div class="card__footer" style="display:flex; gap:.5rem; justify-content:flex-end;">
        <button type="button" class="btn btn--ghost" (click)="onCancel()">{{ cancelText }}</button>
        <button type="button" class="btn" (click)="onConfirm()">{{ confirmText }}</button>
      </div>
    </div>
  </div>`
})
export class ConfirmComponent {
  @Input() open = false;
  @Input() title = 'Confirmar';
  @Input() message = '¿Desea continuar?';
  @Input() confirmText = 'Sí';
  @Input() cancelText = 'Cancelar';

  @Output() confirm = new EventEmitter<void>();
  @Output() cancel = new EventEmitter<void>();

  onConfirm() { this.confirm.emit(); }
  onCancel() { this.cancel.emit(); }
}

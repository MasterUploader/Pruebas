import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

/** Tarjeta CR80 (85.6 x 54 mm) para layouts de impresión. */
@Component({
  selector: 'ui-card-print',
  standalone: true,
  imports: [CommonModule],
  template: `
  <section class="card-print">
    <ng-content></ng-content>
  </section>
  `,
  styles: [`
  .card-print{ width: 85.6mm; height: 54mm; border: 1px solid var(--border); border-radius: 3mm; padding: 4mm; }
  `]
})
export class CardPrintComponent { }

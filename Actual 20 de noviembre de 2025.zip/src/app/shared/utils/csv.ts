/**
 * Exporta un arreglo de objetos a CSV (UTF-8 con BOM) y dispara la descarga.
 * Si el arreglo está vacío, exporta solo cabeceras.
 */
export function exportToCsv(filename: string, rows: any[]) {
  const data = rows ?? [];
  const headers = Array.from(
    data.reduce<Set<string>>((acc, r) => {
      Object.keys(r ?? {}).forEach(k => acc.add(k));
      return acc;
    }, new Set<string>())
  );

  const escape = (val: any) => {
    if (val === null || val === undefined) return '';
    const s = String(val).replace(/"/g, '""');
    return /[",\n]/.test(s) ? `"${s}"` : s;
  };

  const csv = [
    headers.join(','),
    ...data.map(r => headers.map(h => escape((r as any)[h])).join(','))
  ].join('\n');

  // UTF-8 BOM para Excel
  const blob = new Blob([new Uint8Array([0xEF,0xBB,0xBF]), csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename.endsWith('.csv') ? filename : filename + '.csv';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

import { Component, inject } from '@angular/core';
import { CommonModule, NgClass } from '@angular/common';
import { ToastService } from './toast.service';

@Component({
  selector: 'ui-toast-container',
  standalone: true,
  imports: [CommonModule, NgClass],
  template: `
  <div class="toasts">
    <div class="toast" *ngFor="let t of svc.toasts()" [ngClass]="'toast--' + t.type" (click)="svc.dismiss(t.id)">
      {{t.message}}
    </div>
  </div>
  `,
  styles: [`
  .toasts{ position: fixed; right: 1rem; bottom: 1rem; display: grid; gap: .5rem; z-index: 10000; }
  .toast{ padding: .5rem .75rem; border-radius: var(--radius); border:1px solid var(--border); background: var(--surface); box-shadow: 0 2px 8px rgba(0,0,0,.1); cursor: pointer; }
  .toast--success{ border-color: #d1fae5; background: #ecfdf5; color: #065f46; }
  .toast--error{ border-color: #fecaca; background: #fef2f2; color: #991b1b; }
  .toast--info{ border-color: #bfdbfe; background: #eff6ff; color: #1e3a8a; }
  .toast--warn{ border-color: #fde68a; background: #fffbeb; color: #7c2d12; }
  `]
})
export class ToastContainerComponent {
  svc = inject(ToastService);
}

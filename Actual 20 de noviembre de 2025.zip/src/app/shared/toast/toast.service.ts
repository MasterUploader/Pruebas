import { Injectable, signal } from '@angular/core';

export interface Toast {
  id: number;
  type: 'success' | 'error' | 'info' | 'warn';
  message: string;
  timeout?: number;
}

@Injectable({ providedIn: 'root' })
export class ToastService {
  private seq = 1;
  private _toasts = signal<Toast[]>([]);
  readonly toasts = this._toasts.asReadonly();

  show(message: string, type: Toast['type']='info', timeout=3000) {
    const id = this.seq++;
    const t: Toast = { id, type, message, timeout };
    this._toasts.update(xs => [...xs, t]);
    if (timeout > 0) setTimeout(() => this.dismiss(id), timeout);
  }
  success(m: string, timeout=3000){ this.show(m, 'success', timeout); }
  error(m: string, timeout=5000){ this.show(m, 'error', timeout); }
  info(m: string, timeout=3000){ this.show(m, 'info', timeout); }
  warn(m: string, timeout=3000){ this.show(m, 'warn', timeout); }
  dismiss(id: number){ this._toasts.update(xs => xs.filter(x => x.id !== id)); }
  clear(){ this._toasts.set([]); }
}

import { Component, ViewEncapsulation, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from '../../../../../core/auth/auth.service';
import { ToastService } from '../../../../../shared/toast/toast.service';
import { LoadingService } from '../../../../../shared/components/loading/loading.service';

/**
 * Login moderno: se agregan manejadores explícitos para los eventos de input
 * y así evitar 'as HTMLInputElement' en el template (no soportado por el parser).
 */
@Component({
  selector: 'app-login-page',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './login-page.html',
  styleUrl: './login-page.scss',
  encapsulation: ViewEncapsulation.None
})
export class LoginPage {
  private readonly auth = inject(AuthService);
  private readonly toast = inject(ToastService);
  private readonly loading = inject(LoadingService);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);

  // Signals para los campos
  username = signal('');
  password = signal('');
  remember = signal(true);
  showPwd = signal(false);
  submitting = signal(false);

  /** Alterna visibilidad de contraseña. */
  toggleShowPwd() { this.showPwd.update(v => !v); }

  // --- Handlers seguros para el template ---
  onUserInput(value: string) { this.username.set(value ?? ''); }
  onPwdInput(value: string) { this.password.set(value ?? ''); }
  onRememberChange(checked: boolean) { this.remember.set(!!checked); }

  /** Envía credenciales al backend. */
  onSubmit() {
    if (!this.username() || !this.password()) {
      this.toast.warn('Ingrese usuario y contraseña.');
      return;
    }
    this.submitting.set(true);
    this.loading.show();
    this.auth.login({ username: this.username(), password: this.password(), remember: this.remember() })
      .subscribe({
        next: _ => {
          const ret = this.route.snapshot.queryParamMap.get('returnUrl') || '/inicio';
          this.toast.success('Bienvenido');
          this.router.navigateByUrl(ret);
        },
        error: _ => {},
        complete: () => { this.submitting.set(false); this.loading.hide(); }
      });
  }
}

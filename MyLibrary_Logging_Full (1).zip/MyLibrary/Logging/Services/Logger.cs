using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Serilog;
using Serilog.Formatting.Compact;
using MyLibrary.Logging.Abstractions;

namespace MyLibrary.Logging.Services
{
    public class Logger : ILoggerService
    {
        private readonly Serilog.ILogger _logger;
        private readonly LogLevel _configuredLogLevel;
        private readonly string _logFilePath;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public static readonly string LibraryVersion;

        static Logger()
        {
            LibraryVersion = Assembly.GetExecutingAssembly().GetName().Version?.ToString() ?? "Unknown";
        }

        public Logger(LoggingConfiguration config, IHttpContextAccessor httpContextAccessor)
        {
            _configuredLogLevel = config.MinimumLogLevel;
            _logFilePath = config.LogFilePath;
            _httpContextAccessor = httpContextAccessor;

            _logger = new LoggerConfiguration()
                .MinimumLevel.Information()
                .WriteTo.File(new CompactJsonFormatter(), GetExecutionLogFilePath(), rollingInterval: RollingInterval.Day)
                .CreateLogger();
        }

        private string GetExecutionLogFilePath()
        {
            var executionId = Guid.NewGuid().ToString();
            var dateTime = DateTime.UtcNow.ToString("yyyyMMdd_HHmmss");
            var endpoint = _httpContextAccessor.HttpContext?.Request?.Path.Value?.Replace("/", "_") ?? "UnknownEndpoint";
            return Path.Combine(_logFilePath, $"execution_{executionId}_{dateTime}_{endpoint}.log");
        }

        public async Task AddSingleLogAsync(string message, LogLevel level)
        {
            if (level < _configuredLogLevel) return;
            var logEntry = $"[{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss}] - {message}";
            _logger.Information(logEntry);
            await Task.CompletedTask;
        }

        public async Task AddDetailedObjectLogAsync(object obj, LogLevel level)
        {
            if (level < _configuredLogLevel) return;
            var properties = obj.GetType().GetProperties()
                .Where(p => !IsSensitiveProperty(p.Name))
                .Select(prop => new { prop.Name, Value = prop.GetValue(obj) })
                .ToDictionary(p => p.Name, p => p.Value);
            var formattedLog = JsonSerializer.Serialize(properties, new JsonSerializerOptions { WriteIndented = true });
            _logger.Information(formattedLog);
            await Task.CompletedTask;
        }

        private bool IsSensitiveProperty(string propertyName)
        {
            var sensitiveFields = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            {
                "password", "token", "apikey", "secret", "ssn", "creditcard"
            };
            return sensitiveFields.Contains(propertyName);
        }

        public async Task LogExceptionAsync(Exception ex)
        {
            var exceptionDetails = new
            {
                ExceptionType = ex.GetType().FullName,
                Message = ex.Message,
                StackTrace = ex.StackTrace,
                InnerException = ex.InnerException?.Message,
                Source = ex.Source,
                Timestamp = DateTime.UtcNow
            };
            _logger.Error(JsonSerializer.Serialize(exceptionDetails));
            await Task.CompletedTask;
        }
    }
}
import { Component, ViewEncapsulation } from '@angular/core';
import { CommonModule, NgFor, NgIf, NgClass } from '@angular/common';

/** IndexPage modernizada: reemplaza directivas AngularJS (ng-href, ng-repeat) por Angular. */
@Component({
  selector: 'app-index-page',
  standalone: true,
  imports: [CommonModule, NgFor, NgIf, NgClass],
  templateUrl: './page.html',
  styleUrl: './page.scss',
  encapsulation: ViewEncapsulation.None
})
export class IndexPage {
  /** Cabecera/branding */
  menu = { link: '/inicio', value: 'BiB Impresión' };

  /** Menú principal (antiguo ng-repeat="item in items") */
  items = [
    { class: 'nav-item', link: '/impresion', name: 'Impresión' },
    { class: 'nav-item', link: '/reportes', name: 'Reportes' },
    { class: 'nav-item', link: '/configuracion', name: 'Configuración' }
  ];

  /** Visibilidad del acceso de usuario */
  showUserLogin = { user: 'Usuario' };
}

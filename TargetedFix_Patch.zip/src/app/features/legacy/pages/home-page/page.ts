import { Component, ViewEncapsulation, signal } from '@angular/core';
import { CommonModule, NgClass, NgIf, NgFor } from '@angular/common';

/** HomePage modernizada: expone 'metadata', 'date', 'month' y 'getMonth' para el template legacy. */
@Component({
  selector: 'app-home-page',
  standalone: true,
  imports: [CommonModule, NgClass, NgIf, NgFor],
  templateUrl: './page.html',
  styleUrl: './page.scss',
  encapsulation: ViewEncapsulation.None
})
export class HomePage {
  /** Información de cabecera usada en el HTML legacy. Ajusta desde un servicio si lo necesitas. */
  metadata = {
    image: 'assets/placeholder.jpg',
    title: 'Bienvenido',
    description: 'Sistema de Impresión de Matrícula',
    content: ''
  };

  /** Fecha mostrada en el calendario/encabezado del home legacy. */
  date = new Date();
  /** Nombre de mes con helper. */
  month = this.getMonth(this.date.getMonth());

  /** Devuelve el nombre del mes (0..11). */
  getMonth(m: number): string {
    const names = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
    return names[(m ?? 0) % 12];
  }
}

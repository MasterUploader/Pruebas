import { HttpInterceptorFn } from '@angular/common/http';
import { environment } from '../../../environments/environment';

/**
 * Prefija apiBase a URLs relativas y agrega Authorization si existe token.
 */
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const isAbsolute = /^https?:\/\//i.test(req.url);
  const url = isAbsolute ? req.url : `${environment.apiBase}${req.url}`;

  const token = localStorage.getItem('token'); // Reemplaza por tu AuthService si aplica
  const cloned = token
    ? req.clone({ url, setHeaders: { Authorization: `Bearer ${token}` } })
    : req.clone({ url });

  return next(cloned);
};

import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { catchError, throwError } from 'rxjs';

/**
 * Centraliza manejo de errores HTTP (logging, 401/403, etc.).
 */
export const errorInterceptor: HttpInterceptorFn = (req, next) =>
  next(req).pipe(
    catchError((err: HttpErrorResponse) => {
      // Ejemplo: redirigir en 401
      // if (err.status === 401) { window.location.href = '/login'; }
      console.error('[HTTP ERROR]', err);
      return throwError(() => err);
    })
  );

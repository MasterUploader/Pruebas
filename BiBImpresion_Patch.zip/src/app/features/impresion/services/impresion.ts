import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface BuscarRequest {
  documento: string;
  agencia?: number;
  fechaDesde?: string; // ISO
  fechaHasta?: string; // ISO
}

export interface Matricula {
  id: string;
  nombre: string;
  cuenta: string;
  estado: 'PENDIENTE' | 'IMPRESA' | 'RECHAZADA';
  fecha: string; // ISO
}

@Injectable({ providedIn: 'root' })
export class Impresion {
  private readonly http = inject(HttpClient);

  buscar(payload: BuscarRequest): Observable<Matricula[]> {
    return this.http.post<Matricula[]>('/impresion/buscar', payload);
  }

  marcarImpresa(id: string): Observable<void> {
    return this.http.post<void>(`/impresion/${id}/imprimir`, {});
  }
}

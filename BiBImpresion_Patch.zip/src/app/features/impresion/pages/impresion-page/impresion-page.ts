import { Component, ViewEncapsulation, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { finalize } from 'rxjs';
import { Impresion, Matricula } from '../../services/impresion';

/**
 * Página de Impresión (standalone) con Signals.
 */
@Component({
  selector: 'app-impresion-page',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './impresion-page.html',
  styleUrl: './impresion-page.scss',
  encapsulation: ViewEncapsulation.None
})
export class ImpresionPage {
  private readonly api = inject(Impresion);

  readonly items = signal<Matricula[]>([]);
  readonly loading = signal(false);
  readonly puedeImprimir = signal(true);
  readonly total = computed(() => this.items().length);

  buscar(documento = ''): void {
    this.loading.set(true);
    this.api.buscar({ documento })
      .pipe(finalize(() => this.loading.set(false)))
      .subscribe(this.items.set);
  }

  imprimir(m: Matricula): void {
    this.api.marcarImpresa(m.id).subscribe(() => {
      this.items.update(xs => xs.map(x => x.id === m.id ? { ...x, estado: 'IMPRESA' } : x));
      setTimeout(() => window.print(), 0);
    });
  }
}

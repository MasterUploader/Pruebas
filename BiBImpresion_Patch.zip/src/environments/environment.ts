export const environment = {
  production: false,
  apiBase: 'http://localhost:5050' // TODO: Ajusta al host real de tu API
};

Cómo usar este patch:

1) Descomprime el ZIP en la RAÍZ de tu proyecto Angular (la carpeta que contiene 'src').
   - No sobrescribe main.ts ni app.component.ts.
   - Crea/actualiza:
     - src/environments/environment.ts
     - src/app/app.routes.ts
     - src/app/app.config.ts
     - src/app/core/http/auth.interceptor.ts
     - src/app/core/http/error.interceptor.ts
     - src/app/features/impresion/services/impresion.ts
     - src/app/features/impresion/pages/impresion-page/(.ts/.html/.scss)
     - src/styles/** y src/styles.scss

2) Revisa 'environment.apiBase' y ajusta tu host.

3) Si usas 'src/assets', añade en angular.json dentro de build.options:
   "assets": [
     { "glob": "**/*", "input": "public" },
     "src/assets"
   ],
   "styles": ["src/styles.scss"]

4) Arranca:
   npm start

Rutas:
- /impresion (lazy, loadComponent)

import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'inicio' },
  {
    path: 'inicio',
    loadComponent: () =>
      import('./features/inicio/pages/inicio-page/inicio-page')
        .then(m => m.InicioPage)
  },
  {
    path: 'impresion',
    loadComponent: () =>
      import('./features/impresion/pages/impresion-page/impresion-page')
        .then(m => m.ImpresionPage)
  },
  { path: '**', redirectTo: 'inicio' }
];

# MyLibrary.Logging - Guía de Integración

## 📌 Características Clave
✅ **Captura de logs automáticos en controladores y métodos internos.**  
✅ **Registro de excepciones sin intervención manual.**  
✅ **Manejo de flujo de ejecución con `ExecutionId` único por solicitud.**  
✅ **Middleware de ejecución y excepciones para registro automático.**  

## 📌 Configuración en `appsettings.json`
```json
{
  "LoggingConfig": {
    "MinimumLogLevel": "Info",
    "LogFilePath": "logs/"
  }
}
```

## 📌 Configuración en `Program.cs`
```csharp
using MyLibrary.Logging.Helpers;
using MyLibrary.Logging.Filters;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers(options =>
{
    options.Filters.Add<ExecutionLoggingFilter>();
});

var app = builder.Build();
app.UseMiddleware<ExceptionHandlingMiddleware>();
app.UseMiddleware<ExecutionLoggingMiddleware>();

app.MapControllers();
app.Run();
```
✅ **Con estos cambios, tu API capturará logs automáticamente.**

Si necesitas más personalización, revisa los archivos en la librería.

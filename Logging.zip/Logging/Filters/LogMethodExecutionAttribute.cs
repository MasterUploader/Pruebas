﻿using Castle.DynamicProxy;
using Logging.Abstractions;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using System.Diagnostics;
using System.Text.Json;

namespace Logging.Filters
{
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = false)]
    public class LogMethodExecutionInterceptor : Attribute, IInterceptor
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        public LogMethodExecutionInterceptor(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor ?? throw new ArgumentNullException(nameof(httpContextAccessor));
        }

        public void Intercept(IInvocation invocation)
        {
            var httpContext = _httpContextAccessor.HttpContext;

            if (httpContext == null)
            {
                throw new InvalidOperationException("HttpContext is not available.");
            }

            var loggingService = httpContext.RequestServices.GetService<ILoggingService>();

            if (loggingService == null)
            {
                throw new InvalidOperationException("ILoggingService is not registered in DI.");
            }

            var methodName = invocation.Method.Name;
            var className = invocation.TargetType.Name;

            // Registrar inicio del método
           // loggingService.AddSingleLog($"Inicio de ejecución del método {className}.{methodName}");

            var stopwatch = Stopwatch.StartNew();

            try
            {
                invocation.Proceed();
                stopwatch.Stop();

                // Registrar parámetros de salida
                //  var outputParams = invocation.ReturnValue;

                // Capturar parámetros de salida si no es una tarea asincrónica
                string outputParams = invocation.ReturnValue != null
                    ? JsonSerializer.Serialize(invocation.ReturnValue, new JsonSerializerOptions { WriteIndented = true })
                    : "Sin retorno (void)";

              //  loggingService.AddMethodExitLog(methodName, outputParams, httpContext);

              //  loggingService.AddSingleLog($"Método {className}.{methodName} ejecutado en {stopwatch.ElapsedMilliseconds} ms");
            }
            catch (Exception ex)
            {
                loggingService.AddExceptionLog(ex);
                throw;
            }
        }
    }
}

﻿using Logging.Models;
using Microsoft.AspNetCore.Http;
using System.Data.Common;

namespace Logging.Abstractions
{
    /// <summary>
    /// Define la interfaz para el servicio de logging.
    /// </summary>
    public interface ILoggingService
    {
        /// <summary>
        /// MEtodo que guarda logs
        /// </summary>
        /// <param name="context"></param>
        /// <param name="logContent"></param>
        void WriteLog(HttpContext? context, string logContent);
        /// <summary>
        /// Agrega un log de texto simple.
        /// </summary>
        void AddSingleLog(string message);

        /// <summary>
        /// Registra un objeto en los logs con un nombre descriptivo.
        /// </summary>
        /// <param name="objectName">Nombre descriptivo del objeto.</param>
        /// <param name="logObject">Objeto a registrar.</param>
        void AddObjLog(string objectName, object logObject);

        /// <summary>
        /// Registra un objeto en los logs sin necesidad de un nombre específico.
        /// Se intentará capturar automáticamente el tipo de objeto.
        /// </summary>
        /// <param name="logObject">Objeto a Registrar</param>
        void AddObjLog(object logObject);

        /// <summary>
        /// Registra una excepción en los logs.
        /// </summary>
        void AddExceptionLog(Exception ex);

        /// <summary>
        /// Registra un log estructurado de éxito para una operación SQL usando un modelo preformateado.
        /// </summary>
        /// <param name="model">Modelo con los datos del comando SQL ejecutado.</param>
        /// <param name="context">Contexto HTTP para trazabilidad opcional.</param>
        void LogDatabaseSuccess(SqlLogModel model, HttpContext? context = null);

        /// <summary>
        /// Registra un log de error para un comando SQL que lanzó una excepción.
        /// </summary>
        /// <param name="command">El comando ejecutado que causó el error.</param>
        /// <param name="ex">La excepción lanzada.</param>
        /// <param name="context">Contexto HTTP actual para extraer información adicional (opcional).</param>
        void LogDatabaseError(DbCommand command, Exception ex, HttpContext? context = null);
    }
}

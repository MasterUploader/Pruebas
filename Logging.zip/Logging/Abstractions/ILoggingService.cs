﻿using Microsoft.AspNetCore.Http;
using System.Data.Common;

namespace Logging.Abstractions
{
    /// <summary>
    /// Define la interfaz para el servicio de logging.
    /// </summary>
    public interface ILoggingService
    {
        /// <summary>
        /// MEtodo que guarda logs
        /// </summary>
        /// <param name="context"></param>
        /// <param name="logContent"></param>
        void WriteLog(HttpContext? context, string logContent);
        /// <summary>
        /// Agrega un log de texto simple.
        /// </summary>
        void AddSingleLog(string message);

        /// <summary>
        /// Registra un objeto en los logs con un nombre descriptivo.
        /// </summary>
        /// <param name="objectName">Nombre descriptivo del objeto.</param>
        /// <param name="logObject">Objeto a registrar.</param>
        void AddObjLog(string objectName, object logObject);

        /// <summary>
        /// Registra un objeto en los logs sin necesidad de un nombre específico.
        /// Se intentará capturar automáticamente el tipo de objeto.
        /// </summary>
        /// <param name="logObject">Objeto a Registrar</param>
        void AddObjLog(object logObject);

        /// <summary>
        /// Registra una excepción en los logs.
        /// </summary>
        void AddExceptionLog(Exception ex);

        /// <summary>
        /// Registra un log de éxito para un comando SQL ejecutado correctamente.
        /// </summary>
        /// <param name="command">El comando ejecutado (SELECT, INSERT, etc.).</param>
        /// <param name="elapsedMs">El tiempo de ejecución en milisegundos.</param>
        /// <param name="context">Contexto HTTP actual para extraer TraceId, usuario, etc. (opcional).</param>
        /// <param name="executionCount" >Cantidad de ejecuciones.</param>
        /// <param name="totalAffectedRows">Cantidad de Filas Afectadas</param>
        void LogDatabaseSuccess(DbCommand command, long elapsedMs, HttpContext? context = null, int? totalAffectedRows = null, int? executionCount = null);

        /// <summary>
        /// Registra un log de error para un comando SQL que lanzó una excepción.
        /// </summary>
        /// <param name="command">El comando ejecutado que causó el error.</param>
        /// <param name="ex">La excepción lanzada.</param>
        /// <param name="context">Contexto HTTP actual para extraer información adicional (opcional).</param>
        void LogDatabaseError(DbCommand command, Exception ex, HttpContext? context = null);
    }
}

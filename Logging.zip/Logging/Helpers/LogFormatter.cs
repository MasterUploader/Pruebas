﻿using Logging.Extensions;
using Logging.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using System.Data.Common;
using System.Text;
using System.Text.Json;

namespace Logging.Helpers;

/// <summary>
/// Clase estática encargada de formatear los logs con la estructura pre definida.
/// </summary>
public static class LogFormatter
{
    /// <summary>
    /// Formato de Log para FormatBeginLog.
    /// </summary>
    /// <returns>Un string con el formato de Log para FormatBeginLog.</returns>
    public static string FormatBeginLog()
    {
        var sb = new StringBuilder();

        sb.AppendLine("---------------------------Inicio de Log-------------------------");
        sb.AppendLine($"Inicio: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
        sb.AppendLine("-------------------------------------------------------------------");

        return sb.ToString();
    }

    /// <summary>
    /// Formato de Log para FormatEndLog.
    /// </summary>
    /// <returns>Un string con el formato de Log para FormatEndLog.</returns>
    public static string FormatEndLog()
    {
        var sb = new StringBuilder();

        sb.AppendLine("---------------------------Fin de Log-------------------------");
        sb.AppendLine($"Final: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
        sb.AppendLine("-------------------------------------------------------------------");

        return sb.ToString();

    }

    /// <summary>
    /// Formatea la información del entorno, incluyendo datos adicionales si están disponibles.
    /// </summary>
    /// <param name="application">Nombre de la aplicación.</param>
    /// <param name="env">Nombre del entorno (Development, Production, etc.).</param>
    /// <param name="contentRoot">Ruta raíz del contenido.</param>
    /// <param name="executionId">Identificador único de la ejecución.</param>
    /// <param name="clientIp">Dirección IP del cliente.</param>
    /// <param name="userAgent">Agente de usuario del cliente.</param>
    /// <param name="machineName">Nombre de la máquina donde corre la aplicación.</param>
    /// <param name="os">Sistema operativo del servidor.</param>
    /// <param name="host">Host del request recibido.</param>
    /// <param name="distribution">Distribución personalizada u origen (opcional).</param>
    /// <param name="extras">Diccionario con información adicional opcional.</param>
    /// <returns>Texto formateado con la información del entorno.</returns>
    public static string FormatEnvironmentInfo(
        string application, string env, string contentRoot, string executionId,
        string clientIp, string userAgent, string machineName, string os,
        string host, string distribution, Dictionary<string, string>? extras = null)
    {
        var sb = new StringBuilder();

        sb.AppendLine("---------------------------Enviroment Info-------------------------");
        sb.AppendLine($"Inicio: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
        sb.AppendLine("-------------------------------------------------------------------");
        sb.AppendLine($"Application: {application}");
        sb.AppendLine($"Environment: {env}");
        sb.AppendLine($"ContentRoot: {contentRoot}");
        sb.AppendLine($"Execution ID: {executionId}");
        sb.AppendLine($"Client IP: {clientIp}");
        sb.AppendLine($"User Agent: {userAgent}");
        sb.AppendLine($"Machine Name: {machineName}");
        sb.AppendLine($"OS: {os}");
        sb.AppendLine($"Host: {host}");
        sb.AppendLine($"Distribución: {distribution}");

        if (extras is not null && extras.Any())
        {
            sb.AppendLine("  -- Extras del HttpContext --");
            foreach (var kvp in extras)
            {
                sb.AppendLine($"    {kvp.Key,-20}: {kvp.Value}");
            }
        }

        sb.AppendLine(new string('-', 70));
        sb.AppendLine("---------------------------Enviroment Info-------------------------");
        sb.AppendLine($"Fin: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
        sb.AppendLine("-------------------------------------------------------------------");

        return sb.ToString();
    }

    /// <summary>
    /// Formatea los parámetros de entrada de un método antes de guardarlos en el log.
    /// </summary>
    public static string FormatInputParameters(IDictionary<string, object> parameters)
    {
        var sb = new StringBuilder();

        sb.AppendLine("-----------------------Parámetros de Entrada-----------------------------------");

        if (parameters == null || parameters.Count == 0)
        {
            sb.AppendLine("Sin parámetros de entrada.");
        }
        else
        {
            foreach (var param in parameters)
            {
                if (param.Value == null)
                {
                    sb.AppendLine($"{param.Key} = null");
                }
                else if (param.Value.GetType().IsPrimitive || param.Value is string)
                {
                    sb.AppendLine($"{param.Key} = {param.Value}");
                }
                else
                {
                    string json = JsonSerializer.Serialize(param.Value, new JsonSerializerOptions { WriteIndented = true });
                    sb.AppendLine($"Objeto {param.Key} =\n{json}");
                }
            }
        }

        sb.AppendLine("-----------------------Parámetros de Entrada-----------------------------------");

        return sb.ToString();
    }

    /// <summary>
    /// Formato de Log para Request.
    /// </summary>
    /// <param name="context">Contexto HTTP de la petición.</param>
    /// <param name="method">Endpoint.</param>
    /// <param name="path">Ruta del Endpoint.</param>
    /// <param name="queryParams">Parametros del Query.</param>
    /// <param name="body">Cuerpo de la petición.</param>
    /// <returns>uString con el Log Formateado.</returns>
    public static string FormatRequestInfo(HttpContext context, string method, string path, string queryParams, string body)
    {
        string formattedJson = string.IsNullOrWhiteSpace(body) ? "  (Sin cuerpo en la solicitud)" : StringExtensions.FormatJson(body, 30); // Aplica indentación controlada
        var routeData = context.GetRouteData();
        string controllerName = routeData?.Values["controller"]?.ToString() ?? "Desconocido";
        string actionName = routeData?.Values["action"]?.ToString() ?? "Desconocido";

        var sb = new StringBuilder();

        sb.AppendLine(FormatControllerBegin(controllerName, actionName));
        sb.AppendLine("----------------------------------Request Info---------------------------------");
        sb.AppendLine($"Inicio: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
        sb.AppendLine("-------------------------------------------------------------------------------");
        sb.AppendLine($"Método: {method}");
        sb.AppendLine($"URL: {path}{queryParams}");
        sb.AppendLine($"Cuerpo:");
        sb.AppendLine($"{formattedJson}");
        sb.AppendLine("----------------------------------Request Info---------------------------------");
        sb.AppendLine($"Fin: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
        sb.AppendLine("-------------------------------------------------------------------------------");

        return sb.ToString();
    }

    /// <summary>
    /// Formato de la información de Respuesta.
    /// </summary>
    /// <param name="context">Contexto HTTP de la petición.</param>
    /// <param name="statusCode">Codigo de Estádo de la respuesta.</param>
    /// <param name="headers">Cabeceras de la respuesta.</param>
    /// <param name="body">Cuerpo de la Respuesta.</param>
    /// <returns>String con el Log Formateado.</returns>
    public static string FormatResponseInfo(HttpContext context, string statusCode, string headers, string body)
    {
        string formattedJson = string.IsNullOrWhiteSpace(body) ? "        (Sin cuerpo en la respuesta)" : StringExtensions.FormatJson(body, 30); // Aplica indentación controlada
        var routeData = context.GetRouteData();
        string controllerName = routeData?.Values["controller"]?.ToString() ?? "Desconocido";
        string actionName = routeData?.Values["action"]?.ToString() ?? "Desconocido";

        var sb = new StringBuilder();

        sb.AppendLine("----------------------------------Response Info---------------------------------");
        sb.AppendLine($"Inicio: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
        sb.AppendLine("-------------------------------------------------------------------------------");
        sb.AppendLine($"Código Estado: {statusCode}");
        sb.AppendLine($"Cuerpo:");
        sb.AppendLine($"{formattedJson}");
        sb.AppendLine("----------------------------------Response Info---------------------------------");
        sb.AppendLine($"Fin: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
        sb.AppendLine("-------------------------------------------------------------------------------");
        sb.AppendLine(FormatControllerEnd(controllerName, actionName));

        return sb.ToString();
    }

    /// <summary>
    /// Método que formatea el Inicio del Log del Controlador.
    /// </summary>
    /// <param name="controllerName">Nombre del controlador.</param>
    /// <param name="actionName">Tipo de Acción.</param>
    /// <returns>String con el log formateado.</returns>
    private static string FormatControllerBegin(string controllerName, string actionName)
    {
        var sb = new StringBuilder();

        sb.AppendLine("-------------------------------------------------------------------------------");
        sb.AppendLine($"Controlador: {controllerName}");
        sb.AppendLine($"Action: {actionName}");
        sb.AppendLine($"Inicio: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
        sb.AppendLine("-------------------------------------------------------------------------------");
        sb.AppendLine("-------------------------------------------------------------------------------");

        return sb.ToString();
    }

    /// <summary>
    /// Método que formatea el fin del Log del Controlador.
    /// </summary>
    /// <param name="controllerName">Nombre del Controlador.</param>
    /// <param name="actionName">Tipo de Acción.</param>
    /// <returns>String con el log formateado.</returns>
    private static string FormatControllerEnd(string controllerName, string actionName)
    {
        var sb = new StringBuilder();

        sb.AppendLine("-------------------------------------------------------------------------------");
        sb.AppendLine($"Controlador: {controllerName}");
        sb.AppendLine($"Action: {actionName}");
        sb.AppendLine($"Fin: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
        sb.AppendLine("-------------------------------------------------------------------------------");

        return sb.ToString();
    }

    /// <summary>
    /// Método que formatea la estructura de inicio un método.
    /// </summary>
    /// <param name="methodName">Nombre del Método.</param>
    /// <param name="parameters">Parametros del metodo.</param>
    /// <returns>String con el log formateado.</returns>
    public static string FormatMethodEntry(string methodName, string parameters)
    {
        var sb = new StringBuilder();

        sb.AppendLine("-------------------------------------------------------------------------------");
        sb.AppendLine($"Método: {methodName}");
        sb.AppendLine($"Inicio: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
        sb.AppendLine("-------------------------------------------------------------------------------");
        sb.AppendLine("Parámetros de Entrada:");
        sb.AppendLine($"{parameters}");

        return sb.ToString();

    }

    /// <summary>
    /// Método que formatea la estructura de salida de un método.
    /// </summary>
    /// <param name="methodName">Nombre del Método.</param>
    /// <param name="returnValue">Valores de Retorno.</param>
    /// <returns>String con el Log Formateado.</returns>
    public static string FormatMethodExit(string methodName, string returnValue)
    {
        var sb = new StringBuilder();

        sb.AppendLine("-------------------------------------------------------------------------------");
        sb.AppendLine($"Método: {methodName}");
        sb.AppendLine($"Fin: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
        sb.AppendLine("-------------------------------------------------------------------------------");

        return sb.ToString();

    }

    /// <summary>
    /// Método de formatea un Log Simple.
    /// </summary>
    /// <param name="message">Cuerpo del texto del Log.</param>
    /// <returns>String con el Log formateado.</returns>
    public static string FormatSingleLog(string message)
    {
        var sb = new StringBuilder();

        sb.AppendLine("----------------------------------Single Log-----------------------------------");
        sb.AppendLine($"Inicio: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
        sb.AppendLine("-------------------------------------------------------------------------------");
        sb.AppendLine($"{message}");
        sb.AppendLine("----------------------------------Single Log-----------------------------------");
        sb.AppendLine($"Fin: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
        sb.AppendLine("-------------------------------------------------------------------------------");

        return sb.ToString();
    }

    /// <summary>
    /// Método que formatea el Log de un Objeto
    /// </summary>
    /// <param name="objectName">Nombre del Objeto.</param>
    /// <param name="obj">Objeto.</param>
    /// <returns>String con el log formateado.</returns>
    public static string FormatObjectLog(string objectName, object obj)
    {
        var sb = new StringBuilder();

        sb.AppendLine($"---------------------- Object -> {objectName}---------------------------------");
        sb.AppendLine($"Inicio: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
        sb.AppendLine("-------------------------------------------------------------------------------");
        sb.AppendLine($"{StringExtensions.ConvertObjectToString(obj)}");
        sb.AppendLine($"---------------------- Object -> {objectName}---------------------------------");
        sb.AppendLine($"Fin: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
        sb.AppendLine("-------------------------------------------------------------------------------");

        return sb.ToString();
    }

    /// <summary>
    /// Método que formatea el Log de una Excepción.
    /// </summary>
    /// <param name="exceptionMessage">Mensaje de la Excepción.</param>
    /// <returns>String con el log formateado.</returns>
    public static string FormatExceptionDetails(string exceptionMessage)
    {
        var sb = new StringBuilder();

        sb.AppendLine("-----------------------------Exception Details---------------------------------");
        sb.AppendLine($"Inicio: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
        sb.AppendLine("-------------------------------------------------------------------------------");
        sb.AppendLine($"{exceptionMessage}");
        sb.AppendLine("-----------------------------Exception Details---------------------------------");
        sb.AppendLine($"Fin: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
        sb.AppendLine("-------------------------------------------------------------------------------");

        return sb.ToString();

    }

    /// <summary>
    /// Formatea la información de una solicitud HTTP externa realizada mediante HttpClient.
    /// </summary>
    public static string FormatHttpClientRequest(
    string traceId,
    string method,
    string url,
    string statusCode,
    long elapsedMs,
    string headers,
    string? body,
    string? responseBody // <-- nuevo
)
    {
        var builder = new StringBuilder();
        builder.AppendLine("============= INICIO HTTP CLIENT =============");
        builder.AppendLine($"TraceId       : {traceId}");
        builder.AppendLine($"Método        : {method}");
        builder.AppendLine($"URL           : {url}");
        builder.AppendLine($"Código Status : {statusCode}");
        builder.AppendLine($"Duración (ms) : {elapsedMs}");
        builder.AppendLine($"Encabezados   :\n{headers}");

        if (!string.IsNullOrWhiteSpace(body))
        {
            builder.AppendLine("Cuerpo:");
            builder.AppendLine(body);
        }

        if (!string.IsNullOrWhiteSpace(responseBody))
        {
            builder.AppendLine("Respuesta:");
            builder.AppendLine(responseBody);
        }

        builder.AppendLine("============= FIN HTTP CLIENT =============");
        return builder.ToString();
    }

    /// <summary>
    /// Formatea la información de error ocurrida durante una solicitud con HttpClient.
    /// </summary>
    public static string FormatHttpClientError(
        string traceId,
        string method,
        string url,
        Exception exception)
    {
        var builder = new StringBuilder();

        builder.AppendLine();
        builder.AppendLine("======= ERROR HTTP CLIENT =======");
        builder.AppendLine($"TraceId     : {traceId}");
        builder.AppendLine($"Método      : {method}");
        builder.AppendLine($"URL         : {url}");
        builder.AppendLine($"Excepción   : {exception.Message}");
        builder.AppendLine($"StackTrace  : {exception.StackTrace}");
        builder.AppendLine("=================================");

        return builder.ToString();
    }

    /// <summary>
    /// Formatea un log detallado de una ejecución de base de datos exitosa.
    /// Incluye motor, servidor, base de datos, comando SQL y parámetros.
    /// </summary>
    /// <param name="command">Comando ejecutado (DbCommand).</param>
    /// <param name="elapsedMs">Milisegundos que tomó la ejecución.</param>
    /// <param name="context">Contexto HTTP opcional para enlazar trazabilidad.</param>
    /// <param name="customMessage">Mensaje adicional que puede incluir el log.</param>
    /// <returns>Cadena formateada para log de éxito en base de datos.</returns>
    public static string FormatDatabaseSuccess(DbCommand command, long elapsedMs, HttpContext? context = null, string? customMessage = null)
    {
        var sb = new StringBuilder();

        sb.AppendLine("📘 [Base de Datos] Consulta ejecutada exitosamente:");
        sb.AppendLine($"→ Motor: {command.Connection?.GetType().Name ?? "Desconocido"}");
        sb.AppendLine($"→ Servidor: {command.Connection?.DataSource ?? "Desconocido"}");
        sb.AppendLine($"→ Base de Datos: {command.Connection?.Database ?? "Desconocido"}");
        sb.AppendLine($"→ Tipo de Comando: {command.CommandType}");
        sb.AppendLine($"→ Texto SQL: {command.CommandText}");

        if (command.Parameters.Count > 0)
        {
            sb.AppendLine("→ Parámetros:");
            foreach (DbParameter param in command.Parameters)
            {
                sb.AppendLine($"   • {param.ParameterName} = {param.Value} ({param.DbType})");
            }
        }

        sb.AppendLine($"→ Tiempo de ejecución: {elapsedMs} ms");

        if (!string.IsNullOrWhiteSpace(customMessage))
        {
            sb.AppendLine($"→ Mensaje adicional: {customMessage}");
        }

        if (context != null)
        {
            sb.AppendLine($"→ TraceId: {context.TraceIdentifier}");
        }

        return sb.ToString();
    }

    /// <summary>
    /// Formatea un log detallado de un error durante la ejecución de una consulta a base de datos.
    /// Incluye información del motor, SQL ejecutado y excepción.
    /// </summary>
    /// <param name="command">Comando que produjo el error.</param>
    /// <param name="exception">Excepción generada.</param>
    /// <param name="context">Contexto HTTP opcional.</param>
    /// <returns>Cadena formateada para log de error en base de datos.</returns>
    public static string FormatDatabaseError(DbCommand command, Exception exception, HttpContext? context = null)
    {
        var sb = new StringBuilder();

        sb.AppendLine("❌ [Base de Datos] Error en la ejecución de una consulta:");
        sb.AppendLine($"→ Motor: {command.Connection?.GetType().Name ?? "Desconocido"}");
        sb.AppendLine($"→ Servidor: {command.Connection?.DataSource ?? "Desconocido"}");
        sb.AppendLine($"→ Base de Datos: {command.Connection?.Database ?? "Desconocido"}");
        sb.AppendLine($"→ Tipo de Comando: {command.CommandType}");
        sb.AppendLine($"→ Texto SQL: {command.CommandText}");

        if (command.Parameters.Count > 0)
        {
            sb.AppendLine("→ Parámetros:");
            foreach (DbParameter param in command.Parameters)
            {
                sb.AppendLine($"   • {param.ParameterName} = {param.Value} ({param.DbType})");
            }
        }

        sb.AppendLine($"→ Excepción: {exception.GetType().Name} - {exception.Message}");

        if (context != null)
        {
            sb.AppendLine($"→ TraceId: {context.TraceIdentifier}");
        }

        return sb.ToString();
    }

    /// <summary>
    /// Da formato al log estructurado de una ejecución SQL para fines de almacenamiento en log de texto plano.
    /// </summary>
    /// <param name="model">Modelo de log SQL estructurado.</param>
    /// <returns>Cadena con formato estándar para logging de SQL.</returns>
    public static string FormatDbExecution(SqlLogModel model)
    {
        var sb = new StringBuilder();
        sb.AppendLine("===== LOG DE EJECUCIÓN SQL =====");
        sb.AppendLine($"Fecha y Hora      : {model.StartTime:yyyy-MM-dd HH:mm:ss.fff}");
        sb.AppendLine($"Duración          : {model.Duration.TotalMilliseconds} ms");
        sb.AppendLine($"Base de Datos     : {model.DatabaseName}");
        sb.AppendLine($"IP                : {model.Ip}");
        sb.AppendLine($"Puerto            : {model.Port}");
        sb.AppendLine($"Esquema           : {model.Schema}");
        sb.AppendLine($"Tabla             : {model.TableName}");
        sb.AppendLine($"Veces Ejecutado   : {model.ExecutionCount}");
        sb.AppendLine($"Filas Afectadas   : {model.TotalAffectedRows}");
        sb.AppendLine("SQL:");
        sb.AppendLine(model.Sql);
        sb.AppendLine("================================");

        return sb.ToString();
    }

    /// <summary>
    /// Formatea un bloque de log para errores en ejecución SQL, incluyendo contexto y detalles de excepción.
    /// </summary>
    /// <param name="nombreBD">Nombre de la base de datos.</param>
    /// <param name="ip">IP del servidor de base de datos.</param>
    /// <param name="puerto">Puerto utilizado en la conexión.</param>
    /// <param name="biblioteca">Biblioteca o esquema objetivo.</param>
    /// <param name="tabla">Tabla afectada por la operación fallida.</param>
    /// <param name="sentenciaSQL">Sentencia SQL que generó el error.</param>
    /// <param name="exception">Excepción lanzada por el proveedor de datos.</param>
    /// <param name="horaError">Hora en la que ocurrió el error.</param>
    /// <returns>Texto formateado para almacenar como log de error estructurado.</returns>
    public static string FormatDbExecutionError(
        string nombreBD,
        string ip,
        int puerto,
        string biblioteca,
        string tabla,
        string sentenciaSQL,
        Exception exception,
        DateTime horaError)
    {
        var sb = new StringBuilder();

        sb.AppendLine("============= DB ERROR =============");
        sb.AppendLine($"Nombre BD: {nombreBD}");
        sb.AppendLine($"IP: {ip}");
        sb.AppendLine($"Puerto: {puerto}");
        sb.AppendLine($"Biblioteca: {biblioteca}");
        sb.AppendLine($"Tabla: {tabla}");
        sb.AppendLine($"Hora del error: {horaError:yyyy-MM-dd HH:mm:ss}");
        sb.AppendLine("Sentencia SQL:");
        sb.AppendLine(sentenciaSQL);
        sb.AppendLine();
        sb.AppendLine("Excepción:");
        sb.AppendLine(exception.Message);
        sb.AppendLine("StackTrace:");
        sb.AppendLine(exception.StackTrace ?? "Sin detalles de stack.");
        sb.AppendLine("============= END DB ERROR ===================");

        return sb.ToString();
    }

}

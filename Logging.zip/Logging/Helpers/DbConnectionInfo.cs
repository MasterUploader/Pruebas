﻿namespace Logging.Helpers;

public class DbConnectionInfo
{
    public string Ip { get; set; } = "Desconocido";
    public int Port { get; set; } = 0;
    public string Database { get; set; } = "Desconocida";
    public string Library { get; set; } = "Desconocida";
}

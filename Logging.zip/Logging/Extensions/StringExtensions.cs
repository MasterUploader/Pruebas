﻿using System.Text.Json;
using System.Xml;

namespace Logging.Extensions
{
    /// <summary>
    /// Métodos de extensión para manipulación de cadenas en el logging.
    /// </summary>
    public static class StringExtensions
    {
        /// <summary>
        /// Indenta cada línea de un texto con un número de espacios determinado.
        /// </summary>
        public static string Indent(this string text, int level = 4)
        {
            if (string.IsNullOrWhiteSpace(text)) return text;
            string indentation = new string(' ', level);
            return indentation + text.Replace("\n", "\n" + indentation);
        }

        /// <summary>
        /// Normaliza los espacios en blanco dentro de una cadena eliminando espacios extra.
        /// </summary>
        public static string NormalizeWhitespace(this string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return string.Empty;
            return System.Text.RegularExpressions.Regex.Replace(text, @"\s+", " ").Trim();
        }

        /// <summary>
        /// Convierte un objeto a formato de texto legible (JSON o XML).
        /// </summary>
        public static string ConvertObjectToString(object obj)
        { 
            if (obj == null)
                return "NULL";

            string jsonString = JsonSerializer.Serialize(obj, new JsonSerializerOptions { WriteIndented = true });

            if (IsJson(jsonString))
                return FormatJson(jsonString);
            if (IsXml(jsonString))
                return FormatXml(jsonString);

            return jsonString;
        }

    /// <summary>
    /// Determina si una cadena está en formato JSON.
    /// </summary>
    public static bool IsJson(string input)
        {
            input = input.Trim();
            return input.StartsWith('{') && input.EndsWith('}') || input.StartsWith('[') && input.EndsWith(']');
        }

        /// <summary>
        /// Determina si una cadena está en formato XML.
        /// </summary>
        public static bool IsXml(string input)
        {
            input = input.Trim();
            return input.StartsWith('<') && input.EndsWith('>');
        }

        /// <summary>
        /// Formatea un string JSON para ser más legible.
        /// </summary>
        public static string FormatJson(string json, int indentationLevel = 8)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(json)) return "Sin datos";
                using var jsonDoc = JsonDocument.Parse(json);
                string formattedJson = JsonSerializer.Serialize(jsonDoc, new JsonSerializerOptions
                {
                    WriteIndented = true,
                    Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
                });

                string indent = new string(' ', indentationLevel); // Espacios de indentación

                // 🔹 Alinear la primera línea correctamente
                string[] lines = formattedJson.Split(Environment.NewLine);
                lines[0] = indent + lines[0]; // La primera línea lleva indentación manual
                for (int i = 1; i < lines.Length; i++)
                {
                    lines[i] = indent + lines[i]; // Las siguientes líneas se indentan normalmente
                }

                return Environment.NewLine + string.Join(Environment.NewLine, lines);
            }
            catch
            {
                return json; // Si el JSON no es válido, devuelve el texto original
            }
        }

        /// <summary>
        /// Aplica formato XML legible con indentación.
        /// </summary>
        public static string FormatXml(string xml)
        {
            if (string.IsNullOrWhiteSpace(xml)) return "Sin datos";
            try
            {
                var xmlDocument = new XmlDocument();
                xmlDocument.LoadXml(xml);
                using var stringWriter = new System.IO.StringWriter();
                using var xmlTextWriter = new XmlTextWriter(stringWriter) { Formatting = Formatting.Indented };
                xmlDocument.WriteContentTo(xmlTextWriter);
                return stringWriter.ToString();
            }
            catch
            {
                return xml; // Si falla, retorna la cadena original.
            }
        }
    }
}

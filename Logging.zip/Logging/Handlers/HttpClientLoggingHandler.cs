﻿using Logging.Helpers;
using Microsoft.AspNetCore.Http;
using System.Diagnostics;

namespace RestUtilities.Logging.Handlers;

/// <summary>
/// Handler personalizado para interceptar y registrar llamadas HTTP salientes realizadas mediante HttpClient.
/// Este log se integrará automáticamente con el archivo de log del Middleware.
/// </summary>
public class HttpClientLoggingHandler : DelegatingHandler
{
    private readonly IHttpContextAccessor _httpContextAccessor;

    public HttpClientLoggingHandler(IHttpContextAccessor httpContextAccessor)
    {
        _httpContextAccessor = httpContextAccessor ?? throw new ArgumentNullException(nameof(httpContextAccessor));
    }

    /// <summary>
    /// Intercepta la solicitud y la respuesta del HttpClient, y guarda su información en HttpContext.Items.
    /// </summary>
    protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        var stopwatch = Stopwatch.StartNew();
        var context = _httpContextAccessor.HttpContext;
        string traceId = context?.TraceIdentifier ?? Guid.NewGuid().ToString();

        try
        {
            HttpResponseMessage response = await base.SendAsync(request, cancellationToken);
            stopwatch.Stop();

            string responseBody = response.Content != null
                ? await response.Content.ReadAsStringAsync(cancellationToken)
                : "Sin contenido";

            // 🔹 Formato del log: incluye cuerpo de respuesta bien formateado
            string formatted = LogFormatter.FormatHttpClientRequest(
                traceId: traceId,
                method: request.Method.Method,
                url: request.RequestUri?.ToString() ?? "URI no definida",
                statusCode: ((int)response.StatusCode).ToString(),
                elapsedMs: stopwatch.ElapsedMilliseconds,
                headers: request.Headers.ToString(),
                body: request.Content != null ? await request.Content.ReadAsStringAsync(cancellationToken) : null,
                responseBody: LogHelper.PrettyPrintAuto(responseBody, response.Content?.Headers?.ContentType?.MediaType)
            );
            if (context != null)
            {
                AppendHttpClientLogToContext(context, formatted);
            }

            return response;
        }
        catch (Exception ex)
        {
            stopwatch.Stop();

            string errorLog = LogFormatter.FormatHttpClientError(
                traceId: traceId,
                method: request.Method.Method,
                url: request.RequestUri?.ToString() ?? "URI no definida",
                exception: ex
            );

            if (context != null)
            {
                AppendHttpClientLogToContext(context, errorLog);
            }
            throw;
        }
    }

    /// <summary>
    /// Agrega el log de HttpClient a la lista en HttpContext.Items, para que luego sea procesado por el Middleware.
    /// </summary>
    private static void AppendHttpClientLogToContext(HttpContext context, string logEntry)
    {
        const string key = "HttpClientLogs";

        if (!context.Items.ContainsKey(key))
            context.Items[key] = new List<string>();

        if (context.Items[key] is List<string> logs)
            logs.Add(logEntry);
    }
}
﻿using System.Globalization;

namespace QueryBuilder.Extensions;

/// <summary>
/// Métodos de extensión para manipulación de cadenas útiles en la generación de queries SQL.
/// </summary>
public static class StringExtensions
{
    /// <summary>
    /// Convierte una cadena a PascalCase eliminando guiones bajos y capitalizando cada palabra.
    /// </summary>
    /// <param name="value">Texto de entrada.</param>
    /// <returns>Texto convertido a PascalCase.</returns>
    public static string ToPascalCase(this string value)
    {
        if (string.IsNullOrEmpty(value))
            return value;

        var words = value.Split('_');
        for (int i = 0; i < words.Length; i++)
            words[i] = CultureInfo.InvariantCulture.TextInfo.ToTitleCase(words[i].ToLower());

        return string.Concat(words);
    }

    /// <summary>
    /// Escapa comillas simples para evitar errores o inyección en valores de tipo string.
    /// </summary>
    /// <param name="value">Valor de entrada.</param>
    /// <returns>Valor escapado para SQL.</returns>
    public static string EscapeSql(this string value)
    {
        return value?.Replace("'", "''") ?? string.Empty;
    }
}
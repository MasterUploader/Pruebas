﻿using System;

namespace QueryBuilder.Utils;

/// <summary>
/// Proporciona métodos auxiliares para manejar tipos de datos en tiempo de ejecución,
/// incluyendo validaciones y conversiones seguras.
/// </summary>
public static class TypeHelper
{
    /// <summary>
    /// Intenta convertir un valor al tipo especificado. Si no es posible, lanza una excepción.
    /// </summary>
    /// <param name="value">Valor a convertir.</param>
    /// <param name="targetType">Tipo de destino al que se desea convertir.</param>
    /// <returns>Valor convertido al tipo destino.</returns>
    public static object? ConvertTo(object value, Type targetType)
    {
        if (value == null || targetType.IsInstanceOfType(value))
            return value;

        return System.Convert.ChangeType(value, Nullable.GetUnderlyingType(targetType) ?? targetType);
    }

    /// <summary>
    /// Indica si el tipo proporcionado representa un valor numérico.
    /// </summary>
    /// <param name="type">Tipo a evaluar.</param>
    /// <returns>True si el tipo es numérico; de lo contrario, false.</returns>
    public static bool IsNumeric(Type type)
    {
        return type == typeof(byte) || type == typeof(short) || type == typeof(int) ||
               type == typeof(long) || type == typeof(decimal) || type == typeof(double) ||
               type == typeof(float);
    }
}

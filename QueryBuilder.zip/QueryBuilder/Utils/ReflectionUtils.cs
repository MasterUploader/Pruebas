﻿using QueryBuilder.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace QueryBuilder.Utils;

/// <summary>
/// Proporciona funciones utilitarias para inspeccionar clases por reflexión,
/// especialmente para analizar sus atributos y estructura.
/// </summary>
public static class ReflectionUtils
{
    /// <summary>
    /// Obtiene todas las propiedades públicas de una clase que no tengan el atributo SqlIgnore.
    /// </summary>
    /// <param name="type">Tipo de clase que se desea inspeccionar.</param>
    /// <returns>Lista de propiedades mapeables.</returns>
    public static IEnumerable<PropertyInfo> GetMappableProperties(Type type)
    {
        return type.GetProperties()
                   .Where(p => !Attribute.IsDefined(p, typeof(SqlIgnoreAttribute)));
    }

    /// <summary>
    /// Devuelve el nombre de la columna a utilizar en SQL.
    /// Puede provenir del atributo SqlColumnName o del nombre de la propiedad.
    /// </summary>
    /// <param name="property">Propiedad a analizar.</param>
    /// <returns>Nombre de columna asociado.</returns>
    public static string GetColumnName(PropertyInfo property)
    {
        var attr = property.GetCustomAttribute<SqlColumnNameAttribute>();
        return attr != null ? attr.ColumnName : property.Name;
    }
}

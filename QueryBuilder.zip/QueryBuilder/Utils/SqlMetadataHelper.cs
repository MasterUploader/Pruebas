﻿using QueryBuilder.Attributes;
using System;
using System.Linq;
using System.Reflection;

namespace QueryBuilder.Utils;

/// <summary>
/// Ayudante para obtener metadatos desde atributos en clases de modelo.
/// </summary>
public static class SqlMetadataHelper
{
    /// <summary>
    /// Obtiene el nombre completo de la tabla a partir del atributo SqlTableAttribute.
    /// </summary>
    public static string GetFullTableName<T>()
    {
        var attr = typeof(T).GetCustomAttribute<SqlTableAttribute>();

        if (attr == null)
            throw new InvalidOperationException($"El modelo {typeof(T).Name} no contiene el atributo [SqlTable].");

        return !string.IsNullOrWhiteSpace(attr.Library)
            ? $"{attr.Library}.{attr.TableName}"
            : attr.TableName;
    }

    /// <summary>
    /// Obtiene las propiedades decoradas con [SqlColumnDefinition] del modelo.
    /// </summary>
    public static PropertyInfo[] GetColumnProperties<T>()
    {
        return typeof(T)
            .GetProperties()
            .Where(p => p.GetCustomAttribute<SqlColumnDefinitionAttribute>() != null)
            .ToArray();
    }
}



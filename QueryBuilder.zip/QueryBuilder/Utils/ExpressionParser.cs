﻿using System;
using System.Linq.Expressions;

namespace QueryBuilder.Utils;

/// <summary>
/// Convierte expresiones lambda simples en fragmentos de SQL.
/// Ideal para filtros dinámicos en WHERE u ON.
/// </summary>
public static class ExpressionParser
{
    /// <summary>
    /// Convierte una expresión lambda básica a un fragmento SQL (solo binarios).
    /// </summary>
    /// <typeparam name="T">Tipo sobre el que se evalúa la expresión.</typeparam>
    /// <param name="expression">Expresión lambda.</param>
    /// <returns>Fragmento SQL equivalente.</returns>
    public static string Parse<T>(Expression<Func<T, bool>> expression)
    {
        if (expression.Body is BinaryExpression binary)
        {
            var left = binary.Left.ToString().Split('.')[^1];
            var right = ExpressionValue(binary.Right);
            var op = GetSqlOperator(binary.NodeType);

            return $"{left} {op} {right}";
        }

        return string.Empty;
    }

    private static string GetSqlOperator(ExpressionType nodeType) => nodeType switch
    {
        ExpressionType.Equal => "=",
        ExpressionType.NotEqual => "<>",
        ExpressionType.GreaterThan => ">",
        ExpressionType.GreaterThanOrEqual => ">=",
        ExpressionType.LessThan => "<",
        ExpressionType.LessThanOrEqual => "<=",
        _ => throw new NotSupportedException($"Operador no soportado: {nodeType}")
    };

    private static string ExpressionValue(Expression expr)
    {
        if (expr is ConstantExpression constExpr)
            return $"'{constExpr.Value}'";

        return expr.ToString().Split('.')[^1]; // Fallback
    }
}

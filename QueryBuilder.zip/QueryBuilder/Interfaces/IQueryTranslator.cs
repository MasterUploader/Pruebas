﻿using QueryBuilder.Models;

namespace QueryBuilder.Interfaces;

/// <summary>
/// Define un contrato para traducir un objeto de construcción de consulta a una sentencia SQL final.
/// </summary>
public interface IQueryTranslator
{
    /// <summary>
    /// Traduce el contexto de consulta a SQL final compatible con el motor correspondiente.
    /// </summary>
    /// <param name="context">Contexto con la consulta construida.</param>
    /// <returns>Cadena SQL final traducida.</returns>
    string Translate(QueryTranslationContext context);
}

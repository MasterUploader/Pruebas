﻿namespace QueryBuilder.Interfaces;

/// <summary>
/// Define la interfaz que traduce sentencias SQL a su sintaxis específica
/// dependiendo del motor de base de datos (AS400, SQL Server, Oracle, etc.).
/// </summary>
public interface ISqlEngineTranslator
{
    /// <summary>
    /// Traduce la consulta SQL genérica a la sintaxis del motor objetivo.
    /// </summary>
    /// <param name="query">Consulta SQL generada.</param>
    /// <returns>Consulta adaptada al motor SQL.</returns>
    string TranslateEngineSpecific(string query);
}

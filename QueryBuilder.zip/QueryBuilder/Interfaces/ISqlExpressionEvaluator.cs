﻿using System.Linq.Expressions;

namespace QueryBuilder.Interfaces;

/// <summary>
/// Proporciona una interfaz para traducir expresiones lambda a condiciones SQL.
/// Es utilizada por la capa de expresión avanzada para facilitar el uso de expresiones tipadas.
/// </summary>
public interface ISqlExpressionEvaluator
{
    /// <summary>
    /// Traduce una expresión lambda a su equivalente en SQL.
    /// </summary>
    /// <param name="expression">Expresión lambda.</param>
    /// <returns>Condición SQL generada.</returns>
    string Translate(Expression expression);
}

﻿using QueryBuilder.Models;

namespace QueryBuilder.Interfaces;

/// <summary>
/// Define la interfaz que todo dialecto SQL debe implementar.
/// </summary>
public interface ISqlDialectService
{
    QueryMetadata BuildSelect<T>(T criteria) where T : class;
    QueryMetadata BuildInsert<T>(T entity) where T : class;
    QueryMetadata BuildUpdate<T>(T entity, object keys) where T : class;
    QueryMetadata BuildDelete<T>(object keys) where T : class;
}

﻿namespace QueryBuilder.Interfaces;

/// <summary>
/// Contrato para definir métodos que generan sentencias SQL específicas para cada motor.
/// </summary>
public interface ISqlEngine
{
    string GenerateSelectQuery<TModel>(System.Linq.Expressions.Expression<System.Func<TModel, bool>>? filter = null);
    string GenerateInsertQuery<TModel>(TModel insertValues);
    string GenerateUpdateQuery<TModel>(TModel updateValues, System.Linq.Expressions.Expression<System.Func<TModel, bool>> filter);

    /// <summary>
    /// Genera una sentencia SQL que consulta los metadatos de una tabla.
    /// </summary>
    /// <param name="tableName">Nombre de la tabla.</param>
    /// <returns>Consulta SQL para obtener metadata (campos, tipos, etc.).</returns>
    string GenerateMetadataQuery(string tableName);
}
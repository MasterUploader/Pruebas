﻿using System;
using System.Linq.Expressions;

namespace QueryBuilder.Interfaces;

/// <summary>
/// Interfaz que define métodos para construir sentencias SQL dinámicas a partir de modelos de datos.
/// </summary>
public interface IQueryBuilderService
{
    /// <summary>
    /// Genera una sentencia SQL SELECT basada en el tipo del modelo y una expresión de filtro opcional.
    /// </summary>
    /// <typeparam name="TModel">Tipo del modelo que representa la tabla.</typeparam>
    /// <param name="filter">Expresión lambda que representa los criterios de filtrado.</param>
    /// <returns>Cadena con la sentencia SQL SELECT generada.</returns>
    string BuildSelectQuery<TModel>(Expression<Func<TModel, bool>>? filter = null);

    /// <summary>
    /// Genera una sentencia SQL INSERT basada en un objeto con los valores a insertar.
    /// </summary>
    /// <typeparam name="TModel">Tipo del modelo que representa la tabla.</typeparam>
    /// <param name="insertValues">Objeto con las propiedades y valores a insertar.</param>
    /// <returns>Cadena con la sentencia SQL INSERT generada.</returns>
    string BuildInsertQuery<TModel>(TModel insertValues);

    /// <summary>
    /// Genera una sentencia SQL UPDATE basada en un objeto con los nuevos valores y una expresión de filtro.
    /// </summary>
    /// <typeparam name="TModel">Tipo del modelo que representa la tabla.</typeparam>
    /// <param name="updateValues">Objeto con las propiedades y nuevos valores.</param>
    /// <param name="filter">Expresión lambda que representa los criterios WHERE de actualización.</param>
    /// <returns>Cadena con la sentencia SQL UPDATE generada.</returns>
    string BuildUpdateQuery<TModel>(TModel updateValues, Expression<Func<TModel, bool>> filter);

    /// <summary>
    /// Genera una consulta SQL que devuelve metadatos de la tabla (nombres y tipos de columnas).
    /// </summary>
    /// <param name="tableName">Nombre de la tabla.</param>
    /// <returns>Consulta SQL para obtener metadatos.</returns>
    string BuildMetadataQuery(string tableName);
}


﻿using QueryBuilder.Enums;
using System;

namespace QueryBuilder.Validators;

/// <summary>
/// Valida los tipos de datos y sus restricciones (longitud, precisión, etc.) para una columna SQL.
/// </summary>
public static class SqlTypeValidator
{
    /// <summary>
    /// Verifica si un valor cumple con las restricciones de tipo, tamaño y precisión de una columna SQL.
    /// </summary>
    /// <param name="value">Valor a validar.</param>
    /// <param name="expectedType">Tipo de dato esperado (por ejemplo: VARCHAR, NUMERIC, etc.).</param>
    /// <param name="length">Tamaño máximo permitido.</param>
    /// <param name="precision">Número de decimales, si aplica.</param>
    /// <returns>Verdadero si el valor es compatible, falso en caso contrario.</returns>
    public static bool IsValid(object value, SqlDataType expectedType, int length = 0, int precision = 0, int scale = 0)
    {
        if (value == null) return true;

        switch (expectedType)
        {
            case SqlDataType.Char:
            case SqlDataType.Varchar:
                return value is string str && (length == 0 || str.Length <= length);

            case SqlDataType.Numeric:
            case SqlDataType.Decimal:
                if (decimal.TryParse(value.ToString(), out decimal dec))
                {
                    var parts = dec.ToString().Split('.');
                    var intPart = parts[0];
                    var decPart = parts.Length > 1 ? parts[1] : "";
                    return intPart.Length + decPart.Length <= length && decPart.Length <= precision;
                }
                return false;

            case SqlDataType.Int:
            case SqlDataType.Integer:
                return int.TryParse(value.ToString(), out _);

            case SqlDataType.SmallInt:
                return short.TryParse(value.ToString(), out _);

            case SqlDataType.BigInt:
                return long.TryParse(value.ToString(), out _);

            case SqlDataType.Date:
                return DateTime.TryParse(value.ToString(), out _);

            default:
                return true;
        }
    }
}

﻿using QueryBuilder.Attributes;
using System.Collections.Generic;
using System.Reflection;

namespace QueryBuilder.Validators;

/// <summary>
/// Valida los modelos definidos por el usuario antes de construir una sentencia SQL.
/// </summary>
public static class QueryModelValidator
{
    /// <summary>
    /// Evalúa si un modelo es válido para generar un query SQL.
    /// </summary>
    /// <param name="model">Instancia del modelo a validar.</param>
    /// <returns>Lista de errores detectados. Si está vacía, el modelo es válido.</returns>
    public static List<string> ValidateModel(object model)
    {
        var errors = new List<string>();
        if (model == null) return errors;

        var props = model.GetType().GetProperties();

        foreach (var prop in props)
        {
            var attr = prop.GetCustomAttribute<SqlColumnDefinitionAttribute>();
            if (attr != null)
            {
                var value = prop.GetValue(model);
                if (value != null && !SqlTypeValidator.IsValid(value, attr.DataType, attr.Length, attr.Precision, attr.Scale))
                {
                    errors.Add($"Campo '{prop.Name}' no cumple con las restricciones definidas: Tipo={attr.DataType}, Longitud={attr.Length}, Precisión={attr.Precision}, Escala={attr.Scale}");
                }
            }
        }

        return errors;
    }
}

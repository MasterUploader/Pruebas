﻿using QueryBuilder.Models;

namespace QueryBuilder.Services;

/// <summary>
/// Implementación del dialecto SQL para AS400 (DB2 for i).
/// Genera queries compatibles con la sintaxis específica de este motor.
/// </summary>
public class As400DialectService : SqlDialectServiceBase
{
    public override QueryMetadata BuildSelect<T>(T criteria)
    {
        // Implementación simplificada inicial.
        return new QueryMetadata
        {
            Sql = $"SELECT * FROM {typeof(T).Name}" // Ejemplo simple, reemplazable por lógica de reflexión avanzada
        };
    }

    public override QueryMetadata BuildInsert<T>(T entity)
    {
        // Generar INSERT dinámico a partir del objeto
        return new QueryMetadata
        {
            Sql = $"INSERT INTO {typeof(T).Name} (...) VALUES (...)"
        };
    }

    public override QueryMetadata BuildUpdate<T>(T entity, object keys)
    {
        return new QueryMetadata
        {
            Sql = $"UPDATE {typeof(T).Name} SET ... WHERE ..."
        };
    }

    public override QueryMetadata BuildDelete<T>(object keys)
    {
        return new QueryMetadata
        {
            Sql = $"DELETE FROM {typeof(T).Name} WHERE ..."
        };
    }
}
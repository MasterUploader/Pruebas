﻿using QueryBuilder.Interfaces;
using QueryBuilder.Models;

namespace QueryBuilder.Services;

/// <summary>
/// Clase base para los servicios de dialecto SQL por motor.
/// Define la estructura común para crear consultas dinámicamente.
/// </summary>
public abstract class SqlDialectServiceBase : ISqlDialectService
{
    public abstract QueryMetadata BuildSelect<T>(T criteria) where T : class;
    public abstract QueryMetadata BuildInsert<T>(T entity) where T : class;
    public abstract QueryMetadata BuildUpdate<T>(T entity, object keys) where T : class;
    public abstract QueryMetadata BuildDelete<T>(object keys) where T : class;
}

﻿using QueryBuilder.Attributes;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace QueryBuilder.Services;

/// <summary>
/// Generador dinámico de sentencias SQL UPDATE a partir de modelos decorados con atributos de metadatos.
/// </summary>
public static class DynamicUpdateGenerator
{
    /// <summary>
    /// Genera una sentencia SQL UPDATE dinámica con los campos que tienen el atributo <see cref="SqlColumnDefinitionAttribute"/>.
    /// </summary>
    /// <typeparam name="T">Tipo del modelo.</typeparam>
    /// <param name="schemaAndTable">Nombre completo de la tabla (por ejemplo: "BCAH96DTA.BTSACTA").</param>
    /// <param name="model">Instancia del modelo que contiene los valores a actualizar.</param>
    /// <param name="whereClause">Cláusula WHERE (sin la palabra clave "WHERE").</param>
    /// <param name="parameters">Lista de nombres de parámetros generados para los valores SET.</param>
    /// <returns>Cadena SQL del UPDATE.</returns>
    public static string GenerateUpdateSql<T>(string schemaAndTable, T model, string whereClause, out List<string> parameters)
        where T : class
    {
        var props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
        var setClauses = new List<string>();
        parameters = new List<string>();

        foreach (var prop in props)
        {
            var attr = prop.GetCustomAttribute<SqlColumnDefinitionAttribute>();
            if (attr == null)
                continue;

            var paramName = $"@{attr.ColumnName}";
            setClauses.Add($"{attr.ColumnName} = {paramName}");
            parameters.Add(paramName);
        }

        var sql = new StringBuilder();
        sql.Append($"UPDATE {schemaAndTable} SET ");
        sql.Append(string.Join(", ", setClauses));

        if (!string.IsNullOrWhiteSpace(whereClause))
        {
            sql.Append(" WHERE ");
            sql.Append(whereClause);
        }

        return sql.ToString();
    }
}

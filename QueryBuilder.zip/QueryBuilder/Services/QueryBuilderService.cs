﻿using QueryBuilder.Interfaces;
using QueryBuilder.Models;
using static QueryBuilder.Compatibility.SqlCompatibilityService;
using System.Linq.Expressions;
using System;

namespace QueryBuilder.Services;

/// <summary>
/// Servicio que implementa la lógica para construir sentencias SQL basadas en modelos de datos.
/// </summary>
public class QueryBuilderService : IQueryBuilderService
{
    private readonly ISqlEngine _sqlEngine;

    /// <summary>
    /// Inicializa una nueva instancia del servicio con el motor SQL especificado.
    /// </summary>
    /// <param name="sqlEngine">Motor SQL que define la lógica específica según el proveedor (SQL Server, Oracle, AS400, etc.).</param>
    public QueryBuilderService(ISqlEngine sqlEngine)
    {
        _sqlEngine = sqlEngine;
    }

    /// <inheritdoc />
    public string BuildSelectQuery<TModel>(Expression<Func<TModel, bool>>? filter = null)
    {
        return _sqlEngine.GenerateSelectQuery(filter);
    }

    /// <inheritdoc />
    public string BuildInsertQuery<TModel>(TModel insertValues)
    {
        return _sqlEngine.GenerateInsertQuery(insertValues);
    }

    /// <inheritdoc />
    public string BuildUpdateQuery<TModel>(TModel updateValues, Expression<Func<TModel, bool>> filter)
    {
        return _sqlEngine.GenerateUpdateQuery(updateValues, filter);
    }
    /// <inheritdoc />
    public string BuildMetadataQuery(string tableName)
    {
        return _sqlEngine.GenerateMetadataQuery(tableName);
    }


}
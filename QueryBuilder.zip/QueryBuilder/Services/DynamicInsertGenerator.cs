﻿using QueryBuilder.Attributes;
using System.Collections.Generic;
using System.Reflection;

namespace QueryBuilder.Services;

/// <summary>
/// Generador dinámico de sentencias SQL INSERT a partir de atributos definidos en el modelo.
/// </summary>
public static class DynamicInsertGenerator
{
    /// <summary>
    /// Genera un INSERT INTO ... VALUES (...) para el modelo especificado.
    /// </summary>
    /// <typeparam name="T">Tipo del modelo.</typeparam>
    /// <param name="schemaAndTable">Nombre completo de tabla (por ejemplo: "BCAH96DTA.BTSACTA").</param>
    /// <param name="model">Instancia del modelo a insertar.</param>
    /// <param name="parameters">Lista de nombres de parámetros generados, en el mismo orden que las columnas.</param>
    /// <returns>SQL generado.</returns>
    public static string GenerateInsertSql<T>(string schemaAndTable, T model, out List<string> parameters) where T : class
    {
        var props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
        var columns = new List<string>();
        parameters = new List<string>();

        foreach (var prop in props)
        {
            var attr = prop.GetCustomAttribute<SqlColumnDefinitionAttribute>();
            if (attr == null)
                continue;

            columns.Add(attr.ColumnName);
            parameters.Add($"@{attr.ColumnName}"); // nombre de parámetro OleDb
        }

        string columnList = string.Join(", ", columns);
        string paramList = string.Join(", ", parameters);

        return $"INSERT INTO {schemaAndTable} ({columnList}) VALUES ({paramList})";
    }
}


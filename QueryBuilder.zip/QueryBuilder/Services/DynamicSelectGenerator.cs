﻿using QueryBuilder.Attributes;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace QueryBuilder.Services;

/// <summary>
/// Generador dinámico de sentencias SQL SELECT a partir de modelos decorados con atributos de metadatos.
/// </summary>
public static class DynamicSelectGenerator
{
    /// <summary>
    /// Genera una sentencia SQL SELECT basada en los atributos <see cref="SqlColumnDefinitionAttribute"/>.
    /// </summary>
    /// <typeparam name="T">Tipo del modelo decorado con atributos.</typeparam>
    /// <param name="schemaAndTable">Nombre completo de la tabla (por ejemplo: "BCAH96DTA.BTSACTA").</param>
    /// <param name="whereConditions">Diccionario con condiciones WHERE: clave = nombre de columna, valor = nombre del parámetro.</param>
    /// <returns>Sentencia SQL SELECT generada dinámicamente.</returns>
    public static string GenerateSelectSql<T>(string schemaAndTable, Dictionary<string, string>? whereConditions = null)
        where T : class
    {
        var props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
        var columns = new List<string>();

        foreach (var prop in props)
        {
            var attr = prop.GetCustomAttribute<SqlColumnDefinitionAttribute>();
            if (attr != null)
                columns.Add(attr.ColumnName);
        }

        var sql = new StringBuilder();
        sql.Append($"SELECT {string.Join(", ", columns)} FROM {schemaAndTable}");

        if (whereConditions != null && whereConditions.Count > 0)
        {
            sql.Append(" WHERE ");
            sql.Append(string.Join(" AND ", whereConditions.Select(kvp => $"{kvp.Key} = @{kvp.Value}")));
        }

        return sql.ToString();
    }
}



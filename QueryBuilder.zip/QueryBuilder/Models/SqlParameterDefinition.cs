﻿namespace QueryBuilder.Models;

/// <summary>
/// Representa la definición de un parámetro SQL.
/// Incluye el nombre del parámetro, su tipo de datos y su valor.
/// </summary>
public class SqlParameterDefinition
{
    /// <summary>
    /// Nombre del parámetro, incluyendo el prefijo @ si es necesario.
    /// </summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>
    /// Valor que se asignará al parámetro.
    /// </summary>
    public object Value { get; set; } = new();

    /// <summary>
    /// Tipo de datos esperado por el motor SQL (por ejemplo, VARCHAR, INT).
    /// </summary>
    public string DataType { get; set; } = string.Empty;

    /// <summary>
    /// Tamaño o precisión del dato, si aplica (por ejemplo, 20 o 10,2).
    /// </summary>
    public string Size { get; set; } = string.Empty;
}

﻿using QueryBuilder.Enums;

namespace QueryBuilder.Models;

/// <summary>
/// Representa metadatos de un parámetro SQL (nombre, tipo, longitud, valor actual).
/// </summary>
public class SqlParameterMetadata
{
    public string Name { get; set; } = string.Empty;
    public SqlDataType DataType { get; set; }
    public int? Length { get; set; }
    public object? Value { get; set; }
}
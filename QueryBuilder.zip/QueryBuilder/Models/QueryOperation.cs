﻿namespace QueryBuilder.Models;

/// <summary>
/// Enum que define el tipo de operación SQL a ejecutar.
/// </summary>
public enum QueryOperation
{
    Select,
    Insert,
    Update
}

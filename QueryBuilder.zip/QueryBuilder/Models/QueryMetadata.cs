﻿using System.Collections.Generic;

namespace QueryBuilder.Models;

/// <summary>
/// Representa los metadatos generales asociados a una consulta SQL generada.
/// Permite almacenar el SQL, los parámetros y otra información útil.
/// </summary>
public class QueryMetadata
{
    /// <summary>
    /// Consulta SQL final generada.
    /// </summary>
    public string Sql { get; set; } = string.Empty;

    /// <summary>
    /// Lista de parámetros que deben asignarse antes de ejecutar la consulta.
    /// </summary>
    public List<SqlParameterDefinition> Parameters { get; set; } = [];

    /// <summary>
    /// Información adicional para depuración o ejecución (por ejemplo, tiempo estimado).
    /// </summary>
    public Dictionary<string, string> Metadata { get; set; } = [];
}

﻿using System.Collections.Generic;

namespace QueryBuilder.Models;

/// <summary>
/// Extiende el contexto de traducción para admitir operaciones INSERT, UPDATE y METADATA.
/// </summary>
public class ExtendedQueryTranslationContext : QueryTranslationContext
{
    /// <summary>
    /// Columnas a insertar (INSERT INTO ...).
    /// </summary>
    public List<string> InsertColumns { get; set; } = [];

    /// <summary>
    /// Valores de los parámetros para el INSERT.
    /// </summary>
    public List<string> InsertValues { get; set; } = [];

    /// <summary>
    /// Columnas que serán actualizadas (UPDATE ... SET ...).
    /// </summary>
    public List<string> UpdateColumns { get; set; } = [];

    /// <summary>
    /// Valores de los parámetros para el UPDATE.
    /// </summary>
    public List<string> UpdateValues { get; set; } = [];

    /// <summary>
    /// Indica si se desea obtener únicamente metadata de la tabla.
    /// </summary>
    public bool MetadataOnly { get; set; }
}

﻿namespace QueryBuilder.Models;

/// <summary>
/// Representa una columna de una tabla SQL.
/// Incluye nombre, tipo, tamaño y si es clave primaria o permite nulos.
/// </summary>
public class ColumnDefinition
{
    /// <summary>
    /// Nombre de la columna.
    /// </summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>
    /// Tipo de dato SQL (por ejemplo: VARCHAR, INT, DECIMAL).
    /// </summary>
    public string DataType { get; set; } = string.Empty;

    /// <summary>
    /// Tamaño o precisión del campo, si aplica.
    /// </summary>
    public string Size { get; set; } = string.Empty;

    /// <summary>
    /// Indica si la columna permite valores nulos.
    /// </summary>
    public bool IsNullable { get; set; }

    /// <summary>
    /// Indica si la columna es clave primaria.
    /// </summary>
    public bool IsPrimaryKey { get; set; }
}

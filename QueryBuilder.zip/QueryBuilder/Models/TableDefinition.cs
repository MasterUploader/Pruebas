﻿using System.Collections.Generic;

namespace QueryBuilder.Models;

/// <summary>
/// Representa una tabla SQL y su definición estructural.
/// Incluye el nombre, alias, columnas y posibles restricciones.
/// </summary>
public class TableDefinition
{
    /// <summary>
    /// Nombre de la tabla tal como aparece en la base de datos.
    /// </summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>
    /// Alias opcional para usar en la consulta SQL.
    /// </summary>
    public string Alias { get; set; } = string.Empty;

    /// <summary>
    /// Lista de columnas que componen la tabla.
    /// </summary>
    public List<ColumnDefinition> Columns { get; set; } = [];
}

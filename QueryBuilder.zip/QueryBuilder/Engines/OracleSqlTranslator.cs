﻿using QueryBuilder.Interfaces;

namespace QueryBuilder.Engines;

/// <summary>
/// Traductor de sentencias SQL específico para Oracle Database.
/// Incluye adaptaciones como NVL, ROWNUM y funciones propias de Oracle.
/// </summary>
public class OracleSqlTranslator : ISqlEngineTranslator
{
    /// <inheritdoc />
    public string TranslateEngineSpecific(string query)
    {
        return query
            .Replace("COALESCE", "NVL")
            .Replace("LIMIT", "") // Oracle usa ROWNUM o FETCH
            .Replace("FETCH NEXT", "FETCH FIRST");
    }
}

﻿using QueryBuilder.Interfaces;
using QueryBuilder.Models;
using QueryBuilder.Translators;
using QueryBuilder.Utils;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace QueryBuilder.Engines;

/// <summary>
/// Motor SQL especializado para generar consultas compatibles con AS400.
/// </summary>
public class As400SqlEngine : ISqlEngine
{
    private readonly IQueryTranslator _translator;

    /// <summary>
    /// Inicializa una nueva instancia del motor con el traductor AS400 especificado.
    /// </summary>
    /// <param name="translator">Traductor que convierte el contexto en una sentencia SQL específica.</param>
    public As400SqlEngine(IQueryTranslator translator)
    {
        _translator = translator;
    }

    /// <inheritdoc />
    public string GenerateSelectQuery<TModel>(Expression<Func<TModel, bool>>? filter = null)
    {
        var tableName = SqlMetadataHelper.GetFullTableName<TModel>();
        var columnNames = SqlMetadataHelper.GetSqlColumns<TModel>();

        var context = new QueryTranslationContext
        {
            TableName = tableName,
            SelectColumns = columnNames,
            Operation = QueryOperation.Select,
            WhereClause = filter != null ? SqlExpressionParser.Parse(filter) : null
        };

        return _translator.Translate(context);
    }

    /// <inheritdoc />
    public string GenerateInsertQuery<TModel>(TModel insertValues)
    {
        var tableName = SqlMetadataHelper.GetFullTableName<TModel>();
        var columnValues = SqlMetadataHelper.GetColumnValuePairs(insertValues);

        var context = new QueryTranslationContext
        {
            TableName = tableName,
            InsertValues = columnValues,
            Operation = QueryOperation.Insert
        };

        return _translator.Translate(context);
    }

    /// <inheritdoc />
    public string GenerateUpdateQuery<TModel>(TModel updateValues, Expression<Func<TModel, bool>> filter)
    {
        var tableName = SqlMetadataHelper.GetFullTableName<TModel>();
        var columnValues = SqlMetadataHelper.GetColumnValuePairs(updateValues);
        var whereClause = SqlExpressionParser.Parse(filter);

        var context = new QueryTranslationContext
        {
            TableName = tableName,
            UpdateValues = columnValues,
            WhereClause = whereClause,
            Operation = QueryOperation.Update
        };

        return _translator.Translate(context);
    }
}
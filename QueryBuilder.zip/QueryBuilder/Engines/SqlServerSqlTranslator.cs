﻿using QueryBuilder.Interfaces;

namespace QueryBuilder.Engines;

/// <summary>
/// Traductor de sentencias SQL específico para Microsoft SQL Server.
/// Adapta funciones como ISNULL, TOP, y FETCH según compatibilidad.
/// </summary>
public class SqlServerSqlTranslator : ISqlEngineTranslator
{
    /// <inheritdoc />
    public string TranslateEngineSpecific(string query)
    {
        return query
            .Replace("COALESCE", "ISNULL") // SQL Server prefiere ISNULL
            .Replace("LIMIT", "")          // No se usa LIMIT
            .Replace("FETCH FIRST", "FETCH NEXT"); // si se usa OFFSET/FETCH
    }
}
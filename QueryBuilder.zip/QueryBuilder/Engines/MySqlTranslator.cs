﻿using QueryBuilder.Interfaces;

namespace QueryBuilder.Engines;

/// <summary>
/// Traductor de sentencias SQL específico para MySQL.
/// Incluye soporte para funciones como IFNULL, LIMIT y operadores estándar.
/// </summary>
public class MySqlTranslator : ISqlEngineTranslator
{
    /// <inheritdoc />
    public string TranslateEngineSpecific(string query)
    {
        return query
            .Replace("COALESCE", "IFNULL");
    }
}

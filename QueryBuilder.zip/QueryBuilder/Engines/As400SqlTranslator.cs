﻿using QueryBuilder.Interfaces;

namespace QueryBuilder.Engines;

/// <summary>
/// Traductor de sentencias SQL específico para IBM AS400 (DB2 for i).
/// Adapta ciertas funciones y cláusulas que varían respecto a SQL estándar.
/// </summary>
public class As400SqlTranslator : ISqlEngineTranslator
{
    /// <inheritdoc />
    public string TranslateEngineSpecific(string query)
    {
        // Adaptaciones específicas para AS400:
        // - FETCH FIRST N ROWS ONLY no siempre está soportado, se puede usar RRN o subquery
        // - NVL() en lugar de COALESCE()
        // - CONCAT con ||
        // Aquí se podrían aplicar transformaciones condicionales
        return query
            .Replace("COALESCE", "NVL")
            .Replace("||", " CONCAT ")
            .Replace("FETCH NEXT", "FETCH FIRST"); // si aplica según versión
    }
}

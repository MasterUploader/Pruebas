﻿using QueryBuilder.Interfaces;

namespace QueryBuilder.Engines;

/// <summary>
/// Traductor de sentencias SQL específico para PostgreSQL.
/// Soporta LIMIT, OFFSET, COALESCE y funciones estándar.
/// </summary>
public class PostgreSqlTranslator : ISqlEngineTranslator
{
    /// <inheritdoc />
    public string TranslateEngineSpecific(string query)
    {
        return query; // PostgreSQL usa muchas convenciones estándar
    }
}

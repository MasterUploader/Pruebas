﻿using QueryBuilder.Enums;
using System.Text;

namespace QueryBuilder.Builders;

/// <summary>
/// Constructor para sentencias JOIN SQL.
/// Permite agregar JOINs con sus respectivos tipos y condiciones ON.
/// </summary>
public class JoinBuilder
{
    /// <summary>Tabla secundaria que se desea unir.</summary>
    public string JoinTable { get; set; } = string.Empty;

    /// <summary>Condición que relaciona ambas tablas.</summary>
    public string JoinCondition { get; set; } = string.Empty;

    /// <summary>Tipo de JOIN (INNER, LEFT, etc.).</summary>
    public SqlJoinType JoinType { get; set; } = SqlJoinType.Inner;

    /// <summary>
    /// Construye el fragmento de JOIN SQL.
    /// </summary>
    /// <returns>Fragmento SQL del JOIN.</returns>
    public string Build()
    {
        var joinTypeStr = JoinType switch
        {
            SqlJoinType.Left => "LEFT JOIN",
            SqlJoinType.Right => "RIGHT JOIN",
            SqlJoinType.Full => "FULL JOIN",
            SqlJoinType.Self => "JOIN", // El SELF JOIN se especifica con alias
            _ => "INNER JOIN"
        };

        return new StringBuilder()
            .Append($"{joinTypeStr} {JoinTable} ON {JoinCondition}")
            .ToString();
    }
}

﻿using System.Collections.Generic;
using System.Text;

namespace QueryBuilder.Builders;

/// <summary>
/// Constructor de consultas SQL del tipo INSERT.
/// Permite construir dinámicamente sentencias INSERT INTO con columnas y valores parametrizados.
/// </summary>
public class InsertQueryBuilder
{
    /// <summary>Nombre de la tabla destino.</summary>
    public string Table { get; set; } = string.Empty;

    /// <summary>Lista de columnas a insertar.</summary>
    public List<string> Columns { get; set; } = [];

    /// <summary>Lista de valores asociados a las columnas.</summary>
    public List<string> Values { get; set; } = [];

    /// <summary>
    /// Construye la consulta SQL INSERT basada en los valores proporcionados.
    /// </summary>
    /// <returns>Consulta SQL generada.</returns>
    public string Build()
    {
        var sb = new StringBuilder();
        sb.Append($"INSERT INTO {Table} ({string.Join(", ", Columns)}) ");
        sb.Append($"VALUES ({string.Join(", ", Values)})");
        return sb.ToString();
    }
}

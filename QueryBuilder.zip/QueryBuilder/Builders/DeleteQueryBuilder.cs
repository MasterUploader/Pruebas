﻿using System.Collections.Generic;
using System.Text;

namespace QueryBuilder.Builders;

/// <summary>
/// Constructor de consultas SQL del tipo DELETE.
/// Permite construir sentencias DELETE con condiciones WHERE.
/// </summary>
public class DeleteQueryBuilder
{
    /// <summary>Nombre de la tabla desde la que se eliminarán los registros.</summary>
    public string Table { get; set; } = string.Empty;

    /// <summary>Condiciones WHERE que limitan la eliminación.</summary>
    public List<string> WhereConditions { get; set; } = [];

    /// <summary>
    /// Construye la sentencia SQL DELETE.
    /// </summary>
    /// <returns>Consulta SQL generada.</returns>
    public string Build()
    {
        var sb = new StringBuilder();
        sb.Append($"DELETE FROM {Table}");

        if (WhereConditions.Count > 0)
            sb.Append(" WHERE ").Append(string.Join(" AND ", WhereConditions));

        return sb.ToString();
    }
}
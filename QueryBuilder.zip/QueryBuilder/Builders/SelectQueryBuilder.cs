﻿using QueryBuilder.Enums;
using QueryBuilder.Interfaces;
using System.Collections.Generic;
using System.Text;

namespace QueryBuilder.Builders;

/// <summary>
/// Constructor de consultas SQL del tipo SELECT.
/// Permite construir dinámicamente sentencias SELECT con soporte para filtros, ordenamientos, paginación, joins, etc.
/// </summary>
public class SelectQueryBuilder : IQueryBuilder
{
    private string _table = string.Empty;
    private readonly List<string> _columns = [];
    private readonly List<string> _whereConditions = [];
    private readonly List<string> _orderBy = [];
    private int? _offset;
    private int? _fetch;

    /// <inheritdoc/>
    public IQueryBuilder From(string tableName)
    {
        _table = tableName;
        return this;
    }

    /// <inheritdoc/>
    public IQueryBuilder Select(params string[] columns)
    {
        _columns.AddRange(columns);
        return this;
    }

    /// <inheritdoc/>
    public IQueryBuilder Where(string condition)
    {
        _whereConditions.Add(condition);
        return this;
    }

    /// <inheritdoc/>
    public IQueryBuilder OrderBy(string column, SqlSortDirection direction)
    {
        _orderBy.Add($"{column} {(direction == SqlSortDirection.Ascending ? "ASC" : "DESC")}");
        return this;
    }

    /// <inheritdoc/>
    public IQueryBuilder Offset(int offset)
    {
        _offset = offset;
        return this;
    }

    /// <inheritdoc/>
    public IQueryBuilder FetchNext(int size)
    {
        _fetch = size;
        return this;
    }

    /// <inheritdoc/>
    public string Build()
    {
        var sb = new StringBuilder();
        sb.Append("SELECT ");
        sb.Append(_columns.Count > 0 ? string.Join(", ", _columns) : "*");
        sb.Append(" FROM ").Append(_table);

        if (_whereConditions.Count > 0)
            sb.Append(" WHERE ").Append(string.Join(" AND ", _whereConditions));

        if (_orderBy.Count > 0)
            sb.Append(" ORDER BY ").Append(string.Join(", ", _orderBy));

        if (_offset.HasValue && _fetch.HasValue)
            sb.Append($" OFFSET {_offset.Value} ROWS FETCH NEXT {_fetch.Value} ROWS ONLY");

        return sb.ToString();
    }
}

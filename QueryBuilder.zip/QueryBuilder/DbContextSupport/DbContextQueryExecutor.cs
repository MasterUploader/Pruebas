﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace QueryBuilder.DbContextSupport;

/// <summary>
/// Servicio encargado de ejecutar consultas SQL generadas usando una instancia de DbContext.
/// </summary>
public class DbContextQueryExecutor
{
    private readonly DbContext _context;

    /// <summary>
    /// Inicializa una nueva instancia del ejecutor con el contexto especificado.
    /// </summary>
    /// <param name="context">Instancia activa de DbContext.</param>
    public DbContextQueryExecutor(DbContext context)
    {
        _context = context;
    }

    /// <summary>
    /// Ejecuta una consulta SELECT usando FromSqlRaw y devuelve una lista de resultados tipados.
    /// </summary>
    /// <typeparam name="T">Tipo de entidad o DTO esperado como resultado.</typeparam>
    /// <param name="sql">Cadena SQL generada dinámicamente.</param>
    /// <param name="parameters">Parámetros opcionales para la consulta.</param>
    /// <returns>Lista de resultados de tipo T.</returns>
    public async Task<List<T>> ExecuteQueryAsync<T>(string sql, params object[]? parameters) where T : class
    {
        return await _context.Set<T>()
                             .FromSqlRaw(sql, parameters ?? Array.Empty<object>())
                             .ToListAsync();
    }

    /// <summary>
    /// Ejecuta una instrucción SQL de modificación (INSERT, UPDATE o DELETE).
    /// </summary>
    /// <param name="sql">Cadena SQL generada dinámicamente.</param>
    /// <param name="parameters">Parámetros opcionales.</param>
    /// <returns>Número de filas afectadas.</returns>
    public async Task<int> ExecuteCommandAsync(string sql, params object[]? parameters)
    {
        return await _context.Database.ExecuteSqlRawAsync(sql, parameters ?? Array.Empty<object>());
    }
}

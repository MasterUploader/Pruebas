﻿using System;

namespace QueryBuilder.Attributes;

/// <summary>
/// Atributo utilizado para marcar una propiedad como clave primaria en una tabla SQL.
/// Esto permite identificar la columna como parte de la llave al generar WHERE en UPDATE o DELETE.
/// </summary>
[AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
public class SqlKeyAttribute : Attribute
{
    /// <summary>
    /// Inicializa una nueva instancia del atributo SqlKeyAttribute.
    /// </summary>
    public SqlKeyAttribute()
    {
    }
}

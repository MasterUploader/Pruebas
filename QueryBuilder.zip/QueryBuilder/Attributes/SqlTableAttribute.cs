﻿using System;

namespace QueryBuilder.Attributes;

/// <summary>
/// Atributo utilizado para indicar explícitamente el nombre de la tabla
/// asociada a una clase cuando no coincide con el nombre de la clase en C#.
/// </summary>
[AttributeUsage(AttributeTargets.Class, AllowMultiple = false)]
public class SqlTableAttribute : Attribute
{
    /// <summary>
    /// Nombre de la tabla en la base de datos.
    /// </summary>
    public string TableName { get; }

    /// <summary>
    /// Nombre de la libreria en la que se encuentra la base de datos.
    /// </summary>
    public string Library { get; }

    /// <summary>
    /// Inicializa una nueva instancia del atributo SqlTableAttribute.
    /// </summary>
    /// <param name="tableName">Nombre de la tabla.</param>
    public SqlTableAttribute(string library,  string tableName)
    {
        Library = library;
        TableName = tableName;
    }
}

﻿using System;

namespace QueryBuilder.Attributes;

/// <summary>
/// Atributo utilizado para excluir una propiedad de una clase
/// durante la generación automática de sentencias SQL.
/// 
/// Este atributo indica que la propiedad no debe incluirse en cláusulas
/// como SELECT, INSERT o UPDATE al construir dinámicamente una consulta.
/// </summary>
[AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
public class SqlIgnoreAttribute : Attribute
{
    /// <summary>
    /// Inicializa una nueva instancia del atributo SqlIgnoreAttribute.
    /// </summary>
    public SqlIgnoreAttribute()
    {
    }
}

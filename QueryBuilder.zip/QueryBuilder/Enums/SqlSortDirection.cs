﻿namespace QueryBuilder.Enums;

/// <summary>
/// Define la dirección de ordenamiento utilizada en las cláusulas ORDER BY.
/// </summary>
public enum SqlSortDirection
{
    /// <summary>Orden ascendente (ASC)</summary>
    Ascending,

    /// <summary>Orden descendente (DESC)</summary>
    Descending
}
﻿namespace QueryBuilder.Enums;

/// <summary>
/// Define los tipos de JOIN utilizados en SQL.
/// </summary>
public enum SqlJoinType
{
    /// <summary>JOIN INTERNO (INNER JOIN)</summary>
    Inner,

    /// <summary>JOIN IZQUIERDO (LEFT JOIN)</summary>
    Left,

    /// <summary>JOIN DERECHO (RIGHT JOIN)</summary>
    Right,

    /// <summary>JOIN COMPLETO (FULL OUTER JOIN)</summary>
    Full,

    /// <summary>SELF JOIN</summary>
    Self
}

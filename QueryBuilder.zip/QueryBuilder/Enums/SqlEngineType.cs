﻿namespace QueryBuilder.Enums;

/// <summary>
/// Define los motores de base de datos soportados por el generador de consultas.
/// </summary>
public enum SqlEngineType
{
    /// <summary>AS400 (IBM iSeries)</summary>
    AS400,

    /// <summary>Microsoft SQL Server</summary>
    SqlServer,

    /// <summary>Oracle</summary>
    Oracle,

    /// <summary>PostgreSQL</summary>
    PostgreSql,

    /// <summary>MySQL</summary>
    MySql
}

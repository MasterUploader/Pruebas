﻿namespace QueryBuilder.Enums;

/// <summary>
/// Enum para representar tipos de datos SQL soportados por el atributo.
/// </summary>
public enum SqlDataType
{
    Char,
    Varchar,
    Int,
    Integer,
    Decimal,
    Numeric,
    SmallInt,
    BigInt,
    Double,
    Date,
    Time,
    Timestamp,
    Boolean
}

﻿namespace QueryBuilder.Enums;

/// <summary>
/// Representa los operadores de comparación que pueden usarse en condiciones SQL.
/// </summary>
public enum SqlOperator
{
    /// <summary>Igual (=)</summary>
    Equal,

    /// <summary>Diferente (<> o !=)</summary>
    NotEqual,

    /// <summary>Mayor que (>)</summary>
    GreaterThan,

    /// <summary>Menor que (<)</summary>
    LessThan,

    /// <summary>Mayor o igual que (>=)</summary>
    GreaterThanOrEqual,

    /// <summary>Menor o igual que (<=)</summary>
    LessThanOrEqual,

    /// <summary>Contiene (LIKE %valor%)</summary>
    Contains,

    /// <summary>Empieza con (LIKE valor%)</summary>
    StartsWith,

    /// <summary>Termina con (LIKE %valor)</summary>
    EndsWith,

    /// <summary>IN (lista de valores)</summary>
    In,

    /// <summary>NOT IN (lista de valores)</summary>
    NotIn,

    /// <summary>IS NULL</summary>
    IsNull,

    /// <summary>IS NOT NULL</summary>
    IsNotNull,

    /// <summary>BETWEEN (rango)</summary>
    Between
}
﻿using QueryBuilder.Attributes;
using QueryBuilder.Enums;
using System;
using System.Collections.Generic;
using System.Reflection;

namespace QueryBuilder.Helpers;

/// <summary>
/// Utilidades para obtener metadatos de columnas SQL definidas mediante atributos personalizados.
/// </summary>
public static class SqlModelMetadataHelper
{
    /// <summary>
    /// Obtiene los metadatos de todas las propiedades decoradas con <see cref="SqlColumnDefinitionAttribute"/> de un modelo.
    /// </summary>
    /// <param name="model">Instancia del modelo.</param>
    /// <returns>Diccionario con nombre de propiedad y su definición SQL.</returns>
    public static Dictionary<string, SqlColumnDefinitionAttribute> GetColumnDefinitions(object model)
    {
        var result = new Dictionary<string, SqlColumnDefinitionAttribute>();

        var properties = model.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance);
        foreach (var prop in properties)
        {
            var attr = prop.GetCustomAttribute<SqlColumnDefinitionAttribute>();
            if (attr != null)
                result.Add(prop.Name, attr);
        }

        return result;
    }

    /// <summary>
    /// Aplica padding automático a propiedades tipo CHAR/VARCHAR según la longitud definida en el atributo.
    /// </summary>
    /// <typeparam name="T">Tipo del modelo.</typeparam>
    /// <param name="model">Instancia del modelo.</param>
    /// <param name="padChar">Carácter de padding (por defecto espacio).</param>
    /// <param name="padRight">Indica si el padding debe ser al final (true) o al inicio (false).</param>
    public static void ApplyStringPadding<T>(T model, char padChar = ' ', bool padRight = true) where T : class
    {
        var props = model.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance);

        foreach (var prop in props)
        {
            var attr = prop.GetCustomAttribute<SqlColumnDefinitionAttribute>();
            if (attr == null) continue;

            if ((attr.DataType == SqlDataType.Char || attr.DataType == SqlDataType.Varchar) &&
                prop.PropertyType == typeof(string))
            {
                var currentValue = (string?)prop.GetValue(model);
                if (currentValue == null) continue;

                string padded = padRight
                    ? currentValue.PadRight(attr.Length, padChar)
                    : currentValue.PadLeft(attr.Length, padChar);

                prop.SetValue(model, padded);
            }
        }
    }

    /// <summary>
    /// Obtiene el nombre de la tabla y de la libreria
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <returns></returns>
    /// <exception cref="InvalidOperationException"></exception>
    public static string GetFullTableName<T>()
    {
        var attr = typeof(T).GetCustomAttribute<SqlTableAttribute>();
        if (attr == null)
            throw new InvalidOperationException($"El modelo '{typeof(T).Name}' no tiene el atributo SqlTableDefinition.");

        return $"{attr.Library}.{attr.TableName}";
    }
}

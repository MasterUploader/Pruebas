﻿using QueryBuilder.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace QueryBuilder.Metadata;

/// <summary>
/// Utilidad para extraer metadatos de modelos decorados con atributos personalizados.
/// </summary>
public static class SqlMetadataHelper
{
    /// <summary>
    /// Obtiene el nombre completo de la tabla (esquema.tabla) a partir del modelo.
    /// </summary>
    /// <typeparam name="T">Tipo del modelo.</typeparam>
    /// <returns>Nombre completo de la tabla.</returns>
    public static string GetFullTableName<T>()
    {
        var type = typeof(T);
        var tableAttr = type.GetCustomAttribute<SqlTableAttribute>();
        if (tableAttr == null)
            throw new InvalidOperationException($"El modelo '{type.Name}' no tiene el atributo SqlTableAttribute.");

        return $"{tableAttr.Schema}.{tableAttr.TableName}";
    }

    /// <summary>
    /// Obtiene la lista de nombres de columnas SQL del modelo decoradas con SqlColumnDefinitionAttribute.
    /// </summary>
    /// <typeparam name="T">Tipo del modelo.</typeparam>
    /// <returns>Lista de nombres de columnas.</returns>
    public static List<string> GetSqlColumns<T>()
    {
        return typeof(T)
            .GetProperties()
            .Where(p => p.GetCustomAttribute<SqlColumnDefinitionAttribute>() != null)
            .Select(p => p.GetCustomAttribute<SqlColumnDefinitionAttribute>()!.ColumnName)
            .ToList();
    }

    /// <summary>
    /// Obtiene los pares columna-valor desde una instancia de modelo con atributos SqlColumnDefinitionAttribute.
    /// </summary>
    /// <param name="model">Instancia del modelo.</param>
    /// <returns>Diccionario de columnas con sus respectivos valores.</returns>
    public static Dictionary<string, object?> GetColumnValuePairs(object model)
    {
        var type = model.GetType();
        var props = type.GetProperties()
            .Where(p => p.GetCustomAttribute<SqlColumnDefinitionAttribute>() != null);

        var result = new Dictionary<string, object?>();

        foreach (var prop in props)
        {
            var columnAttr = prop.GetCustomAttribute<SqlColumnDefinitionAttribute>()!;
            var value = prop.GetValue(model);
            result[columnAttr.ColumnName] = value;
        }

        return result;
    }
}

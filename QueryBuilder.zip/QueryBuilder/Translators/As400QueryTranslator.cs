﻿using QueryBuilder.Interfaces;
using QueryBuilder.Models;
using System;
using System.Text;

namespace QueryBuilder.Translators;

/// <summary>
/// Traductor de consultas específico para AS400 (DB2).
/// Soporta SELECT, INSERT y UPDATE utilizando el contexto de traducción.
/// </summary>
public class As400QueryTranslator : IQueryTranslator
{
    /// <inheritdoc />
    public string Translate(QueryTranslationContext context)
    {
        return context.Operation switch
        {
            QueryOperation.Select => BuildSelect(context),
            QueryOperation.Insert => BuildInsert(context),
            QueryOperation.Update => BuildUpdate(context),
            _ => throw new NotSupportedException($"Operación SQL no soportada: {context.Operation}")
        };
    }

    private string BuildSelect(QueryTranslationContext context)
    {
        var sb = new StringBuilder();
        sb.Append("SELECT ");
        sb.Append(string.Join(", ", context.SelectColumns));
        sb.Append(" FROM ");
        sb.Append(context.TableName);

        if (!string.IsNullOrWhiteSpace(context.WhereClause))
        {
            sb.Append(" WHERE ");
            sb.Append(context.WhereClause);
        }

        if (!string.IsNullOrWhiteSpace(context.OrderByClause))
        {
            sb.Append(" ORDER BY ");
            sb.Append(context.OrderByClause);
        }

        if (context.Offset.HasValue && context.Limit.HasValue)
        {
            sb.Append($" OFFSET {context.Offset.Value} ROWS FETCH NEXT {context.Limit.Value} ROWS ONLY");
        }

        return sb.ToString();
    }

    private string BuildInsert(QueryTranslationContext context)
    {
        var columns = context.InsertValues!.Keys.ToList();
        var columnList = string.Join(", ", columns);
        var paramList = string.Join(", ", columns.Select(_ => "?"));

        return $"INSERT INTO {context.TableName} ({columnList}) VALUES ({paramList})";
    }

    private string BuildUpdate(QueryTranslationContext context)
    {
        var columns = context.UpdateValues!.Keys.ToList();
        var setList = string.Join(", ", columns.Select(c => $"{c} = ?"));

        var sb = new StringBuilder();
        sb.Append($"UPDATE {context.TableName} SET ");
        sb.Append(setList);

        if (!string.IsNullOrWhiteSpace(context.WhereClause))
        {
            sb.Append(" WHERE ");
            sb.Append(context.WhereClause);
        }

        return sb.ToString();
    }
}

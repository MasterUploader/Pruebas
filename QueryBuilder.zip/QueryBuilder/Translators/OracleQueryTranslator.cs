﻿using QueryBuilder.Interfaces;
using QueryBuilder.Models;
using System.Text;

namespace QueryBuilder.Translators;

/// <summary>
/// Traductor de consultas para bases de datos Oracle.
/// </summary>
public class OracleQueryTranslator : IQueryTranslator
{
    /// <inheritdoc />
    public string Translate(QueryTranslationContext context)
    {
        var sb = new StringBuilder();

        sb.Append("SELECT ");
        sb.Append(string.Join(", ", context.SelectColumns));
        sb.Append(" FROM ");
        sb.Append(context.TableName);

        if (!string.IsNullOrWhiteSpace(context.WhereClause))
        {
            sb.Append(" WHERE ");
            sb.Append(context.WhereClause);
        }

        if (!string.IsNullOrWhiteSpace(context.OrderByClause))
        {
            sb.Append(" ORDER BY ");
            sb.Append(context.OrderByClause);
        }

        if (context.Offset.HasValue && context.Limit.HasValue)
        {
            sb.Append($" OFFSET {context.Offset.Value} ROWS FETCH NEXT {context.Limit.Value} ROWS ONLY");
        }

        return sb.ToString();
    }
}

﻿namespace CAUAdministracion.Models;

/// <summary>
/// Modelo LoginResult
/// </summary>
public class LoginResult
{
    /// <summary>
    /// Parametro que indica si la conexión fue exitosa.
    /// </summary>
    public bool IsSuccessful { get; set; }
    /// <summary>
    /// Mensaje de error sobre login.
    /// </summary>
    public string ErrorMessage { get; set; } = string.Empty;
    /// <summary>
    /// Nombre de Usuario con error.
    /// </summary>
    public string Username { get; set; } = string.Empty;
    /// <summary>
    /// Tipo de usuario devuelto.
    /// </summary>
    public string TipoUsuario { get; set; } = string.Empty;
}

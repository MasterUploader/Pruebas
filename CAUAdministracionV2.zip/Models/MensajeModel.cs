﻿using System.ComponentModel.DataAnnotations;

namespace CAUAdministracion.Models;

/// <summary>
/// Modelo que representa un mensaje de la tabla MANTMSG del AS400.
/// </summary>
public class MensajeModel
{
    /// <summary>
    /// Código único del mensaje.
    /// </summary>
    public int CodMsg { get; set; }

    /// <summary>
    /// Código del centro de costo (agencia).
    /// </summary>
    [Required(ErrorMessage = "Debe seleccionar una agencia.")]
    public string Codcco { get; set; } = string.Empty;

    /// <summary>
    /// Nombre de la agencia. Solo para visualización.
    /// </summary>
    public string NombreAgencia { get; set; } = string.Empty;

    /// <summary>
    /// Número de secuencia para orden.
    /// </summary>
   // [Range(1, int.MaxValue, ErrorMessage = "Secuencia debe ser mayor a 0.")]
    public int Seq { get; set; }

    /// <summary>
    /// Contenido del mensaje.
    /// </summary>
    [Required(ErrorMessage = "Debe ingresar un mensaje.")]
    public string Mensaje { get; set; } = string.Empty;

    /// <summary>
    /// Estado del mensaje: 'A' (Activo) o 'I' (Inactivo).
    /// </summary>
    public string Estado { get; set; } = string.Empty;

    /// <summary>
    /// Propiedad para mostrar el texto legible del estado (Activo/Inactivo).
    /// </summary>
    public string EstadoDescripcion
    {
        get
        {
            return Estado == "A" ? "Activo" : "Inactivo";
        }
    }
}
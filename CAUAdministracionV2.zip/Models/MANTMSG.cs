﻿namespace CAUAdministracion.Models
{
    /// <summary>
    /// Clase Modelo
    /// </summary>
    public class MANTMSG
    {
        public string CODCCO { get; set; } = string.Empty;
        public int CODMSG { get; set; }
        public int SEQ { get; set; }
        public string MENSAJE { get; set; } = string.Empty;
        public string ESTADO { get; set; } = string.Empty;
    }
}

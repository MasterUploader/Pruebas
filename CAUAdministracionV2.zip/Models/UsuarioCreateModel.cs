﻿using System.ComponentModel.DataAnnotations;

namespace CAUAdministracion.Models;

/// <summary>
/// DTO para crear un nuevo usuario de administración.
/// </summary>
public class UsuarioCreateModel
{
    [Required(ErrorMessage = "El usuario es obligatorio")]
    [StringLength(32, ErrorMessage = "Máximo 32 caracteres")]
    public string Usuario { get; set; } = string.Empty;

    [Required(ErrorMessage = "La clave es obligatoria")]
    [StringLength(10, ErrorMessage = "Máximo 10 caracteres")]
    [DataType(DataType.Password)]
    public string Clave { get; set; } = string.Empty;

    [Required(ErrorMessage = "Debe confirmar la clave")]
    [StringLength(10)]
    [DataType(DataType.Password)]
    [Compare(nameof(Clave), ErrorMessage = "Las claves no coinciden")]
    public string ConfirmarClave { get; set; } = string.Empty;

    /// <summary>
    /// 1=Administrador, 2=Admin. Videos, 3=Admin. Mensajes
    /// </summary>
    [Range(1, 3, ErrorMessage = "Tipo de usuario inválido")]
    public int TipoUsuario { get; set; } = 2;

    /// <summary>
    /// A = Activo, I = Inactivo
    /// </summary>
    [Required]
    [RegularExpression("A|I", ErrorMessage = "Estado inválido")]
    public string Estado { get; set; } = "A";
}

﻿namespace CAUAdministracion.Models;

public class UsuarioListadoModel
{
    public string Usuario { get; set; } = string.Empty;
    public int TipoUsuario { get; set; } // 1,2,3
    public string Estado { get; set; } = "A"; // "A" o "I"
}
﻿using System.ComponentModel.DataAnnotations;

namespace CAUAdministracion.Models;

/// <summary>
/// Modelo de la vista UsuarioCreateModel.
/// </summary>
public class UsuarioCreateViewModel
{
    [Required, MaxLength(32)]
    public string Usuario { get; set; } = string.Empty;

    [Required, DataType(DataType.Password), StringLength(10, MinimumLength = 1)]
    public string Clave { get; set; } = string.Empty;

    [Required, DataType(DataType.Password), Compare(nameof(Clave), ErrorMessage = "Las claves no coinciden.")]
    public string ConfirmarClave { get; set; } = string.Empty;

    [Required, Range(1, 3, ErrorMessage = "Tipo de usuario inválido.")]
    public int TipoUsuario { get; set; }

    [Required, RegularExpression("A|I", ErrorMessage = "Estado inválido.")]
    public string Estado { get; set; } = "A";
}

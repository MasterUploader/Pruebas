﻿namespace CAUAdministracion.Models;

/// <summary>
/// Representa un registro de la tabla USUADMIN en AS400.
/// Se usa para validar credenciales y roles del usuario.
/// </summary>
public class USUADMIN
{
    public string USUARIO { get; set; } = string.Empty;
    public string TIPUSU { get; set; } = string.Empty;
    public string ESTADO { get; set; } = string.Empty;
    public string PASS { get; set; } = string.Empty;
}
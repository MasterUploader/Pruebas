﻿using System.ComponentModel.DataAnnotations;

namespace CAUAdministracion.Models;

/// <summary>
/// Modelo UserLogin.
/// </summary>
public class UserLogin
{
    /// <summary>
    /// Nombre de usuario.
    /// </summary>
    [Required] 
    public string Username { get; set; } = string.Empty;

    /// <summary>
    /// Contraseña de acceso.
    /// </summary>
    [Required]
    [DataType(DataType.Password)]
    public string Password { get; set; } = string.Empty;
}

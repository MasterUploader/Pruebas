﻿namespace CAUAdministracion.Models;

/// <summary>
/// 
/// </summary>
public class MANTVIDEO
{
    public string CODCCO { get; set; } = string.Empty;
    public int CODVIDEO { get; set; }
    public int SEQ { get; set; }
    public string RUTA { get; set; } = string.Empty;
    public string NOMBRE { get; set; } = string.Empty;
    public string ESTADO { get; set; } = string.Empty;
}

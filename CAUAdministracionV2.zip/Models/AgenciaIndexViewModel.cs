﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.Rendering;
using X.PagedList;

namespace CAUAdministracion.Models;

/// <summary>
/// Modelo AgenciaIndexViewModel
/// </summary>
public class AgenciaIndexViewModel
{
    /// <summary>
    /// Lista paginada de agencias.
    /// </summary>
    [BindNever]
    public IPagedList<AgenciaModel> Lista { get; set; } 

    /// <summary>
    /// Agencia actualmente en edición.
    /// </summary>
    public AgenciaModel? AgenciaEnEdicion { get; set; }

    /// <summary>
    /// Código seleccionado en el filtro.
    /// </summary>
    public string? CodccoSeleccionado { get; set; }

    [BindNever]
    public List<SelectListItem> AgenciasFiltro { get; set; } = new();
}


﻿using System;

namespace CAUAdministracion.Models;

public class MenuItem
{
    public string Url { get; set; }
    public string Titulo { get; set; }
    public string Imagen { get; set; }
    public string Icono { get; set; }

    public MenuItem(string url, string titulo, string imagen)
    {
        Url = url;
        Titulo = titulo;
        Imagen = imagen;
    }
}

﻿using System.ComponentModel.DataAnnotations;

namespace CAUAdministracion.Models;

public class UsuarioModel
{
    [Required, MaxLength(32)]
    public string Usuario { get; set; } = string.Empty;

    /// <summary>1 = Administrador, 2 = Admin. Videos, 3 = Admin. Mensajes</summary>
    [Range(1, 3)]
    public int TipoUsuario { get; set; }

    /// <summary>A = Activo, I = Inactivo</summary>
    [Required, RegularExpression("A|I")]
    public string Estado { get; set; } = "A";
}

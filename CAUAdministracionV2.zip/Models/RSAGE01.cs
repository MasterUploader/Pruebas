﻿namespace CAUAdministracion.Models;

/// <summary>
/// Clase modelo BCAH96DTA.RSAGE01
/// </summary>
public class RSAGE01
{
    public int CODCCO { get; set; }
    public string NOMAGE { get; set; } = string.Empty;
    public int ZONA { get; set; } 
    public string MARQUESINA { get; set; } = string.Empty;
    public string RSTBRANCH { get; set; } = string.Empty;
    public string NOMBD { get; set; } = string.Empty;
    public string NOMSER { get; set; } = string.Empty;
    public string IPSER { get; set; } = string.Empty;
}

﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Security.Claims;

namespace CAUAdministracion.Helpers;
public class AutorizarPorTipoUsuarioAttribute : Attribute, IAuthorizationFilter
{
    private readonly string[] _tiposPermitidos;

    public AutorizarPorTipoUsuarioAttribute(params string[] tiposPermitidos)
    {
        _tiposPermitidos = tiposPermitidos;
    }

    public void OnAuthorization(AuthorizationFilterContext context)
    {
        var tipoUsuario = context.HttpContext.User.Claims
            .FirstOrDefault(c => c.Type == "TipoUsuario")?.Value;

        if (string.IsNullOrEmpty(tipoUsuario) || !_tiposPermitidos.Contains(tipoUsuario))
        {
            context.Result = new RedirectToActionResult("NoAutorizado", "Home", null);
        }
    }
}

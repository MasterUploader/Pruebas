using CAUAdministracion.Services.Agencias;
using CAUAdministracion.Services.Autentication;
using CAUAdministracion.Services.Mensajes;
using CAUAdministracion.Services.Menssages;
using CAUAdministracion.Services.Usuarios;
using CAUAdministracion.Services.VideoQueryService;
using CAUAdministracion.Services.Videos;
using Connections.Abstractions;
using Connections.Helpers;
using Connections.Providers.Database;
using Connections.Services;
using Microsoft.AspNetCore.Authentication.Cookies;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container
builder.Services.AddControllersWithViews();
// Cargar configuraci�n desde Connection.json por ambiente (DEV, UAT, PROD)
builder.Configuration.AddJsonFile("ConnectionData.json", optional: false, reloadOnChange: true);

var connectionSettings = new ConnectionSettings(builder.Configuration);
ConnectionManagerHelper.ConnectionConfig = connectionSettings;

// Registrar ConnectionSettings para leer configuraci�n din�mica
builder.Services.AddSingleton<ConnectionSettings>();

builder.Services.AddHttpContextAccessor();

// Registrar la conexi�n principal a AS400 usando OleDbCommand
builder.Services.AddScoped<IDatabaseConnection>(sp =>
{
    var config = sp.GetRequiredService<IConfiguration>();
    var settings = new ConnectionSettings(config);

    // Obtener la cadena de conexi�n desencriptada desde el archivo
    var connStr = settings.GetAS400ConnectionString("AS400"); // o el nombre que est�s usando

    // Instanciar proveedor interno
    return new AS400ConnectionProvider(
        connStr, null);
});


builder.Services.AddHttpClient<IVideoQueryService, VideoQueryService>();
builder.Services.AddHttpClient<IVideoService, VideoService>();
builder.Services.AddHttpClient<IMensajeService, MensajeService>();
builder.Services.AddHttpClient<IAgenciaService, AgenciaService>();
builder.Services.AddHttpClient<IUsuarioService, UsuarioService>();


//Declaraci�n de interfaces y servicios.
builder.Services.AddScoped<IVideoQueryService, VideoQueryService>();
builder.Services.AddScoped<IVideoService, VideoService>();
builder.Services.AddScoped<IMensajeService, MensajeService>();
builder.Services.AddScoped<IAgenciaService, AgenciaService>();
builder.Services.AddScoped<IUsuarioService, UsuarioService>();


builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme).AddCookie(
    options => { 
        options.LoginPath = "/Account/Login"; 
        options.LogoutPath = "/Account/Logout"; });

builder.Services.AddSession(); 
builder.Services.AddScoped<ILoginService, LoginService>();

var app = builder.Build();

// Configure the HTTP request pipeline
if (!app.Environment.IsDevelopment()) { app.UseExceptionHandler("/Home/Error"); app.UseHsts(); }

app.UseHttpsRedirection();

app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication(); 

app.UseAuthorization();

app.UseSession();

app.MapControllerRoute(name: "default", pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
﻿using CAUAdministracion.Models;
using Connections.Abstractions;
using Connections.Providers.Database;
using QueryBuilder.Builders;
using QueryBuilder.Enums;
using System.Runtime.Versioning;

namespace CAUAdministracion.Services.Agencias;

/// <summary>
/// Servicio que gestiona operaciones sobre agencias en AS400.
/// </summary>
public class AgenciaService : IAgenciaService
{
    private readonly IDatabaseConnection _as400;
    private readonly IHttpContextAccessor _httpContextAccessor;

    public AgenciaService(IDatabaseConnection as400, IHttpContextAccessor httpContextAccessor)
    {
        _as400 = as400;
        _httpContextAccessor = httpContextAccessor;
    }

    /// <summary>
    /// Lista todas las agencias registradas.
    /// </summary>
    public List<AgenciaModel> ObtenerAgencias()
    {
        var agencias = new List<AgenciaModel>();
        try
        {
            _as400.Open();

            if (!_as400.IsConnected)
                return agencias;

            //Construimos el Query
            var query = QueryBuilder.Core.QueryBuilder
            .From("RSAGE01", "BCAH96DTA")
            .Select("CODCCO", "NOMAGE", "ZONA", "MARQUESINA", "RSTBRANCH", "NOMBD", "NOMSER", "IPSER")
            .OrderBy(("CODCCO", SortDirection.Desc))
            .Build();

            using var command = _as400.GetDbCommand(_httpContextAccessor.HttpContext!);
            command.CommandText = query.Sql;

            //Validamos si la coneción se establecio
            if (command.Connection?.State == System.Data.ConnectionState.Closed)
                command.Connection.Open();

            using var reader = command.ExecuteReader();
            while (reader.Read())
            {
                agencias.Add(new AgenciaModel
                {
                    Codcco = Convert.ToInt32(reader["CODCCO"]),
                    NomAge = reader.GetString(reader.GetOrdinal("NOMAGE")),
                    Zona = Convert.ToInt32(reader["ZONA"]),
                    Marquesina = reader.GetString(reader.GetOrdinal("MARQUESINA")),
                    RstBranch = reader.GetString(reader.GetOrdinal("RSTBRANCH")),
                    NomBD = reader.GetString(reader.GetOrdinal("NOMBD")),
                    NomSer = reader.GetString(reader.GetOrdinal("NOMSER")),
                    IpSer = reader.GetString(reader.GetOrdinal("IPSER"))
                });
            }
        }
        finally
        {
            _as400.Close();
        }

        return agencias;
    }

    /// <summary>
    /// Inserta una nueva agencia en la base de datos.
    /// </summary>
    [SupportedOSPlatform("windows")]
    public bool InsertarAgencia(AgenciaModel agencia)
    {
        try
        {
            _as400.Open();

            if (!_as400.IsConnected)
                return false;

            // Generar la sentencia SQL con QueryBuilder
            var query = new InsertQueryBuilder("RSAGE01", "BCAH96DTA")
            .Values(
                ("CODCCO", agencia.Codcco),
                ("NOMAGE", agencia.NomAge),
                ("ZONA", agencia.Zona),
                ("MARQUESINA", agencia.Marquesina),
                ("RSTBRANCH", agencia.RstBranch),
                ("NOMBD", agencia.NomBD),
                ("NOMSER", agencia.NomSer),
                ("IPSER", agencia.IpSer)
            )
            .Build();

            // Crear y ejecutar el comando
            using var command = ((AS400ConnectionProvider)_as400).GetDbCommand(query, null);

            return command.ExecuteNonQuery() > 0;
        }
        finally
        {
            _as400.Close();
        }
    }

    /// <summary>
    /// Actualiza los datos de una agencia existente.
    /// </summary>
    public bool ActualizarAgencia(AgenciaModel agencia)
    {
        try
        {
            _as400.Open();

            if (!_as400.IsConnected)
                return false;

            //Construimos el Query
            var query = new UpdateQueryBuilder("RSAGE01", "BCAH96DTA")
                .Set("NOMAGE", agencia.NomAge)
                .Set("ZONA", agencia.Zona)
                .Set("MARQUESINA", agencia.Marquesina)
                .Set("RSTBRANCH", agencia.RstBranch)
                .Set("NOMBD", agencia.NomBD)
                .Set("NOMSER", agencia.NomSer)
                .Set("IPSER", agencia.IpSer)
                .Where<RSAGE01>(x => x.CODCCO == agencia.Codcco)
                .Build();

            using var command = _as400.GetDbCommand(null);
            command.CommandText = query.Sql;

            //Validamos si la coneción se establecio
            if (command.Connection?.State == System.Data.ConnectionState.Closed)
                command.Connection.Open();

            int rows = command.ExecuteNonQuery();

            return rows > 0;
        }
        finally
        {
            _as400.Close();
        }
    }

    /// <summary>
    /// Elimina una agencia de la base de datos por su código.
    /// </summary>
    public bool EliminarAgencia(int codcco)
    {
        try
        {
            _as400.Open();

            if (!_as400.IsConnected)
                return false;

            using var command = _as400.GetDbCommand(_httpContextAccessor.HttpContext!);

            var query = new DeleteQueryBuilder("RSAGE01", "BCAH96DTA")
                    .Where<RSAGE01>(X => X.CODCCO == codcco)
                    .Build();
            command.CommandText = query.Sql;

            //Validamos si la coneción se establecio
            if (command.Connection?.State == System.Data.ConnectionState.Closed)
                command.Connection.Open();

            return command.ExecuteNonQuery() > 0;
        }
        finally
        {
            _as400.Close();
        }
    }

    /// <summary>
    /// Obtiene la lista completa de agencias desde la tabla RSAGE01 en AS400.
    /// </summary>
    /// <returns>Una lista de objetos AgenciaModel.</returns>
    public async Task<List<AgenciaModel>> ObtenerAgenciasAsync()
    {
        var agencias = new List<AgenciaModel>();
        _as400.Open();

        if (!_as400.IsConnected)
            return agencias;

        try
        {
            //Construimos el Query
            var query = QueryBuilder.Core.QueryBuilder
            .From("RSAGE01", "BCAH96DTA")
            .Select("CODCCO", "NOMAGE", "NOMBD", "NOMSER", "IPSER", "ZONA", "MARQUESINA", "RSTBRANCH")
            .OrderBy(("CODCCO", SortDirection.Asc))
            .Build();

            using var command = _as400.GetDbCommand(_httpContextAccessor.HttpContext!);
            command.CommandText = query.Sql;

            using var reader = await command.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                agencias.Add(new AgenciaModel
                {
                    //reader.GetString(reader.GetOrdinal("CDC12OFIC"))
                    Codcco = Convert.ToInt32(reader["CODCCO"]),
                    NomAge = reader.GetString(reader.GetOrdinal("NOMAGE")),
                    NomBD = reader.GetString(reader.GetOrdinal("NOMBD")),
                    NomSer = reader.GetString(reader.GetOrdinal("NOMSER")),
                    IpSer = reader.GetString(reader.GetOrdinal("IPSER")),
                    Zona = Convert.ToInt32(reader["ZONA"]),
                    Marquesina = reader.GetString(reader.GetOrdinal("MARQUESINA")),
                    RstBranch = reader.GetString(reader.GetOrdinal("RSTBRANCH"))
                });
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error al obtener agencias: " + ex.Message);
        }
        finally
        {
            _as400.Close();
        }
        return agencias;
    }

    /// <summary>
    /// Obtiene la lista  de agencias desde la tabla RSAGE01 en AS400 mediante CODCCO.
    /// </summary>
    /// <returns>Una lista de objetos AgenciaModel.</returns>
    public async Task<AgenciaModel?> ObtenerAgenciaPorIdAsync(int codcco)
    {
        try
        {
            _as400.Open();

            if (!_as400.IsConnected)
                return null;

            //Construimos el Query
            var query = QueryBuilder.Core.QueryBuilder
            .From("RSAGE01", "BCAH96DTA")
            .Select("CODCCO", "NOMAGE", "ZONA", "MARQUESINA", "RSTBRANCH", "NOMBD", "NOMSER", "IPSER")
            .Where<RSAGE01>(x => x.CODCCO == codcco)
            .Build();

            using var command = _as400.GetDbCommand(_httpContextAccessor.HttpContext!);
            command.CommandText = query.Sql;

            using var reader = await command.ExecuteReaderAsync();
            if (await reader.ReadAsync())
            {
                return new AgenciaModel
                {
                    Codcco = Convert.ToInt32(reader["CODCCO"]),
                    NomAge = reader.GetString(reader.GetOrdinal("NOMAGE")),
                    NomBD = reader.GetString(reader.GetOrdinal("NOMBD")),
                    NomSer = reader.GetString(reader.GetOrdinal("NOMSER")),
                    IpSer = reader.GetString(reader.GetOrdinal("IPSER")),
                    Zona = Convert.ToInt32(reader["ZONA"]),
                    Marquesina = reader.GetString(reader.GetOrdinal("MARQUESINA")),
                    RstBranch = reader.GetString(reader.GetOrdinal("RSTBRANCH"))
                };
            }

            return null; // No encontrada
        }
        catch
        {
            return null;
        }
    }

    /// <summary>
    /// Verifica si ya existe una agencia registrada con el centro de costo especificado.
    /// </summary>
    /// <param name="codcco">Centro de costo a verificar</param>
    /// <returns>True si existe, False si no existe o ocurre un error</returns>
    public bool ExisteCentroCosto(int codcco)
    {
        try
        {
            _as400.Open();

            if (!_as400.IsConnected)
                return false;

            //Construimos el Query
            var query = QueryBuilder.Core.QueryBuilder
            .From("RSAGE01", "BCAH96DTA")
            .Select("1")
            .Where<RSAGE01>(x => x.CODCCO == codcco)
            .Build();

            using var command = _as400.GetDbCommand(_httpContextAccessor.HttpContext!);
            command.CommandText = query.Sql;

            var result = command.ExecuteScalar();
            return result != null;
        }
        catch
        {
            return false; // En caso de error asumimos que no existe
        }
        finally
        {
            _as400.Close();
        }
    }
}

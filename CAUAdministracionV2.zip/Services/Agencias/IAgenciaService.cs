﻿using CAUAdministracion.Models;

namespace CAUAdministracion.Services.Agencias;

/// <summary>
/// Contrato para el servicio de gestión de agencias.
/// </summary>
public interface IAgenciaService
{
    /// <summary>
    /// Lista todas las agencias registradas.
    /// </summary>
    Task<List<AgenciaModel>> ObtenerAgenciasAsync();

    /// <summary>
    /// Inserta una nueva agencia en AS400.
    /// </summary>
    bool InsertarAgencia(AgenciaModel agencia);

    /// <summary>
    /// Elimina una agencia según su código de centro de costo.
    /// </summary>
    bool EliminarAgencia(int codcco);

    /// <summary>
    /// Actualiza los datos de una agencia existente.
    /// </summary>
    bool ActualizarAgencia(AgenciaModel agencia);

    /// <summary>
    /// Verifica si un código de centro de costo ya existe en la tabla.
    /// </summary>
    bool ExisteCentroCosto(int codcco);

    /// <summary>
    /// Obtiene la lista  de agencias desde la tabla RSAGE01 en AS400 mediante CODCCO.
    /// </summary>
    /// <param name="codcco">Código Agencia</param>
    /// <returns>Una lista de objetos AgenciaModel</returns>
    Task<AgenciaModel?> ObtenerAgenciaPorIdAsync(int codcco);
}



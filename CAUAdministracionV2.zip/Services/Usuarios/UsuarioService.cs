﻿using CAUAdministracion.Helpers;
using CAUAdministracion.Models;
using Connections.Abstractions;
using Connections.Providers.Database;
using QueryBuilder.Builders;
using System.Data;
using System.Runtime.Versioning;

namespace CAUAdministracion.Services.Usuarios;

/// <summary>
/// Clase de Servicio UsuarioService, encargada de las operaciones CRUD para usuarios.
/// </summary>
/// <param name="as400">Instancia de conexión al As400.</param>
/// <param name="httpContextAccessor">Contex de la petición HTTP, información referente a la misma.</param>
public class UsuarioService(IDatabaseConnection as400, IHttpContextAccessor httpContextAccessor) : IUsuarioService
{
    private readonly IDatabaseConnection _as400 = as400;
    private readonly IHttpContextAccessor _httpContextAccessor = httpContextAccessor;

    /// <inheritdoc />
    public async Task<List<UsuarioModel>> BuscarUsuariosAsync(string? q, int? tipo, string? estado)
    {
        var usuario = new List<UsuarioModel>();
        try
        {
            _as400.Open();

            if (!_as400.IsConnected)
                return usuario;

            //Traemos usuario
            var query = new SelectQueryBuilder("USUADMIN", "BCAH96DTA")
                .Select("USUARIO", "TIPUSU", "ESTADO");

            // Filtros
            if (!string.IsNullOrWhiteSpace(q))
                query.WhereRaw("UPPER(USUARIO) LIKE @q");

            if (tipo.HasValue)
                query.WhereRaw("TIPUSU = @tipo");

            if (!string.IsNullOrWhiteSpace(estado))
                query.WhereRaw("ESTADO = @estado");

            query.OrderBy("USUARIO");

            var result = query.Build();
            using var command = _as400.GetDbCommand(_httpContextAccessor.HttpContext!);

            command.CommandText = result.Sql;

            // Parámetros
            if (!string.IsNullOrWhiteSpace(q))
                AddParam(command, "@q", $"%{q.Trim().ToUpper()}%");
            if (tipo.HasValue)
                AddParam(command, "@tipo", tipo.Value);
            if (!string.IsNullOrWhiteSpace(estado))
                AddParam(command, "@estado", estado);

            using var rd = await command.ExecuteReaderAsync();
            while (await rd.ReadAsync())
            {
                usuario.Add(new UsuarioModel
                {
                    Usuario = rd["USUARIO"]?.ToString() ?? "",
                    TipoUsuario = Convert.ToInt32(rd["TIPUSU"]),
                    Estado = rd["ESTADO"]?.ToString() ?? "A"
                });
            }
            return usuario;
        }
        catch
        {
            return usuario;
        }
        finally
        {
            _as400.Close();
        }
    }

    /// <inheritdoc />
    public async Task<bool> ActualizarUsuarioAsync(string usuario, string estado, int tipoUsuario)
    {
        try
        {
            _as400.Open();

            if (!_as400.IsConnected)
                return false;

            // UPDATE BCAH96DTA.USUADMIN SET ESTADO=@estado, TIPUSU=@tipo WHERE USUARIO=@usuario
            var query = new UpdateQueryBuilder("USUADMIN", "BCAH96DTA")
                .Set("ESTADO", "@estado")
                .Set("TIPUSU", "@tipo")
                .Where("USUARIO = @usuario");

            var result = query.Build();
            using var command = _as400.GetDbCommand(_httpContextAccessor.HttpContext!);

            command.CommandText = result.Sql;

            AddParam(command, "@estado", estado);
            AddParam(command, "@tipo", tipoUsuario);
            AddParam(command, "@usuario", usuario);

            var rows = await command.ExecuteNonQueryAsync();
            return rows > 0;
        }
        catch
        {
            return false;
        }
        finally
        {
            _as400.Close();
        }
    }

    /// <inheritdoc />
    public async Task<bool> EliminarUsuarioAsync(string usuario)
    {
        try
        {
            _as400.Open();

            if (!_as400.IsConnected)
                return false;

            if (!await ExisteMasDeUnUsuarioAsync())
                return false;

            var query = new DeleteQueryBuilder("USUADMIN", "BCAH96DTA")
                .Where($"USUARIO = {usuario}");

            var result = query.Build();
            using var command = _as400.GetDbCommand(_httpContextAccessor.HttpContext!);

            command.CommandText = result.Sql;

            AddParam(command, "@usuario", usuario);

            var rows = await command.ExecuteNonQueryAsync();
            return rows > 0;
        }
        catch
        {
            return false;
        }
        finally
        {
            _as400.Close();
        }
    }

    /// <inheritdoc />
    public async Task<int> ContarUsuariosAsync()
    {
        try
        {
            _as400.Open();

            if (!_as400.IsConnected)
                return 0;

            // SELECT COUNT(*) FROM BCAH96DTA.USUADMIN
            var query = new SelectQueryBuilder("USUADMIN", "BCAH96DTA")
            .Select("COUNT(*) AS CNT")
            .Build();

            using var command = _as400.GetDbCommand(_httpContextAccessor.HttpContext!);
            command.CommandText = query.Sql;

            var scalar = await command.ExecuteScalarAsync();
            return Convert.ToInt32(scalar);
        }
        catch
        {
            return 0;
        }
        finally
        {
            _as400.Close();
        }
    }

    /// <inheritdoc />
    public async Task<bool> ExisteMasDeUnUsuarioAsync()
    {
        var total = await ContarUsuariosAsync();
        return total > 1;
    }

    // --------------------------------------
    // Helpers
    // --------------------------------------
    private static void AddParam(IDbCommand cmd, string name, object? value)
    {
        var p = cmd.CreateParameter();
        p.ParameterName = name;
        p.Value = value ?? DBNull.Value;
        cmd.Parameters.Add(p);
    }

    /// <inheritdoc />
    [SupportedOSPlatform("windows")]
    public async Task<bool> ExisteUsuarioAsync(string usuario)
    {
        if (string.IsNullOrWhiteSpace(usuario)) return false;

        // SELECT COUNT(1) FROM BCAH96DTA.USUADMIN WHERE UPPER(USUARIO)=UPPER(@usuario)
        try
        {
            _as400.Open();

            if (!_as400.IsConnected)
                return false;

            //Construimos el Query
            var query = QueryBuilder.Core.QueryBuilder
            .From("USUADMIN", "BCAH96DTA")
            .Select("*")
            .WhereRaw($"UPPER(USUARIO) = UPPER('{usuario}')")
            .Build();

            using var command = _as400.GetDbCommand(_httpContextAccessor.HttpContext!);
            command.CommandText = query.Sql;

            var count = Convert.ToInt32(await command.ExecuteScalarAsync());

            if (count > 0)
            {
                return true;
            }
            return false;
        }
        catch
        {
            return true;
        }
        finally
        {
            _as400.Close();
        }
    }

    /// <inheritdoc />
    [SupportedOSPlatform("windows")]
    public async Task<bool> CrearUsuarioAsync(UsuarioModel usuario, string clavePlano)
    {
        if (usuario == null) throw new ArgumentNullException(nameof(usuario));
        if (string.IsNullOrWhiteSpace(usuario.Usuario)) throw new ArgumentException("Usuario requerido.", nameof(usuario));
        if (usuario.TipoUsuario is < 1 or > 3) throw new ArgumentException("Tipo de usuario inválido.", nameof(usuario));
        if (usuario.Estado is not ("A" or "I")) throw new ArgumentException("Estado inválido.", nameof(usuario));
        if (string.IsNullOrWhiteSpace(clavePlano)) throw new ArgumentException("Clave requerida.", nameof(clavePlano));

        // ====> Cifrado con tu clase OperacionesVarias (Legacy por defecto o AES si config lo indica)
        var claveCifrada = OperacionesVarias.EncriptarCadena(clavePlano);

        try
        {
            _as400.Open();

            if (!_as400.IsConnected)
                return false;

            //Construimos el Query
            var query = new InsertQueryBuilder("USUADMIN", "BCAH96DTA")
                .Values(
                        ("USUARIO", usuario.Usuario),
                        ("PASS", claveCifrada),
                        ("TIPUSU", usuario.TipoUsuario),
                        ("ESTADO", usuario.Estado)
                        )
                .Build();

            using var command = ((AS400ConnectionProvider)_as400).GetDbCommand(query, _httpContextAccessor.HttpContext!);

            int filas = await command.ExecuteNonQueryAsync();

            return filas > 0;
        }
        catch
        {
            return false;
        }
        finally
        {
            _as400.Close();
        }
    }
}

﻿using CAUAdministracion.Models;

namespace CAUAdministracion.Services.Usuarios;

/// <summary>
/// Interfaz de la Clase de servicio UsuarioService
/// </summary>
public interface IUsuarioService
{
    /// <summary>
    /// Método encargado de buscar usuarios para el filtro.
    /// </summary>
    /// <param name="q"></param>
    /// <param name="tipo"></param>
    /// <param name="estado"></param>
    /// <returns>Retorna una lista UsuarioModel</returns>
    Task<List<UsuarioModel>> BuscarUsuariosAsync(string? q, int? tipo, string? estado);

    /// <summary>
    /// Actualiza la información de un usuario.
    /// </summary>
    /// <param name="usuario"></param>
    /// <param name="estado"></param>
    /// <param name="tipoUsuario"></param>
    /// <returns>Retorna un valor boleano correspondiente al exito o no del proceso de actualización de usuarios.</returns>
    Task<bool> ActualizarUsuarioAsync(string usuario, string estado, int tipoUsuario);

    /// <summary>
    /// Método Que elimina un usuario del sitio web.
    /// </summary>
    /// <param name="usuario"></param>
    /// <returns>Retorna un valor boleano correspondiente al exito o no del proceso de eliminación de usuarios.</returns>
    Task<bool> EliminarUsuarioAsync(string usuario);

    /// <summary>
    /// Método que se encarga de contar si hay usuarios con ese nombre en tabla.
    /// </summary>
    /// <returns>Retorna un entero con la cantidad total, si no hay usuarios retorna 0.</returns>
    Task<int> ContarUsuariosAsync();

    /// <summary>
    /// Método que valida si existe más de un usuario en tabla.
    /// </summary>
    /// <returns></returns>
    Task<bool> ExisteMasDeUnUsuarioAsync();

    /// <summary>
    /// Verifica si ya existe un usuario (insensible a mayúsculas/minúsculas).
    /// </summary>
    /// <param name="usuario">Nombre de usuario a verificar.</param>
    /// <returns>true si existe; false en caso contrario.</returns>
    Task<bool> ExisteUsuarioAsync(string usuario);

    /// <summary>
    /// Crea un usuario nuevo en USUADMIN.
    /// </summary>
    /// <param name="usuario">Objeto con Usuario, TipoUsu y Estado.</param>
    /// <param name="clavePlano">Clave en texto plano (se cifra en el servicio).</param>
    /// <returns>true si se insertó; false si no.</returns>
    Task<bool> CrearUsuarioAsync(UsuarioModel usuario, string clavePlano);
}
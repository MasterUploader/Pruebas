﻿using CAUAdministracion.Models;
using Connections.Abstractions;
using Connections.Helpers;
using Connections.Providers.Database;
using Microsoft.AspNetCore.Mvc.Rendering;
using QueryBuilder.Builders;
using QueryBuilder.Enums;
using System.Data;
using System.Data.Common;
using System.Runtime.Versioning;

namespace CAUAdministracion.Services.Videos;
/// <summary>
/// Servicio para manejo de archivos y registros en la tabla MANTVIDEO del AS400.
/// Toda interacción con la base de datos se hace vía DbCommand.
/// </summary>
public class VideoService : IVideoService
{
    private readonly IDatabaseConnection _as400;
    private readonly IHttpContextAccessor _httpContextAccessor;

    public VideoService(IDatabaseConnection as400, IHttpContextAccessor httpContextAccessor)
    {
        _as400 = as400;
        _httpContextAccessor = httpContextAccessor;
    }

    /// <summary>
    /// Guarda el archivo recibido en el disco, detectando si la ruta es de red o local.
    /// Lanza errores controlados si no se puede escribir en la ruta especificada.
    /// </summary>
    /// <param name="archivo">Archivo subido (formulario)</param>
    /// <param name="codcco">Código de agencia</param>
    /// <param name="rutaBase">Ruta base (extraída de ConnectionData.json según el ambiente)</param>
    /// <param name="nombreArchivo">Nombre del archivo original</param>
    /// <returns>True si el archivo se guardó correctamente, false en caso contrario</returns>
    public async Task<bool> GuardarArchivoEnDisco(IFormFile archivo, string codcco, string rutaBase, string nombreArchivo)
    {
        try
        {
            // Asegura que la ruta base termine en backslash
            if (!rutaBase.EndsWith(Path.DirectorySeparatorChar))
                rutaBase += Path.DirectorySeparatorChar;

            // Ruta completa del archivo
            string rutaCompleta = Path.Combine(rutaBase, nombreArchivo);

            // Detectar si es ruta de red compartida (UNC) o local
            bool esRutaCompartida = rutaBase.StartsWith(@"\\");

            // Validación para rutas compartidas (no se deben crear)
            if (esRutaCompartida)
            {
                if (!Directory.Exists(rutaBase))
                    throw new DirectoryNotFoundException($"La ruta de red '{rutaBase}' no está disponible o no existe.");
            }
            else
            {
                // Crear ruta local si no existe (solo si no es red)
                if (!Directory.Exists(rutaBase))
                    Directory.CreateDirectory(rutaBase);
            }

            // Guardar el archivo físicamente en la ruta
            using var stream = new FileStream(rutaCompleta, FileMode.Create, FileAccess.Write);
            await archivo.CopyToAsync(stream);

            return true;
        }
        catch (DirectoryNotFoundException ex)
        {
            // Error específico por ruta no encontrada
          //  _logger?.LogError(ex, "Error de ruta al guardar el archivo en disco: {Ruta}", rutaBase);
            return false;
        }
        catch (UnauthorizedAccessException ex)
        {
            // Permisos insuficientes en la ruta
          //  _logger?.LogError(ex, "Sin permisos para escribir en la ruta: {Ruta}", rutaBase);
            return false;
        }
        catch (Exception ex)
        {
            // Error general
          //  _logger?.LogError(ex, "Error inesperado al guardar el archivo en disco");
            return false;
        }
    }

    /// <summary>
    /// Guarda el registro del video en AS400 con la ruta formateada como C:\Vid{codcco}Marq
    /// </summary>
    /// <param name="codcco">Código de agencia</param>
    /// <param name="estado">Estado del video (A/I)</param>
    /// <param name="nombreArchivo">Nombre del archivo de video</param>
    /// <param name="rutaServidor">Ruta del servidor físico (no se usa en el insert, solo para guardar el archivo)</param>
    /// <returns>True si el registro se insertó correctamente, false si falló</returns>
    [SupportedOSPlatform("windows")]
    public bool GuardarRegistroEnAs400(string codcco, string estado, string nombreArchivo, string rutaServidor)
    {
        try
        {
            // Abrir conexión a AS400 desde la librería RestUtilities.Connections
            _as400.Open();

            if (_as400.IsConnected)
            {
                // Obtener comando para ejecutar SQL
                using var command = _as400.GetDbCommand(_httpContextAccessor.HttpContext!);

                // Obtener nuevo ID para el video
                int codVideo = GetUltimoId(command);

                // Obtener secuencia correlativa
                int sec = GetSecuencia(command, codcco);

                // Construir la ruta en el formato que espera AS400: C:\Vid{codcco}Marq\
                string rutaAs400 = $"C:\\Vid{codcco}Marq\\";

                // Construir query de inserción SQL
                var query = new InsertQueryBuilder("MANTVIDEO", "BCAH96DTA")
                .Values(
                        ("CODCCO", codcco),
                        ("CODVIDEO", codVideo),
                        ("RUTA", rutaAs400),
                        ("NOMBRE", nombreArchivo),
                        ("ESTADO", estado),
                        ("SEQ", sec)
                        )
                .Build();

                // Crear y ejecutar el comando
                using var command2 = ((AS400ConnectionProvider)_as400).GetDbCommand(query, _httpContextAccessor.HttpContext!);

                // Ejecutar inserción
                int result = command2.ExecuteNonQuery();

                return result > 0;

            }
            return false;
        }
        catch (Exception ex)
        {
            // Loguear o manejar el error según tu sistema (puedes usar RestUtilities.Logging aquí si lo deseas)
            // Por ahora, devolvemos false controladamente
            return false;
        }
        finally
        {
            // Cerrar conexión correctamente
            _as400.Close();
        }
    }

    /// <summary>
    /// Obtiene la lista de agencias activas desde RSAGE01.
    /// </summary>
    public List<string> ObtenerAgencias(DbCommand command)
    {
        var agencias = new List<string>();
        try
        {
            //Generamos el Query
            //var query = new SelectQueryBuilder("RSAGE01", "BCAH96DTA")
            //    .Select("CODCCO", "NOMAGE")
            //    .Where<RSAGE01>(x => x.MARQUESINA == "SI")
            //    .OrderByCase(
            //         CaseWhenBuilder
            //            .Start<RSAGE01>(x => x.CODCCO == 0)
            //            .Then("0")
            //            .Else("1"),
            //         SortDirection.None,
            //        null // sin alias porque es para ORDER BY
            //    )
            //    .OrderBy(("NOMAGE", SortDirection.None))
            //    .Build();
            var query = new SelectQueryBuilder("RSAGE01", "BCAH96DTA")
                .Select("CODCCO", "NOMAGE")
                .Where<RSAGE01>(x => x.CODCCO == 0)
                .Build();

            command.CommandText = query.Sql;

            using var reader = command.ExecuteReader();
            while (reader.Read())
                agencias.Add(reader["CODCCO"].ToString()!);

            reader.Close();
        }
        catch
        {
            return agencias;
        }

        return agencias;
    }

    /// <summary>
    /// Obtiene las agencias en formato SelectListItem para desplegar en el formulario
    /// </summary>
    public List<SelectListItem> ObtenerAgenciasSelectList()
    {
        var agencias = new List<SelectListItem>();

        try
        {
            _as400.Open();

            if (!_as400.IsConnected)
                return agencias;

            //Generamos el Query
            //var query = new SelectQueryBuilder("RSAGE01", "BCAH96DTA")
            //    .Select("CODCCO", "NOMAGE")
            //    .Where<RSAGE01>(x => x.MARQUESINA == "SI")
            //    .OrderByCase(
            //         CaseWhenBuilder
            //            .Start<RSAGE01>(x => x.CODCCO == 0)
            //            .Then("0")
            //            .Else("1"),
            //         SortDirection.None,
            //        null // sin alias porque es para ORDER BY
            //    )
            //    .OrderBy(("NOMAGE", SortDirection.None))
            //    .Build();
            var query = new SelectQueryBuilder("RSAGE01", "BCAH96DTA")
                .Select("CODCCO", "NOMAGE")
                .Where<RSAGE01>(x => x.CODCCO == 0)
                .Build();

            using var command = _as400.GetDbCommand(_httpContextAccessor.HttpContext!);

            command.CommandText = query.Sql;

            //Validamos si la coneción se establecio

            if (command.Connection!.State == ConnectionState.Closed)
                command.Connection.Open();

            using var reader = command.ExecuteReader();
            while (reader.Read())
            {
                agencias.Add(new SelectListItem
                {
                    Value = reader["CODCCO"].ToString(),
                    Text = reader["NOMAGE"].ToString()
                });
            }
        }
        catch (Exception ex)
        {
            // Puedes loguearlo si tienes un sistema de logging, por ahora solo devolvemos una opción informativa
            agencias.Clear();
            agencias.Add(new SelectListItem
            {
                Value = "",
                Text = "Error al obtener agencias: " + ex.Message
            });
        }

        return agencias;
    }

    /// <summary>
    /// Retorna el siguiente valor de CODVIDEO (MAX + 1)
    /// </summary>
    public int GetUltimoId(DbCommand command)
    {
        try
        {

            //Construimos el Query
            var query = QueryBuilder.Core.QueryBuilder
            .From("MANTVIDEO", "BCAH96DTA")
            .Select("MAX(CODVIDEO)")
            .Build();

            command.CommandText = query.Sql;

            //Validamos si la coneción se establecio
            if (command.Connection?.State == System.Data.ConnectionState.Closed)
                command.Connection.Open();

            var result = command.ExecuteScalar();

            return result != DBNull.Value ? Convert.ToInt32(result) + 1 : 1;
        }
        catch
        {
            return 1; //or defecto
        }
    }

    /// <summary>
    /// Retorna el siguiente valor de SEQ por agencia (MAX + 1)
    /// </summary>
    public int GetSecuencia(DbCommand command, string codcco)
    {
        try
        {
            //Construimos el Query
            // Consulta SQL para obtener el valor máximo actual de SEQ en la agencia indicada
            var query = QueryBuilder.Core.QueryBuilder
            .From("MANTVIDEO", "BCAH96DTA")
            .Select("MAX(SEQ)")
            .Where<MANTMSG>(x => x.CODCCO == codcco)
            .Build();

            command.CommandText = query.Sql;
            var result = command.ExecuteScalar();

            return result != DBNull.Value ? Convert.ToInt32(result) + 1 : 1;
        }
        catch
        {
            return 1; //Por defecto
        }
    }

    /// <summary>
    /// Devuelve la ruta personalizada desde la tabla RSAGE01 según el código de agencia.
    /// </summary>
    private string GetRutaServer(string codcco)
    {
        try
        {
            // Abrir conexión a AS400
            _as400.Open();

            if (!_as400.IsConnected)
                return "";

            //Construimos el Query
            // Consulta SQL para obtener el valor máximo actual de SEQ en la agencia indicada
            var query = QueryBuilder.Core.QueryBuilder
            .From("RSAGE01", "BCAH96DTA")
            .Select("NOMSER")
            .Where<RSAGE01>(x => x.CODCCO == (int.Parse( codcco)))
            .Build();

            using var command = _as400.GetDbCommand(_httpContextAccessor.HttpContext!);
            command.CommandText = query.Sql;

            //Validamos si la coneción se establecio
            if (command.Connection?.State == System.Data.ConnectionState.Closed)
                command.Connection.Open();

           /// command.CommandText = $"SELECT NOMSER FROM BCAH96DTA.RSAGE01 WHERE CODCCO = '{codcco}'";

            using var reader = command.ExecuteReader();
            if (reader.Read())
            {
                var ruta = reader["NONSER"]?.ToString();
                if (!string.IsNullOrWhiteSpace(ruta))
                    return $"\\\\{ruta}\\";
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error al obtener ruta de servidor: {ex.Message}");
        }

        return null; // Si falla, retornará null y se usará ContenedorVideos
    }






    /// <summary>
    /// Obtiene la lista completa de videos registrados desde AS400.
    /// </summary>
    /// <returns>Lista de objetos VideoModel con la información cargada desde la tabla MANTVIDEO.</returns>
    public async Task<List<VideoModel>> ObtenerListaVideosAsync()
    {
        var videos = new List<VideoModel>();

        try
        {
            // Abrir conexión a AS400
            _as400.Open();

            if (!_as400.IsConnected)
                return videos;

            //Construimos el Query
            var query = QueryBuilder.Core.QueryBuilder
            .From("MANTVIDEO", "BCAH96DTA")
            .Select("CODCCO", "CODVIDEO", "RUTA", "NOMBRE", "ESTADO", "SEQ")
            .OrderBy(("CODCCO", SortDirection.None), ("SEQ", SortDirection.None))
            .Build();

            using var command = _as400.GetDbCommand(_httpContextAccessor.HttpContext!);
            command.CommandText = query.Sql;

            using var reader = await command.ExecuteReaderAsync();

            // Recorrer los resultados y mapear a objetos VideoModel
            while (await reader.ReadAsync())
            {
                var video = new VideoModel
                {
                    Codcco = reader["CODCCO"]?.ToString()!,
                    CodVideo = Convert.ToInt32(reader["CODVIDEO"]),
                    Ruta = reader["RUTA"]?.ToString() ?? "",
                    Nombre = reader["NOMBRE"]?.ToString() ?? "No se pudo recuperar",
                    Estado = reader["ESTADO"]?.ToString() ?? "I",
                    Seq = Convert.ToInt32(reader["SEQ"])
                };

                videos.Add(video);
            }
        }
        catch (Exception ex)
        {
            // Manejo de errores controlado (puedes usar logging aquí)
            Console.WriteLine($"Error al obtener lista de videos: {ex.Message}");
        }
        finally
        {
            // Asegurar cierre de conexión
            _as400.Close();
        }
        return videos;
    }



    /// <summary>
    /// Lista los videos activos e inactivos de una agencia desde AS400.
    /// </summary>
    public List<VideoModel> ListarVideos(string codcco)
    {
        var lista = new List<VideoModel>();

        try
        {
            _as400.Open();

            if (!_as400.IsConnected)
                return lista;

            //Construimos el Query
            var query = QueryBuilder.Core.QueryBuilder
            .From("MANTVIDEO", "BCAH96DTA")
            .Select("CODCCO", "CODVIDEO", "RUTA", "NOMBRE", "ESTADO", "SEQ")
            .Where<MANTVIDEO>(x=> x.CODCCO == codcco)
            .OrderBy(("SEQ", SortDirection.None))
            .Build();

            using var command = _as400.GetDbCommand(_httpContextAccessor.HttpContext!);
            command.CommandText = query.Sql;

            using var reader = command.ExecuteReader();
            while (reader.Read())
            {
                lista.Add(new VideoModel
                {
                    Codcco = reader["CODCCO"].ToString(),
                    CodVideo = Convert.ToInt32(reader["CODVIDEO"]),
                    Ruta = reader["RUTA"].ToString(),
                    Nombre = reader["NOMBRE"].ToString(),
                    Estado = reader["ESTADO"].ToString(),
                    Seq = Convert.ToInt32(reader["SEQ"]),
                    RutaFisica = Path.Combine(ConnectionManagerHelper.GetConnectionSection("AS400")?["ContenedorVideos"], reader["NOMBRE"].ToString())
                });
            }
        }
        catch
        {
            // Manejo opcional con logger
        }
        finally
        {
            _as400.Close();
        }

        return lista;
    }

    /// <summary>
    /// Actualiza el estado y secuencia de un video.
    /// </summary>
    public bool ActualizarVideo(VideoModel video)
    {
        try
        {
            _as400.Open();

            if (!_as400.IsConnected)
                return false;

            //Construimos el Query
            var query = new UpdateQueryBuilder("MANTVIDEO", "BCAH96DTA")
                .Set("ESTADO", video.Estado)
                .Set("SEQ", video.Seq)
                .Where<MANTVIDEO>(x => x.CODCCO == video.Codcco && x.CODVIDEO == video.CodVideo)
                .Build();

            using var command = _as400.GetDbCommand(null);
            command.CommandText = query.Sql;

            return command.ExecuteNonQuery() > 0;
        }
        catch
        {
            return false;
        }
        finally
        {
            _as400.Close();
        }
    }

    /// <summary>
    /// Elimina el registro del video en AS400.
    /// </summary>
    public bool EliminarVideo(int codVideo, string codcco)
    {
        try
        {
            _as400.Open();
            if(_as400.IsConnected) return false;

            using var command = _as400.GetDbCommand(_httpContextAccessor.HttpContext!);

            var query = new DeleteQueryBuilder("MANTVIDEO", "BCAH96DTA")
                    .Where<MANTVIDEO>(X => X.CODCCO == codcco && X.CODVIDEO == codVideo)
                    .Build();
            command.CommandText = query.Sql;

            return command.ExecuteNonQuery() > 0;
        }
        catch
        {
            return false;
        }
        finally
        {
            _as400.Close();
        }
    }

    /// <summary>
    /// Verifica si existen dependencias del video antes de eliminarlo.
    /// </summary>
    public bool TieneDependencias(string codcco, int codVideo)
    {
        try
        {
            _as400.Open();

            if (!_as400.IsConnected)
                return false;

            //Construimos el Query
            var query = QueryBuilder.Core.QueryBuilder
            .From("MANTVIDEO", "BCAH96DTA")
            .Select("COUNT(*)")            
            .Where<VideoModel>(x=> x.Codcco ==codcco && x.CodVideo == codVideo)
            .Build();

            using var command = _as400.GetDbCommand(_httpContextAccessor.HttpContext!);
            command.CommandText = query.Sql;

            var count = Convert.ToInt32(command.ExecuteScalar());
            if(count > 0)
            {
                return false;
            }
            return true;
        }
        catch
        {
            return true; // Si hay error, asumimos que tiene dependencias para prevenir borrado
        }
        finally
        {
            _as400.Close();
        }
    }

    /// <summary>
    /// Elimina el archivo físico del video del disco.
    /// </summary>
    public bool EliminarArchivoFisico(string rutaArchivo)
    {
        try
        {
            if (File.Exists(rutaArchivo))
            {
                File.Delete(rutaArchivo);
                return true;
            }
            return false;
        }
        catch
        {
            return false;
        }
    }

}
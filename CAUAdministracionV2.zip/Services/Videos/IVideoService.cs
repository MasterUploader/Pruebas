﻿using CAUAdministracion.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Data.Common;
using System.Data.OleDb;

namespace CAUAdministracion.Services.Videos;

/// <summary>
/// Interfaz para operaciones de manejo de archivos y registros de video en AS400.
/// </summary>
public interface IVideoService
{
    /// <summary>
    /// Guarda el archivo recibido en el disco, detectando si la ruta es de red o local.
    /// Lanza errores controlados si no se puede escribir en la ruta especificada.
    /// </summary>
    /// <param name="archivo">Archivo subido (formulario)</param>
    /// <param name="codcco">Código de agencia</param>
    /// <param name="rutaBase">Ruta base (extraída de ConnectionData.json según el ambiente)</param>
    /// <param name="nombreArchivo">Nombre del archivo original</param>
    /// <returns>True si el archivo se guardó correctamente, false en caso contrario</returns>
    Task<bool> GuardarArchivoEnDisco(IFormFile archivo, string codcco, string rutaBase, string nombreArchivo);

    /// <summary>
    /// Guarda el registro del video en AS400 con la ruta formateada como C:\Vid{codcco}Marq
    /// </summary>
    /// <param name="codcco">Código de agencia</param>
    /// <param name="estado">Estado del video (A/I)</param>
    /// <param name="nombreArchivo">Nombre del archivo de video</param>
    /// <param name="rutaServidor">Ruta del servidor físico (no se usa en el insert, solo para guardar el archivo)</param>
    /// <returns>True si el registro se insertó correctamente, false si falló</returns>
    bool GuardarRegistroEnAs400(string codcco, string estado, string nombreArchivo, string rutaServer);

    /// <summary>
    /// Obtiene el próximo valor para CODVIDEO (MAX + 1).
    /// </summary>
    int GetUltimoId(DbCommand command);

    /// <summary>
    /// Obtiene el próximo valor de SEQ para una agencia (MAX + 1).
    /// </summary>
    int GetSecuencia(DbCommand command, string codcco);

    /// <summary>
    /// Devuelve la lista de agencias activas (desde RSAGE01).
    /// </summary>
    List<string> ObtenerAgencias(DbCommand command);

    /// <summary>
    /// Obtiene las agencias en formato SelectListItem para desplegar en el formulario
    /// </summary>
    List<SelectListItem> ObtenerAgenciasSelectList();


    /// <summary>
    /// Obtiene la lista completa de videos registrados desde AS400.
    /// </summary>
    /// <returns>Lista de objetos VideoModel con la información cargada desde la tabla MANTVIDEO.</returns>
    Task<List<VideoModel>> ObtenerListaVideosAsync();


    List<VideoModel> ListarVideos(string codcco);
    bool ActualizarVideo(VideoModel video);
    bool EliminarVideo(int codVideo, string codcco);
    bool TieneDependencias(string codcco, int codVideo);
    bool EliminarArchivoFisico(string rutaArchivo);
}

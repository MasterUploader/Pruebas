﻿using CAUAdministracion.Models;
using CAUAdministracion.Services.Menssages;
using Connections.Abstractions;
using Connections.Providers.Database;
using Microsoft.AspNetCore.Mvc.Rendering;
using QueryBuilder.Builders;
using QueryBuilder.Enums;
using System.Data.Common;
using System.Runtime.Versioning;

namespace CAUAdministracion.Services.Mensajes;

/// <summary>
/// Servicio para la gestión de mensajes (tabla MANTMSG) en AS400.
/// </summary>
public class MensajeService(IDatabaseConnection as400, IHttpContextAccessor httpContextAccessor) : IMensajeService
{
    private readonly IDatabaseConnection _as400 = as400;
    private readonly IHttpContextAccessor _httpContextAccessor = httpContextAccessor;

    /// <summary>
    /// Obtiene todas las agencias que tienen marquesina activada, en formato SelectListItem.
    /// </summary>
    public List<SelectListItem> ObtenerAgenciasSelectList()
    {
        var agencias = new List<SelectListItem>();
        try
        {
            _as400.Open();

            if (!_as400.IsConnected)
                return agencias;

            //Generamos el Query
            var query = new SelectQueryBuilder("RSAGE01", "BCAH96DTA")
                .Select("CODCCO", "NOMAGE")
                .Where<RSAGE01>(x => x.MARQUESINA == "SI")
                .OrderByCase(
                     CaseWhenBuilder
                        .Start<RSAGE01>(x => x.CODCCO == 0)
                        .Then("0")
                        .Else("1"),
                     SortDirection.None,
                    null // sin alias porque es para ORDER BY
                )
                .OrderBy(("NOMAGE", SortDirection.None))
                .Build();

            using var command = _as400.GetDbCommand(_httpContextAccessor.HttpContext!);

            command.CommandText = query.Sql;

            using var reader = command.ExecuteReader();
            while (reader.Read())
            {
                agencias.Add(new SelectListItem
                {
                    Value = reader["CODCCO"].ToString(),
                    Text = reader["NOMAGE"].ToString()
                });
            }
        }
        catch (Exception ex)
        {
            agencias.Clear();
            agencias.Add(new SelectListItem
            {
                Value = "",
                Text = "Error: " + ex.Message
            });
        }
        finally
        {
            _as400.Close();
        }

        return agencias;
    }

    /// <summary>
    /// Lista los mensajes filtrados por código de agencia.
    /// </summary>
    public List<MensajeModel> ListarMensajes(string codcco)
    {
        var lista = new List<MensajeModel>();
        try
        {
            _as400.Open();

            if (!_as400.IsConnected)
                return lista;

            //Construimos el Query
            var query = QueryBuilder.Core.QueryBuilder
            .From("MANTMSG", "BCAH96DTA")
            .Select("CODMSG", "SEQ", "MENSAJE", "ESTADO")
            .Where<MANTMSG>(x=> x.CODCCO == codcco)
            .OrderBy(("SEQ", SortDirection.None))
            .Build();

            using var command = _as400.GetDbCommand(_httpContextAccessor.HttpContext!);
            command.CommandText = query.Sql;

            using var reader = command.ExecuteReader();
            while (reader.Read())
            {
                lista.Add(new MensajeModel
                {
                    Codcco = codcco,
                    CodMsg = Convert.ToInt32(reader["CODMSG"]),
                    Seq = Convert.ToInt32(reader["SEQ"]),
                    Mensaje = reader["MENSAJE"].ToString() ?? "No existe Mensaje, error al recuperar.",
                    Estado = reader["ESTADO"].ToString() ?? "I"
                });
            }
        }
        catch
        {
            // Error controlado, se puede loguear si se desea
        }
        finally
        {
            _as400.Close();
        }

        return lista;
    }

    /// <summary>
    /// Elimina un mensaje de la tabla MANTMSG por su ID.
    /// </summary>
    public bool EliminarMensaje(int codMsg)
    {
        try
        {
            _as400.Open();

            if (!_as400.IsConnected)
                return false;

            using var command = _as400.GetDbCommand(_httpContextAccessor.HttpContext!);

            var query = new DeleteQueryBuilder("MANTMSG", "BCAH96DTA")
                    .Where<MANTMSG>(X => X.CODMSG == codMsg)
                    .Build();

            command.CommandText = query.Sql;

            return command.ExecuteNonQuery() > 0;
        }
        catch
        {
            return false;
        }
        finally
        {
            _as400.Close();
        }
    }

    /// <summary>
    /// Actualiza un mensaje existente.
    /// </summary>
    public bool ActualizarMensaje(MensajeModel mensaje)
    {
        try
        {
            _as400.Open();

            if (!_as400.IsConnected)
                return false;

            //Construimos el Query
            var query = new UpdateQueryBuilder("MANTMSG", "BCAH96DTA")
                .Set("SEQ", mensaje.Seq)
                .Set("MENSAJE", mensaje.Mensaje)
                .Set("ESTADO", mensaje.Estado)
                .Where<MANTMSG>(x => x.CODMSG == mensaje.CodMsg && x.CODCCO == mensaje.Codcco)
                .Build();

            using var command = _as400.GetDbCommand(_httpContextAccessor.HttpContext!);
            command.CommandText = query.Sql;

            return command.ExecuteNonQuery() > 0;
        }
        catch
        {
            return false;
        }
        finally
        {
            _as400.Close();
        }
    }

    /// <summary>
    /// Obtiene el siguiente valor de CODMSG (MAX + 1).
    /// </summary>
    public int ObtenerSiguienteId()
    {
        try
        {
            _as400.Open();

            if (!_as400.IsConnected)
                return 1;

            //Construimos el Query
            var query = QueryBuilder.Core.QueryBuilder
            .From("MANTMSG", "BCAH96DTA")
            .Select("MAX(CODMSG)")
            .Build();

            using var command = _as400.GetDbCommand(_httpContextAccessor.HttpContext!);
            command.CommandText = query.Sql;
            
            var result = command.ExecuteScalar();

            return result != DBNull.Value ? Convert.ToInt32(result) + 1 : 1;
        }
        catch
        {
            return 1;
        }
        finally
        {
            _as400.Close();
        }
    }

    /// <summary>
    /// Obtiene la lista de mensajes registrados en la tabla MANTMSG desde el AS400.
    /// </summary>
    /// <returns>Una lista de objetos MensajeModel con los datos cargados desde la base de datos.</returns>
    public async Task<List<MensajeModel>> ObtenerMensajesAsync()
    {
        var mensajes = new List<MensajeModel>();

        try
        {
            _as400.Open();

            if (!_as400.IsConnected)
                return mensajes;

            //Construimos el Query
            var query = QueryBuilder.Core.QueryBuilder
            .From("MANTMSG", "BCAH96DTA")
            .Select("CODCCO", "CODMSG", "SEQ", "MENSAJE", "ESTADO")
            .OrderBy(("CODCCO", SortDirection.None), ("SEQ", SortDirection.None))
            .Build();

            using var command = _as400.GetDbCommand(_httpContextAccessor.HttpContext!);
            command.CommandText = query.Sql;

            using var reader = await command.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                mensajes.Add(new MensajeModel
                {
                    Codcco = reader["CODCCO"]?.ToString() ?? " ",
                    CodMsg = Convert.ToInt32(reader["CODMSG"]),
                    Seq = Convert.ToInt32(reader["SEQ"]),
                    Mensaje = reader["MENSAJE"]?.ToString() ?? "No existe Mensaje, error al recuperar.",
                    Estado = reader["ESTADO"]?.ToString() ?? "I"
                });
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error al obtener los mensajes: " + ex.Message);
        }
        finally
        {
            _as400.Close();
        }

        return mensajes;
    }


    /// <summary>
    /// Verifica si un mensaje tiene dependencias en otra tabla antes de eliminarlo.
    /// Esto previene eliminar mensajes que aún están en uso.
    /// </summary>
    /// <param name="codcco">Código de agencia</param>
    /// <param name="codMsg">Código del mensaje</param>
    /// <returns>True si hay dependencias encontradas, False si no hay o si ocurre un error.</returns>
    public bool TieneDependencia(string codcco, int codMsg)
    {
        try
        {
            _as400.Open();

            if (!_as400.IsConnected)
                return false;

            //Construimos el Query
            var query = QueryBuilder.Core.QueryBuilder
            .From("MANTMSG", "BCAH96DTA")
            .Select("COUNT(*)")
            .Where<MANTMSG>(x=> x.CODCCO == codcco && x.CODMSG == codMsg)
            .Build();

            using var command = _as400.GetDbCommand(_httpContextAccessor.HttpContext!);
            command.CommandText = query.Sql;

            var count = Convert.ToInt32(command.ExecuteScalar());
            if (count > 0)
            {
                return false;
            }
            return true;
        }
        catch
        {
            return true; // Si hay error, asumimos que sí tiene dependencia
        }
        finally
        {
            _as400.Close();
        }
    }

    /// <summary>
    /// Inserta un nuevo mensaje en la tabla MANTMSG en AS400.
    /// Genera el nuevo código automáticamente (MAX + 1) y secuencia correlativa por agencia.
    /// </summary>
    /// <param name="mensaje">Modelo con los datos del mensaje a insertar</param>
    /// <returns>True si se insertó correctamente, false si hubo un error</returns>
    [SupportedOSPlatform("windows")]
    public bool InsertarMensaje(MensajeModel mensaje)
    {
        try
        {
            _as400.Open();

            if (!_as400.IsConnected)
                return false;

            using var command = ((AS400ConnectionProvider)_as400).GetDbCommand(_httpContextAccessor.HttpContext!);

            // Obtener nuevo CODMSG
            int nuevoId = GetUltimoId(command);

            // Obtener nueva secuencia por agencia
            int nuevaSecuencia = GetSecuencia(mensaje.Codcco);

            // Construir query SQL de inserción

            //Construimos el Query
            var query = new InsertQueryBuilder("MANTMSG", "BCAH96DTA")
                .Values(
                        ("CODMSG", nuevoId),
                        ("CODCCO", mensaje.Codcco),
                        ("SEQ", nuevaSecuencia),
                        ("MENSAJE", mensaje.Mensaje),
                        ("ESTADO", mensaje.Estado)
                        )
                .Build();

            using var command2 = ((AS400ConnectionProvider)_as400).GetDbCommand(query, _httpContextAccessor.HttpContext!);

            int filas = command2.ExecuteNonQuery();
            return filas > 0;
        }
        catch
        {
            // Podrías loguear aquí el error si deseas
            return false;
        }
        finally
        {
            _as400.Close();
        }
    }



    /// <summary>
    /// Obtiene el próximo código de mensaje (CODMSG) a usar
    /// </summary>
    public static int GetUltimoId(DbCommand command)
    {
        //Construimos el Query
        var query = QueryBuilder.Core.QueryBuilder
        .From("MANTMSG", "BCAH96DTA")
        .Select("MAX(CODMSG)")
        .Build();

        command.CommandText = query.Sql;

        var result = command.ExecuteScalar();
        return result != DBNull.Value ? Convert.ToInt32(result) + 1 : 1;
    }

    /// <summary>
    /// Obtiene la próxima secuencia (SEQ) a usar para una agencia específica en la tabla MANTMSG.
    /// Esto se utiliza para ordenar los mensajes dentro de una misma agencia.
    /// </summary>
    /// <param name="codcco">Código de la agencia para la cual se desea obtener la secuencia.</param>
    /// <returns>Entero que representa la próxima secuencia disponible. Retorna 1 si no hay registros previos o si hay error.</returns>
    public int GetSecuencia(string codcco)
    {
        try
        {
            // Abrir conexión a AS400
            _as400.Open();

            if (!_as400.IsConnected)
                return 1;

            //Construimos el Query
            // Consulta SQL para obtener el valor máximo actual de SEQ en la agencia indicada
            var query = QueryBuilder.Core.QueryBuilder
            .From("MANTMSG", "BCAH96DTA")
            .Select("MAX(SEQ)")
            .Where<MANTMSG>(x => x.CODCCO == codcco)
            .Build();

            using var command = _as400.GetDbCommand(_httpContextAccessor.HttpContext!);
            command.CommandText = query.Sql;

            var result = command.ExecuteScalar();

            // Si el resultado no es nulo, convertir a entero y sumar 1
            return result != DBNull.Value ? Convert.ToInt32(result) + 1 : 1;
        }
        catch
        {
            // Si hay error, devolvemos 1 como secuencia inicial
            return 1;
        }
    }
}

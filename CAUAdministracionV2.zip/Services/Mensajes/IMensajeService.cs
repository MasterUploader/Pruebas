﻿using CAUAdministracion.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace CAUAdministracion.Services.Menssages;

/// <summary>
/// Interfaz que define las operaciones de mantenimiento para mensajes (MANTMSG).
/// </summary>
public interface IMensajeService
{
    /// <summary>
    /// Obtiene la lista de agencias habilitadas para mensajes.
    /// </summary>
    List<SelectListItem> ObtenerAgenciasSelectList();

    /// <summary>
    /// Obtiene todos los mensajes filtrados por agencia si se especifica.
    /// </summary>
    Task<List<MensajeModel>> ObtenerMensajesAsync();

    /// <summary>
    /// Actualiza un mensaje existente (secuencia, contenido, estado).
    /// </summary>
    bool ActualizarMensaje(MensajeModel mensaje);

    /// <summary>
    /// Elimina un mensaje por su código único.
    /// </summary>
    bool EliminarMensaje(int codMsg);

    /// <summary>
    /// Verifica si el mensaje tiene dependencias (si aplica).
    /// </summary>
    bool TieneDependencia(string codcco, int codMsg);

    /// <summary>
    /// Inserta un nuevo mensaje en la tabla MANTMSG en AS400.
    /// Genera el nuevo código automáticamente (MAX + 1) y secuencia correlativa por agencia.
    /// </summary>
    /// <param name="mensaje">Modelo con los datos del mensaje a insertar</param>
    /// <returns>True si se insertó correctamente, false si hubo un error</returns>
    bool InsertarMensaje(MensajeModel mensaje);

    /// <summary>
    /// Obtiene la próxima secuencia (SEQ) a usar para una agencia específica en la tabla MANTMSG.
    /// Esto se utiliza para ordenar los mensajes dentro de una misma agencia.
    /// </summary>
    /// <param name="codcco">Código de la agencia para la cual se desea obtener la secuencia.</param>
    /// <returns>Entero que representa la próxima secuencia disponible. Retorna 1 si no hay registros previos o si hay error.</returns>
    int GetSecuencia(string codcco);
}
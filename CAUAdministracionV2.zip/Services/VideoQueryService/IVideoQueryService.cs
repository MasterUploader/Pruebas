﻿using CAUAdministracion.Models;

namespace CAUAdministracion.Services.VideoQueryService;

/// <summary>
/// Define las operaciones de consulta para videos registrados en AS400.
/// </summary>
public interface IVideoQueryService
{
    /// <summary>
    /// Retorna la lista de todos los videos registrados.
    /// </summary>
    List<VideoModel> ObtenerTodos();

    /// <summary>
    /// Obtiene un video por su código de agencia y código de video.
    /// </summary>
    VideoModel ObtenerPorId(string codcco, int codvideo);

    /// <summary>
    /// Elimina un registro de video por su código y agencia.
    /// </summary>
    bool Eliminar(string codcco, int codvideo);
}
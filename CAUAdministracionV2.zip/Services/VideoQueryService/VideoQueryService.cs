﻿using CAUAdministracion.Models;
using Connections.Abstractions;

namespace CAUAdministracion.Services.VideoQueryService;

/// <summary>
/// Implementación del servicio de consultas para videos usando DbCommand.
/// </summary>
public class VideoQueryService : IVideoQueryService
{
    private readonly IDatabaseConnection _as400;
    private readonly IHttpContextAccessor _httpContextAccessor;

    public VideoQueryService(IDatabaseConnection as400, IHttpContextAccessor httpContextAccessor)
    {
        _as400 = as400;
        _httpContextAccessor = httpContextAccessor;
    }

    public List<VideoModel> ObtenerTodos()
    {
        var lista = new List<VideoModel>();

        try
        {
            _as400.Open();

            if (!_as400.IsConnected)
                return lista;

            using var command = _as400.GetDbCommand(_httpContextAccessor.HttpContext!);

            command.CommandText = "SELECT CODCCO, CODVIDEO, RUTA, NOMBRE, ESTADO, SEQ FROM BCAH96DTA.MANTVIDEO";

            using var reader = command.ExecuteReader();
            while (reader.Read())
            {
                var video = new VideoModel
                {
                    
                    Codcco = reader["CODCCO"].ToString(),
                    CodVideo = Convert.ToInt32(reader["CODVIDEO"]),
                    Ruta = reader["RUTA"].ToString(),
                    Nombre = reader["NOMBRE"].ToString(),
                    Estado = reader["ESTADO"].ToString(),
                    Seq = Convert.ToInt32(reader["SEQ"])
                };

                lista.Add(video);
            }

            return lista;
        }
        finally
        {
            _as400.Close();
        }
    }

    public VideoModel ObtenerPorId(string codcco, int codvideo)
    {
        VideoModel? video = new();

        try
        {
            _as400.Open();

            if (!_as400.IsConnected)
                return video;

            using var command = _as400.GetDbCommand(_httpContextAccessor.HttpContext!);

            command.CommandText = $@"
                    SELECT CODCCO, CODVIDEO, RUTA, NOMBRE, ESTADO, SEQ 
                    FROM BCAH96DTA.MANTVIDEO 
                    WHERE CODCCO = '{codcco}' AND CODVIDEO = {codvideo}";

            using var reader = command.ExecuteReader();
            if (reader.Read())
            {
                video = new VideoModel
                {
                    Codcco = reader["CODCCO"].ToString(),
                    CodVideo = Convert.ToInt32(reader["CODVIDEO"]),
                    Ruta = reader["RUTA"].ToString(),
                    Nombre = reader["NOMBRE"].ToString(),
                    Estado = reader["ESTADO"].ToString(),
                    Seq = Convert.ToInt32(reader["SEQ"])
                };
            }

            return video!;
        }
        finally
        {
            _as400.Close();
        }
    }

    public bool Eliminar(string codcco, int codvideo)
    {
        try
        {
            _as400.Open();

            if (!_as400.IsConnected)
                return false;

            using var command = _as400.GetDbCommand(_httpContextAccessor.HttpContext!);

            command.CommandText = $@"
                    DELETE FROM BCAH96DTA.MANTVIDEO 
                    WHERE CODCCO = '{codcco}' AND CODVIDEO = {codvideo}";

            return command.ExecuteNonQuery() > 0;
        }
        catch
        {
            return false;
        }
        finally
        {
            _as400.Close();
        }
    }
}

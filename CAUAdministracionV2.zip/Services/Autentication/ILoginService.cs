﻿using CAUAdministracion.Models;

namespace CAUAdministracion.Services.Autentication;

/// <summary>
/// Interfaz ILoginService -> para LoginService.
/// </summary>
public interface ILoginService
{
    /// <summary>
    /// Interfaz Validate User de tipo LoginResult.
    /// </summary>
    /// <param name="username">Nombre de Usuario.</param>
    /// <param name="password">Contraseña del usuario.</param>
    /// <returns></returns>
    LoginResult ValidateUser(string username, string password);
}



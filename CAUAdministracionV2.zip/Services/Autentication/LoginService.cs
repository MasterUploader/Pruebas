﻿using CAUAdministracion.Helpers;
using CAUAdministracion.Models;
using Connections.Abstractions;

namespace CAUAdministracion.Services.Autentication;

/// <summary>
/// Servicio de autenticación utilizando comandos SQL directos en AS400.
/// </summary>
public class LoginService(IDatabaseConnection _as400, IHttpContextAccessor _httpContextAccessor) : ILoginService
{
    public LoginResult ValidateUser(string username, string password)
    {
        var result = new LoginResult();
        _as400.Open();

        if (!_as400.IsConnected)
            return null;

        try
        {
            //Construimos el Query
            var query = QueryBuilder.Core.QueryBuilder
                .From("USUADMIN", "BCAH96DTA")
                .Select("TIPUSU", "ESTADO", "PASS")
                .Where<USUADMIN>(c => c.USUARIO == username)
                .Build();

            // Usa método GetDbCommand para conexión directa desde la librería
            using var command = _as400.GetDbCommand(_httpContextAccessor.HttpContext!);
            command.CommandText = query.Sql;

            USUADMIN datos = null;

            using var reader = command.ExecuteReader();
            if (reader.Read())
            {
                datos = new USUADMIN
                {
                    TIPUSU = reader["TIPUSU"].ToString() ?? "0",
                    ESTADO = reader["ESTADO"].ToString() ?? "X",
                    PASS = reader["PASS"].ToString() ?? ""
                };
            }

            if (datos == null)
            {
                result.ErrorMessage = "Usuario Incorrecto";
                return result;
            }

            var passDesencriptada = OperacionesVarias.DesencriptarAuto(datos.PASS ?? "Sin Contraseña");

            if (!password.Equals(passDesencriptada))
            {
                result.ErrorMessage = "Contraseña Incorrecta";
                return result;
            }

            if (datos.ESTADO != "A")
            {
                result.ErrorMessage = "Usuario Inhabilitado";
                return result;
            }

            result.IsSuccessful = true;
            result.Username = username;
            result.TipoUsuario = datos.TIPUSU ?? "";
            return result;
        }
        catch (Exception ex)
        {
            result.ErrorMessage = ex.Message;
            return result;
        }
        finally
        {
            _as400.Close();
        }
    }
}
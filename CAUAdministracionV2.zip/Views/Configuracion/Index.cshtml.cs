using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CAUAdministracion.Views.Configuracion
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

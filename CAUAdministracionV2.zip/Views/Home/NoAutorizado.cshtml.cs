using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CAUAdministracion.Views.Home
{
    public class NoAutorizadoModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

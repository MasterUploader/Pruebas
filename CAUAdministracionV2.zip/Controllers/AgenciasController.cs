﻿using CAUAdministracion.Helpers;
using CAUAdministracion.Models;
using CAUAdministracion.Services.Agencias;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using X.PagedList.Extensions;

namespace CAUAdministracion.Controllers;

/// <summary>
/// Controlador responsable de gestionar las agencias (agregar, listar, editar, eliminar).
/// </summary>
[Authorize]
public class AgenciasController : Controller
{
    private readonly IAgenciaService _agenciaService;

    public AgenciasController(IAgenciaService agenciaService)
    {
        _agenciaService = agenciaService;
    }

    /// <summary>
    /// Vista principal de mantenimiento de agencias.
    /// Lista todas las agencias existentes.
    /// </summary>
    [HttpGet]
    [AutorizarPorTipoUsuario("1")]
    public async Task<IActionResult> Index(int? page, int? codcco, int? editId)
    {
        var agencias = await _agenciaService.ObtenerAgenciasAsync();

        // Generar lista de agencias para el filtro
        var listaSelect = agencias.Select(a => new SelectListItem
        {
            Value = a.Codcco.ToString(),
            Text = $"{a.Codcco} - {a.NomAge}"
        }).ToList();

        // Filtrar si se seleccionó una agencia
        if (codcco.HasValue && codcco.Value > 0)
            agencias = agencias.Where(a => a.Codcco == codcco.Value).ToList();

        // Obtener agencia en edición si corresponde
        AgenciaModel? agenciaEnEdicion = null;
        if (editId.HasValue)
            agenciaEnEdicion = agencias.FirstOrDefault(a => a.Codcco == editId.Value);

        // Paginación
        int pageNumber = page ?? 1;
        int pageSize = 10;

        // Construir el ViewModel completo
        var modelo = new AgenciaIndexViewModel
        {
            Lista = agencias.ToPagedList(pageNumber, pageSize),
            AgenciaEnEdicion = agenciaEnEdicion,
            CodccoSeleccionado = codcco?.ToString(),
            AgenciasFiltro = listaSelect // Asegurado aquí
        };

        return View("Index", modelo);
    }

    /// <summary>
    /// Vista del formulario para agregar una nueva agencia.
    /// </summary>
    [AutorizarPorTipoUsuario("1")]
    [HttpGet]
    public IActionResult Agregar()
    {
        return View();
    }

    /// <summary>
    /// Procesa el formulario de nueva agencia.
    /// Verifica si el centro de costo ya existe antes de insertar.
    /// </summary>
    [HttpPost]
    [AutorizarPorTipoUsuario("1")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Agregar(AgenciaModel model)
    {
        try
        {
            if (!ModelState.IsValid)
                return  View(model);

            if ( _agenciaService.ExisteCentroCosto(model.Codcco))
            {
                ModelState.AddModelError("Codcco", "Ya existe una agencia con ese centro de costo.");
                return View(model);
            }

            if (_agenciaService.InsertarAgencia(model))
            {
                TempData["Mensaje"] = "Agencia agregada correctamente.";
                return RedirectToAction("Index");
            }
            ModelState.AddModelError("", "Ocurrió un error al agregar la agencia.");
            return View(model);
        }
        catch (Exception ex)
        {
            ModelState.AddModelError(string.Empty, $"Error al guardar: {ex.Message}");
            return View(model);
        }
    }



    /// <summary>
    /// Procesa la actualización de una agencia desde vista en tabla editable.
    /// </summary>
    [AutorizarPorTipoUsuario("1")]
    [HttpGet]
    public async Task<IActionResult> Editar(int id)
    {
        var agencia = await _agenciaService.ObtenerAgenciaPorIdAsync(id);
        if (agencia == null)
        {
            TempData["Mensaje"] = "Agencia no encontrada.";
            return RedirectToAction("Index");
        }

        return View(agencia);
    }

    [HttpPost]
    [AutorizarPorTipoUsuario("1")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Editar(AgenciaModel model)
    {
        if (!ModelState.IsValid)
        {
            return View(model);
        }

        var resultado = _agenciaService.ActualizarAgencia(model);

        if (resultado)
        {
            TempData["Mensaje"] = "Agencia actualizada exitosamente.";
            return RedirectToAction("Index");
        }
        else
        {
            ModelState.AddModelError("", "Error al actualizar la agencia.");
            return View(model);
        }
    }

    /// <summary>
    /// Metodo para guardar 
    /// </summary>
    /// <param name="model"></param>
    /// <returns></returns>
    [HttpPost]
    [AutorizarPorTipoUsuario("1")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> GuardarEdicion(AgenciaIndexViewModel model)
    {
        ModelState.Remove("Lista");
        var agencia = model.AgenciaEnEdicion;

        if (!ModelState.IsValid)
        {
            var agencias = await _agenciaService.ObtenerAgenciasAsync();

            model.Lista = agencias.ToPagedList(1, 10);
            model.CodccoSeleccionado = null;
            model.AgenciasFiltro = agencias.Select(a => new SelectListItem
            {
                Value = a.Codcco.ToString(),
                Text = $"{a.Codcco} - {a.NomAge}"
            }).ToList();

            return View("Index", model);
        }

        var actualizado = _agenciaService.ActualizarAgencia(agencia);

        TempData["Mensaje"] = actualizado
            ? "Agencia actualizada correctamente."
            : "Ocurrió un error al actualizar.";

        return RedirectToAction("Index");
    }

    /// <summary>
    /// Procesa la eliminación de una agencia por su código.
    /// </summary>
    [HttpPost]
    [AutorizarPorTipoUsuario("1")]
    public IActionResult Eliminar(int id)
    {
        if (id < 0)
        {
            TempData["Error"] = "Código de agencia no válido.";
            return RedirectToAction("Index");
        }

        var eliminado = _agenciaService.EliminarAgencia(id);
        TempData["Mensaje"] = eliminado
            ? "Agencia eliminada correctamente."
            : "No se pudo eliminar la agencia.";

        return RedirectToAction("Index");
    }
}
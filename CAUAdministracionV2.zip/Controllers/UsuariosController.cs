﻿using CAUAdministracion.Helpers;
using CAUAdministracion.Models;
using CAUAdministracion.Services.Usuarios;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using X.PagedList.Extensions;

namespace CAUAdministracion.Controllers;

[Authorize, AutorizarPorTipoUsuario("1")]
public class UsuariosController : Controller
{
    private readonly IUsuarioService _usuarioService;

    public UsuariosController(IUsuarioService usuarioService)
    {
        _usuarioService = usuarioService;
    }

    // ========= AGREGAR =========

    [HttpGet]
    [AutorizarPorTipoUsuario("1")]
    public IActionResult Agregar()
    {
        return View(new UsuarioCreateViewModel());
    }

    [HttpPost]
    [AutorizarPorTipoUsuario("1")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Agregar(UsuarioCreateViewModel model)
    {
        // Validaciones de negocio ANTES del IsValid, para que influyan
        if (!string.IsNullOrWhiteSpace(model.Usuario))
        {
            
            // --- Validaciones básicas del lado servidor ---
            if (string.IsNullOrWhiteSpace(model.Usuario))
                ModelState.AddModelError(nameof(model.Usuario), "El usuario es obligatorio.");

            if (model.TipoUsuario < 1 || model.TipoUsuario > 3)
                ModelState.AddModelError(nameof(model.TipoUsuario), "Tipo de usuario inválido.");

            if (model.Estado != "A" && model.Estado != "I")
                ModelState.AddModelError(nameof(model.Estado), "Estado inválido.");

            if (string.IsNullOrWhiteSpace(model.Clave) || string.IsNullOrWhiteSpace(model.ConfirmarClave))
                ModelState.AddModelError(nameof(model.Clave), "Debe indicar la clave y su confirmación.");

            if (!string.Equals(model.Clave, model.ConfirmarClave))
                ModelState.AddModelError(nameof(model.ConfirmarClave), "Las claves no coinciden.");

            if (await _usuarioService.ExisteUsuarioAsync(model.Usuario.Trim()))
            {
                ModelState.AddModelError(nameof(model.Usuario), "El usuario ya existe.");
            }
        }

        // Si hay cualquier error de DataAnnotations o de negocio, será inválido
        if (!ModelState.IsValid)
            return View(model);

        var usuario = new UsuarioModel
        {
            Usuario = model.Usuario.Trim(),
            TipoUsuario = model.TipoUsuario,
            Estado = model.Estado
        };

        var creado = await _usuarioService.CrearUsuarioAsync(usuario, model.Clave);
        if (creado)
        {
            TempData["Mensaje"] = "Usuario creado correctamente.";
            return RedirectToAction("Index");
        }

        ModelState.AddModelError(string.Empty, "No se pudo crear el usuario.");
        return View(model);
    }


    // Listado + filtros + paginación + modo edición por fila
    [HttpGet]
    [AutorizarPorTipoUsuario("1")]
    public async Task<IActionResult> Index(int? page, string? q, int? tipo, string? estado, string? editUser)
    {
        var datos = await _usuarioService.BuscarUsuariosAsync(q, tipo, estado);
        var pageSize = 10;
        var pageNumber = page ?? 1;

        ViewBag.Q = q;
        ViewBag.TipoSel = tipo?.ToString();
        ViewBag.EstadoSel = estado;
        ViewBag.EditUser = editUser;

        return View(datos.ToPagedList(pageNumber, pageSize));
    }

    // Actualiza una fila (usuario, estado y tipo)
    [HttpPost]
    [AutorizarPorTipoUsuario("1")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Actualizar(string usuario, string estado, int tipoUsuario, string? q, int? tipo, string? filtroEstado, int? page)
    {
        // Si intenta inactivar y es el único, bloquear
        if (string.Equals(estado, "I", StringComparison.OrdinalIgnoreCase)
            && !await _usuarioService.ExisteMasDeUnUsuarioAsync())
        {
            TempData["Mensaje"] = "No puede inactivar/eliminar al único usuario del sistema.";
            return RedirectToAction("Index", new { page, q, tipo, estado = filtroEstado });
        }

        var ok = await _usuarioService.ActualizarUsuarioAsync(usuario, estado, tipoUsuario);
        TempData["Mensaje"] = ok ? "Usuario actualizado." : "No se pudo actualizar el usuario.";

        return RedirectToAction("Index", new { page, q, tipo, estado = filtroEstado });
    }

    // Elimina una fila
    [HttpPost]
    [AutorizarPorTipoUsuario("1")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Eliminar(string usuario, string? q, int? tipo, string? estado, int? page)
    {
        var ok = await _usuarioService.EliminarUsuarioAsync(usuario);

        TempData["Mensaje"] = ok
            ? $"Usuario '{usuario}' eliminado."
            : "No se pudo eliminar. Debe existir al menos un usuario en el sistema.";

        return RedirectToAction("Index", new { page, q, tipo, estado });
    }

    // (Opcional) Navegar a “Crear”
    [HttpGet]
    [AutorizarPorTipoUsuario("1")]
    public IActionResult Crear() => View();
}
﻿using CAUAdministracion.Services.Videos;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Connections;
using Connections.Services;
using Connections.Helpers;
using CAUAdministracion.Models;
using System.Net.NetworkInformation;
using X.PagedList.Extensions;
using System.Security.Claims;
using CAUAdministracion.Helpers;

namespace CAUAdministracion.Controllers;

[Authorize]
public class VideosController : Controller
{
    private readonly IVideoService _videoService;

    public VideosController(IVideoService videoService)
    {
        _videoService = videoService;
    }

    // ============= AGREGAR VIDEO =============
    [AutorizarPorTipoUsuario("1", "2")]
    [HttpGet]
    public IActionResult Agregar()
    {
        var tipoUsuario = User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Role)?.Value;

        

        var agencias = _videoService.ObtenerAgenciasSelectList();
        ViewBag.Agencias = agencias;
        return View();
    }

    [AutorizarPorTipoUsuario("1", "2")]
    [HttpPost]
    public async Task<IActionResult> Agregar(IFormFile archivo, string codcco, string estado)
    {
        if (archivo == null || archivo.Length == 0)
        {
            ModelState.AddModelError("archivo", "Debe seleccionar un archivo.");
            return View();
        }

        var nombreArchivo = Path.GetFileName(archivo.FileName);
        string rutaContenedorBase = ConnectionManagerHelper.GetConnectionSection("AS400")?["ContenedorVideos"];

        bool guardadoOk = await _videoService.GuardarArchivoEnDisco(archivo, codcco, rutaContenedorBase, nombreArchivo);
        if (!guardadoOk)
        {
            ViewBag.Mensaje = "No se pudo guardar el archivo.";
            ViewBag.MensajeTipo = "danger";
            return View();
        }

        bool insertadoOk = _videoService.GuardarRegistroEnAs400(codcco, estado, nombreArchivo, rutaContenedorBase);
        if (!insertadoOk)
        {
            ViewBag.Mensaje = "No se pudo registrar en la base de datos.";
            ViewBag.MensajeTipo = "danger";
            return View();
        }

        // Redirección con mensaje por TempData (si prefieres persistencia)
        TempData["Mensaje"] = "Video agregado correctamente.";
        TempData["MensajeTipo"] = "success";
        return RedirectToAction("Index");
    }

    // ============= INDEX / MANTENIMIENTO =============
    [AutorizarPorTipoUsuario("1", "2")]
    [HttpGet]
    public async Task<IActionResult> Index(int? page, string codcco)
    {
        var agencias = _videoService.ObtenerAgenciasSelectList();
        var videos = string.IsNullOrEmpty(codcco)
            ? await _videoService.ObtenerListaVideosAsync()
            : _videoService.ListarVideos(codcco);

        int pageSize = 10;
        int pageNumber = page ?? 1;

        ViewBag.Agencias = agencias;
        ViewBag.CodccoSeleccionado = codcco;

        return View(videos.ToPagedList(pageNumber, pageSize));
    }

    [AutorizarPorTipoUsuario("1", "2")]
    [HttpPost]
    public IActionResult Actualizar(int codVideo, string codcco, string Estado, int Seq)
    {
        var video = new VideoModel
        {
            CodVideo = codVideo,
            Codcco = codcco,
            Estado = Estado,
            Seq = Seq
        };

        var actualizado = _videoService.ActualizarVideo(video);

        TempData["Mensaje"] = actualizado
            ? "Registro actualizado correctamente."
            : "Error al actualizar el registro.";
        TempData["MensajeTipo"] = actualizado ? "success" : "danger";

        return RedirectToAction("Index", new { codcco });
    }

    [AutorizarPorTipoUsuario("1", "2")]
    [HttpPost]
    public IActionResult Eliminar(int codVideo, string codcco)
    {
        if (_videoService.TieneDependencias(codcco, codVideo))
        {
            TempData["Mensaje"] = "No se puede eliminar el video porque tiene dependencias.";
            TempData["MensajeTipo"] = "warning";
            return RedirectToAction("Index", new { codcco });
        }

        var lista = _videoService.ListarVideos(codcco);
        var video = lista.FirstOrDefault(v => v.CodVideo == codVideo);

        if (video == null)
        {
            TempData["Mensaje"] = "El video no fue encontrado.";
            TempData["MensajeTipo"] = "warning";
            return RedirectToAction("Index", new { codcco });
        }

        var eliminadoDb = _videoService.EliminarVideo(codVideo, codcco);
        var eliminadoArchivo = _videoService.EliminarArchivoFisico(video.RutaFisica);

        TempData["Mensaje"] = (eliminadoDb && eliminadoArchivo)
            ? "Video eliminado correctamente."
            : "Error al eliminar el video.";
        TempData["MensajeTipo"] = (eliminadoDb && eliminadoArchivo) ? "success" : "danger";

        return RedirectToAction("Index", new { codcco });
    }
}
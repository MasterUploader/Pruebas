﻿using Microsoft.AspNetCore.Mvc;

namespace CAUAdministracion.Controllers
{
    public class ConfigurationController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
